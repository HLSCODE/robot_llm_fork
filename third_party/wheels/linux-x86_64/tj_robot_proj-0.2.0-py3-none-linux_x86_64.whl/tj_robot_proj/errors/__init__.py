"""SDK exception hierarchy.

Every exception that leaves the public API inherits from ``TianjiSdkError``.
Callers can catch a specific subtype or the base to handle all SDK errors.
"""

from __future__ import annotations

from typing import Any


class TianjiSdkError(RuntimeError):
    """Base for all SDK-raised exceptions."""

    def __init__(
        self,
        message: str = "",
        *,
        operation: str | None = None,
        arm: str | None = None,
        native_code: int | None = None,
        detail: str | None = None,
    ) -> None:
        super().__init__(message)
        self.operation: str | None = operation
        self.arm: str | None = arm
        self.native_code: int | None = native_code
        self.detail: str | None = detail

    def __str__(self) -> str:
        base = super().__str__()
        parts: list[str] = []
        if self.operation:
            parts.append(f"operation={self.operation}")
        if self.arm:
            parts.append(f"arm={self.arm}")
        if self.native_code is not None:
            parts.append(f"native_code={self.native_code}")
        if self.detail:
            parts.append(f"detail={self.detail}")
        if parts:
            return f"{base} [{', '.join(parts)}]"
        return base


class ConfigurationError(TianjiSdkError):
    """Configuration is invalid (bad IP, missing file, out-of-range value)."""


class NativeLibraryError(TianjiSdkError):
    """Failed to load or call a native DLL / SO."""


class ConnectionError(TianjiSdkError):
    """Failed to connect to the robot controller."""


class InitializationError(TianjiSdkError):
    """Robot initialisation failed (clear-error, mode-set, kinematics init)."""


class CommunicationError(TianjiSdkError):
    """Command/response communication failure with the controller."""


class DeviceFaultError(TianjiSdkError):
    """The robot reported a device-level fault or alarm."""


class KinematicsError(TianjiSdkError):
    """Forward or inverse kinematics computation failed."""


class MotionRejectedError(TianjiSdkError):
    """A motion command was rejected by the controller."""


class MotionTimeoutError(TianjiSdkError):
    """A blocking motion did not complete within the timeout."""


class OperationCancelledError(TianjiSdkError):
    """An in-progress operation was cancelled."""


class UnsupportedCapabilityError(TianjiSdkError):
    """The connected robot does not support the requested capability."""


class ClosedSessionError(TianjiSdkError):
    """An operation was attempted on a closed session."""
