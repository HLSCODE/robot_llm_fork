"""Native library binding declarations.

All ``ctypes`` function prototypes are defined once here.  Every
``argtypes`` / ``restype`` is set at module-import time — never
repeatedly inside method bodies.
"""

from __future__ import annotations

import ctypes
import os
import sys
from ctypes import (
    POINTER,
    Structure,
    c_bool,
    c_char,
    c_char_p,
    c_double,
    c_float,
    c_int,
    c_int32,
    c_long,
    c_short,
    c_ubyte,
    c_void_p,
)

# ---------------------------------------------------------------------------
# Platform detection
# ---------------------------------------------------------------------------

_PLATFORM = sys.platform
_IS_WINDOWS = _PLATFORM == "win32"

# SDK directory relative to this file
_SDK_DIR = os.path.dirname(os.path.abspath(__file__))


def _sdk_path(name: str) -> str:
    return os.path.join(_SDK_DIR, name)


# ---------------------------------------------------------------------------
# Shared ctypes aliases
# ---------------------------------------------------------------------------

FX_INT32L = c_int32
FX_DOUBLE = c_double
FX_BOOL = c_bool

# ---------------------------------------------------------------------------
# DCSS structures (native protocol types)
# ---------------------------------------------------------------------------


class RT_STATE(Structure):
    """``StateCtr`` — per-arm state (current / command / error code)."""

    _fields_ = [
        ("m_CurState", c_int32),
        ("m_CmdState", c_int32),
        ("m_ERRCode", c_int32),
    ]


class RT_OUT(Structure):
    """``RT_OUT`` — feedback output.  Field order/types match ``FxRtCSDef.h``."""

    _fields_ = [
        ("m_OutFrameSerial", c_int32),
        ("m_FB_Joint_Pos", c_float * 7),
        ("m_FB_Joint_Vel", c_float * 7),
        ("m_FB_Joint_PosE", c_float * 7),
        ("m_FB_Joint_Cmd", c_float * 7),
        ("m_FB_Joint_CToq", c_float * 7),
        ("m_FB_Joint_SToq", c_float * 7),
        ("m_FB_Joint_Them", c_float * 7),
        ("m_EST_Joint_Firc", c_float * 7),
        ("m_EST_Joint_Firc_Dot", c_float * 7),
        ("m_EST_Joint_Force", c_float * 7),
        ("m_EST_Cart_FN", c_float * 6),
        ("m_TipDI", c_ubyte),
        ("m_LowSpdFlag", c_ubyte),
        ("m_pad", c_char * 1),
        ("m_TrajState", c_ubyte),
    ]


class RT_IN(Structure):
    """``RT_IN`` — real-time input.  Field order/types match ``FxRtCSDef.h``."""

    _fields_ = [
        ("m_RtInSwitch", c_int32),
        ("m_ImpType", c_int32),
        ("m_InFrameSerial", c_int32),
        ("m_FrameMissCnt", c_short),
        ("m_MaxFrameMissCnt", c_short),
        ("m_SysCyc", c_int32),
        ("m_SysCycMissCnt", c_short),
        ("m_MaxSysCycMissCnt", c_short),
        ("m_ToolKine", c_float * 6),
        ("m_ToolDyn", c_float * 10),
        ("m_Joint_CMD_Pos", c_float * 7),
        ("m_Joint_Vel_Ratio", c_short),
        ("m_Joint_Acc_Ratio", c_short),
        ("m_Joint_K", c_float * 7),
        ("m_Joint_D", c_float * 7),
        ("m_DragSpType", c_int32),
        ("m_DragSpPara", c_float * 6),
        ("m_Cart_KD_Type", c_int32),
        ("m_Cart_K", c_float * 6),
        ("m_Cart_D", c_float * 6),
        ("m_Cart_KN", c_float),
        ("m_Cart_DN", c_float),
        ("m_Force_FB_Type", c_int32),
        ("m_Force_Type", c_int32),
        ("m_Force_Dir", c_float * 6),
        ("m_Force_PIDUL", c_float * 7),
        ("m_Force_AdjLmt", c_float),
        ("m_Force_Cmd", c_float),
        ("m_SET_Tags", c_ubyte * 16),
        ("m_Update_Tags", c_ubyte * 16),
        ("m_PvtID", c_ubyte),
        ("m_PvtID_Update", c_ubyte),
        ("m_Pvt_RunID", c_ubyte),
        ("m_Pvt_RunState", c_ubyte),
    ]


class DCSS(Structure):
    """``DCSS`` — top-level data container.  Field order matches ``FxRtCSDef.h``."""

    _fields_ = [
        ("m_State", RT_STATE * 2),
        ("m_In", RT_IN * 2),
        ("m_Out", RT_OUT * 2),
        ("m_ParaName", c_char * 30),
        ("m_ParaType", c_ubyte),
        ("m_ParaIns", c_ubyte),
        ("m_ParaValueI", c_int32),
        ("m_ParaValueF", c_float),
        ("m_ParaCmdSerial", c_short),
        ("m_ParaRetSerial", c_short),
    ]


# ---------------------------------------------------------------------------
# FTCmd structure
# ---------------------------------------------------------------------------


class FTCmd(Structure):
    _fields_ = [
        ("fxDir", c_double * 6),
        ("K", c_double),
        ("F", c_double),
        ("FreeDis", c_double),
        ("Dis", c_double),
        ("Kn", c_double),
        ("Tn", c_double),
        ("NFreeDis", c_double),
        ("Ndis", c_double),
    ]


# ---------------------------------------------------------------------------
# Kinematics structures
# ---------------------------------------------------------------------------


class Vect7(Structure):
    _fields_ = [("data", FX_DOUBLE * 7)]

    def to_list(self):
        return [self.data[i] for i in range(7)]


class Matrix4(Structure):
    _fields_ = [("data", FX_DOUBLE * 16)]

    def to_list(self):
        return [self.data[i] for i in range(16)]


class Matrix8(Structure):
    _fields_ = [("data", FX_DOUBLE * 64)]

    def to_list(self):
        return [self.data[i] for i in range(64)]


class FX_InvKineSolvePara(Structure):
    _fields_ = [
        ("m_Input_IK_TargetTCP", Matrix4),
        ("m_Input_IK_RefJoint", Vect7),
        ("m_Input_IK_ZSPType", FX_INT32L),
        ("m_Input_IK_ZSPPara", FX_DOUBLE * 6),
        ("m_Input_ZSP_Angle", FX_DOUBLE),
        ("m_DGR1", FX_DOUBLE),
        ("m_DGR2", FX_DOUBLE),
        ("m_DGR3", FX_DOUBLE),
        ("m_Output_RetJoint", Vect7),
        ("m_OutPut_AllJoint", Matrix8),
        ("m_OutPut_Result_Num", FX_INT32L),
        ("m_Output_IsOutRange", FX_BOOL),
        ("m_Output_IsDeg", FX_BOOL * 7),
        ("m_Output_JntExdTags", FX_BOOL * 7),
        ("m_Output_JntExdABS", FX_DOUBLE),
        ("m_Output_IsJntExd", FX_BOOL),
        ("m_Output_RunLmtP", Vect7),
        ("m_Output_RunLmtN", Vect7),
    ]


class FX_Jacobi(Structure):
    _fields_ = [
        ("m_AxisNum", FX_INT32L),
        ("m_Jcb", (FX_DOUBLE * 7) * 6),
    ]


# ---------------------------------------------------------------------------
# DCSS → dict conversion
# ---------------------------------------------------------------------------


def structure2dict(dcss: DCSS) -> dict:
    """Convert a filled ``DCSS`` struct to a plain Python dict.

    This is the **only** place where native struct layout leaks into
    Python types.  All public APIs consume the result through models.
    """
    result: dict = {
        "para_name": ["Marvin_sub_data"],
        "states": [
            {
                "cur_state": dcss.m_State[0].m_CurState,
                "cmd_state": dcss.m_State[0].m_CmdState,
                "err_code": dcss.m_State[0].m_ERRCode,
            },
            {
                "cur_state": dcss.m_State[1].m_CurState,
                "cmd_state": dcss.m_State[1].m_CmdState,
                "err_code": dcss.m_State[1].m_ERRCode,
            },
        ],
    }

    result["outputs"] = [
        {
            "frame_serial": rt.m_OutFrameSerial,
            "tip_di": [rt.m_TipDI],
            "low_speed_flag": [rt.m_LowSpdFlag],
            "fb_joint_pos": [round(rt.m_FB_Joint_Pos[j], 4) for j in range(7)],
            "fb_joint_vel": [round(rt.m_FB_Joint_Vel[j], 4) for j in range(7)],
            "fb_joint_posE": [round(rt.m_FB_Joint_PosE[j], 4) for j in range(7)],
            "fb_joint_cmd": [round(rt.m_FB_Joint_Cmd[j], 4) for j in range(7)],
            "fb_joint_cToq": [round(rt.m_FB_Joint_CToq[j], 4) for j in range(7)],
            "fb_joint_sToq": [round(rt.m_FB_Joint_SToq[j], 4) for j in range(7)],
            "fb_joint_them": [round(rt.m_FB_Joint_Them[j], 4) for j in range(7)],
            "est_joint_firc": [round(rt.m_EST_Joint_Firc[j], 4) for j in range(7)],
            "est_joint_firc_dot": [round(rt.m_EST_Joint_Firc_Dot[j], 4) for j in range(7)],
            "est_joint_force": [round(rt.m_EST_Joint_Force[j], 4) for j in range(7)],
            "est_cart_fn": [round(rt.m_EST_Cart_FN[j], 4) for j in range(6)],
        }
        for rt in dcss.m_Out
    ]

    result["inputs"] = [
        {
            "rt_in_switch": ri.m_RtInSwitch,
            "imp_type": ri.m_ImpType,
            "in_frame_serial": ri.m_InFrameSerial,
            "frame_miss_cnt": ri.m_FrameMissCnt,
            "max_frame_miss_cnt": ri.m_MaxFrameMissCnt,
            "sys_cyc": ri.m_SysCyc,
            "sys_cyc_miss_cnt": ri.m_SysCycMissCnt,
            "max_sys_cyc_miss_cnt": ri.m_MaxSysCycMissCnt,
            "tool_kine": [round(ri.m_ToolKine[j], 4) for j in range(6)],
            "tool_dyn": [round(ri.m_ToolDyn[j], 4) for j in range(10)],
            "joint_cmd_pos": [round(ri.m_Joint_CMD_Pos[j], 4) for j in range(7)],
            "joint_vel_ratio": ri.m_Joint_Vel_Ratio,
            "joint_acc_ratio": ri.m_Joint_Acc_Ratio,
            "joint_k": [round(ri.m_Joint_K[j], 4) for j in range(7)],
            "joint_d": [round(ri.m_Joint_D[j], 4) for j in range(7)],
            "drag_sp_type": ri.m_DragSpType,
            "drag_sp_para": [round(ri.m_DragSpPara[j], 4) for j in range(6)],
            "cart_kd_type": ri.m_Cart_KD_Type,
            "cart_k": [round(ri.m_Cart_K[j], 4) for j in range(6)],
            "cart_d": [round(ri.m_Cart_D[j], 4) for j in range(6)],
            "cart_kn": round(ri.m_Cart_KN, 4),
            "cart_dn": round(ri.m_Cart_DN, 4),
            "force_fb_type": ri.m_Force_FB_Type,
            "force_type": ri.m_Force_Type,
            "force_dir": [round(ri.m_Force_Dir[j], 4) for j in range(6)],
            "force_pidul": [round(ri.m_Force_PIDUL[j], 4) for j in range(7)],
            "force_adj_lmt": round(ri.m_Force_AdjLmt, 4),
            "force_cmd": round(ri.m_Force_Cmd, 4),
            "set_tags": list(ri.m_SET_Tags),
            "update_tags": list(ri.m_Update_Tags),
            "pvt_id": ri.m_PvtID,
            "pvt_id_update": ri.m_PvtID_Update,
            "pvt_run_id": ri.m_Pvt_RunID,
            "pvt_run_state": ri.m_Pvt_RunState,
        }
        for ri in dcss.m_In
    ]

    result["ParaName"] = [dcss.m_ParaName]
    result["ParaType"] = [dcss.m_ParaType]
    result["ParaIns"] = [dcss.m_ParaIns]
    result["ParaValueI"] = [dcss.m_ParaValueI]
    result["ParaValueF"] = [dcss.m_ParaValueF]
    result["ParaCmdSerial"] = [dcss.m_ParaCmdSerial]
    result["ParaRetSerial"] = [dcss.m_ParaRetSerial]

    return result


# ---------------------------------------------------------------------------
# Dynamic library loaders
# ---------------------------------------------------------------------------


def load_robot_library() -> ctypes.CDLL:
    """Load the ``libMarvinSDK`` shared library for the current platform."""
    if _IS_WINDOWS:
        path = _sdk_path("libMarvinSDK.dll")
    else:
        path = _sdk_path("libMarvinSDK.so")

    if not os.path.isfile(path):
        raise FileNotFoundError(
            f"Native robot library not found at {path}. "
            f"Expected platform: {'Windows' if _IS_WINDOWS else 'Linux'}"
        )
    return ctypes.CDLL(path)


def load_kinematics_library() -> ctypes.CDLL:
    """Load the ``libKine`` shared library for the current platform."""
    if _IS_WINDOWS:
        path = _sdk_path("libKine.dll")
    else:
        path = _sdk_path("libKine.so")

    if not os.path.isfile(path):
        raise FileNotFoundError(
            f"Native kinematics library not found at {path}. "
            f"Expected platform: {'Windows' if _IS_WINDOWS else 'Linux'}"
        )
    return ctypes.CDLL(path)
