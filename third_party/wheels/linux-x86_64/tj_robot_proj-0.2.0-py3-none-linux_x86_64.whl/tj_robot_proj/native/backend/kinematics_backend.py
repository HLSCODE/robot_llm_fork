"""Thin wrapper around the native ``libKine`` kinematics library.

All unit conversions (mm ↔ m, deg ↔ rad) are handled at this boundary.
Public callers only see metres and degrees.
"""

from __future__ import annotations

import ctypes
import logging
from ctypes import (
    POINTER,
    byref,
    c_bool,
    c_char,
    c_char_p,
    c_double,
    c_int,
    c_int32,
    c_void_p,
)

from tj_robot_proj.native.backend.bindings import (
    FX_DOUBLE,
    FX_INT32L,
    FX_InvKineSolvePara,
    FX_Jacobi,
    load_kinematics_library,
)

logger = logging.getLogger(__name__)


class KinematicsBackend:
    """Wraps the ``libKine`` native library.

    One instance per ``NativeSession``.  The kinematics library requires
    initialisation with robot-type configuration before FK/IK/planning.
    """

    def __init__(self) -> None:
        self._lib = load_kinematics_library()
        self._robot_tag: int | None = None
        self._initialised = False
        self._setup_prototypes()

    # ------------------------------------------------------------------
    # Function prototypes (set once)
    # ------------------------------------------------------------------

    def _setup_prototypes(self) -> None:
        lib = self._lib

        # Point set
        lib.FX_CPointSet_Create.argtypes = []
        lib.FX_CPointSet_Create.restype = c_void_p

        lib.FX_CPointSet_Destroy.argtypes = [c_void_p]
        lib.FX_CPointSet_Destroy.restype = None

        lib.FX_CPointSet_OnInit.argtypes = [c_void_p, c_int32]
        lib.FX_CPointSet_OnInit.restype = c_bool

        lib.FX_CPointSet_OnGetPointNum.argtypes = [c_void_p]
        lib.FX_CPointSet_OnGetPointNum.restype = c_int32

        lib.FX_CPointSet_OnGetPoint.argtypes = [c_void_p, c_int32]
        lib.FX_CPointSet_OnGetPoint.restype = POINTER(c_double)

        # MOVLA
        lib.FX_Robot_PLN_MOVLA_C.argtypes = [
            c_int32,
            POINTER(c_double),
            POINTER(c_double),
            POINTER(c_double),
            c_double,
            c_double,
            c_int32,
            c_void_p,
        ]
        lib.FX_Robot_PLN_MOVLA_C.restype = c_bool

        # MOV_KeepJ
        lib.FX_Robot_PLN_MOVL_KeepJA_C.argtypes = [
            c_int32,
            POINTER(c_double),
            POINTER(c_double),
            c_double,
            c_double,
            c_int32,
            c_void_p,
        ]
        lib.FX_Robot_PLN_MOVL_KeepJA_C.restype = c_bool

        # MOV_Target
        lib.FX_Robot_PLN_MOV_Target_C.argtypes = [
            c_int32,
            POINTER(c_double),
            POINTER(c_double),
            POINTER(c_double),
            c_double,
            c_double,
            c_int32,
            c_void_p,
        ]
        lib.FX_Robot_PLN_MOV_Target_C.restype = c_bool

        # Log switch
        lib.FX_LOG_SWITCH.argtypes = [c_int32]

        # Config loader
        lib.LOADMvCfg.argtypes = [
            c_char_p,
            POINTER(c_int32 * 2),
            POINTER((c_double * 3) * 2),
            POINTER(((c_double * 4) * 8) * 2),
            POINTER(((c_double * 4) * 7) * 2),
            POINTER(((c_double * 3) * 4) * 2),
            POINTER((c_double * 7) * 2),
            POINTER(((c_double * 3) * 7) * 2),
            POINTER(((c_double * 6) * 7) * 2),
        ]
        lib.LOADMvCfg.restype = c_bool

        # Init
        lib.FX_Robot_Init_Type.argtypes = [c_int32, c_int32]
        lib.FX_Robot_Init_Type.restype = c_bool
        lib.FX_Robot_Init_Kine.argtypes = [c_int32, (c_double * 4) * 8]
        lib.FX_Robot_Init_Kine.restype = c_bool
        lib.FX_Robot_Init_Lmt.argtypes = [c_int32, (c_double * 4) * 7, (c_double * 3) * 4]
        lib.FX_Robot_Init_Lmt.restype = c_bool

        # FK
        lib.FX_Robot_Kine_FK.argtypes = [
            c_int32,
            POINTER(c_double * 7),
            POINTER((c_double * 4) * 4),
        ]
        lib.FX_Robot_Kine_FK.restype = c_bool

        # IK
        lib.FX_Robot_Kine_IK.argtypes = [c_int32, POINTER(FX_InvKineSolvePara)]
        lib.FX_Robot_Kine_IK.restype = c_bool

        # Matrix ↔ xyzabc
        lib.FX_Matrix42XYZABCDEG.argtypes = [(c_double * 4) * 4, c_double * 6]
        lib.FX_Matrix42XYZABCDEG.restype = c_bool

        lib.FX_XYZABC2Matrix4DEG.argtypes = [
            POINTER(c_double * 6),
            POINTER((c_double * 4) * 4),
        ]

        # Jacobian
        lib.FX_Robot_Kine_Jacb.argtypes = [
            c_int32,
            c_double * 7,
            POINTER(FX_Jacobi),
        ]
        lib.FX_Robot_Kine_Jacb.restype = c_bool

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def log_switch(self, on: int) -> None:
        self._lib.FX_LOG_SWITCH(c_int32(on))

    def load_config(self, arm_type: int, config_path: str) -> dict | None:
        """Load a ``.MvKDCfg`` file.  Returns the parsed config dict or None."""
        self._robot_tag = arm_type

        TYPE = (c_int32 * 2)()
        GRV = ((c_double * 3) * 2)()
        DH = (((c_double * 4) * 8) * 2)()
        PNVA = (((c_double * 4) * 7) * 2)()
        BD = (((c_double * 3) * 4) * 2)()
        Mass = ((c_double * 7) * 2)()
        MCP = (((c_double * 3) * 7) * 2)()
        I = (((c_double * 6) * 7) * 2)()

        ok = self._lib.LOADMvCfg(
            config_path.encode("utf-8"),
            byref(TYPE),
            byref(GRV),
            byref(DH),
            byref(PNVA),
            byref(BD),
            byref(Mass),
            byref(MCP),
            byref(I),
        )
        if not ok:
            return None

        return {
            "TYPE": [TYPE[i] for i in range(2)],
            "GRV": [[GRV[i][j] for j in range(3)] for i in range(2)],
            "DH": [[[DH[i][j][k] for k in range(4)] for j in range(8)] for i in range(2)],
            "PNVA": [[[PNVA[i][j][k] for k in range(4)] for j in range(7)] for i in range(2)],
            "BD": [[[BD[i][j][k] for k in range(3)] for j in range(4)] for i in range(2)],
            "Mass": [[Mass[i][j] for j in range(7)] for i in range(2)],
            "MCP": [[[MCP[i][j][k] for k in range(3)] for j in range(7)] for i in range(2)],
            "I": [[[I[i][j][k] for k in range(6)] for j in range(7)] for i in range(2)],
        }

    def initial_kine(
        self,
        robot_type: int,
        dh: list,
        pnva: list,
        j67: list,
    ) -> bool:
        """Initialize kinematics with loaded configuration data."""
        serial = c_int32(self._robot_tag)
        robot_type_c = c_int32(robot_type)

        DH = ((c_double * 4) * 8)()
        for i in range(8):
            for j in range(4):
                DH[i][j] = dh[i][j]

        PNVA = ((c_double * 4) * 7)()
        for i in range(7):
            for j in range(4):
                PNVA[i][j] = pnva[i][j]

        J67 = ((c_double * 3) * 4)()
        for i in range(4):
            for j in range(3):
                J67[i][j] = j67[i][j]

        ok1 = self._lib.FX_Robot_Init_Type(serial, robot_type_c)
        ok2 = self._lib.FX_Robot_Init_Kine(serial, DH)
        ok3 = self._lib.FX_Robot_Init_Lmt(serial, PNVA, J67)
        self._initialised = bool(ok1 and ok2 and ok3)
        return self._initialised

    @property
    def initialised(self) -> bool:
        return self._initialised

    # ------------------------------------------------------------------
    # Forward / Inverse Kinematics
    # ------------------------------------------------------------------

    def fk(self, joints_deg: list[float]) -> list[list[float]] | None:
        """Forward kinematics.  Joints in degrees → 4x4 matrix (mm)."""
        if len(joints_deg) != 7:
            raise ValueError("joints_deg must have 7 elements")

        serial = c_int32(self._robot_tag)
        joints = (c_double * 7)(*joints_deg)
        pg = ((c_double * 4) * 4)()
        for i in range(4):
            for j in range(4):
                pg[i][j] = 1.0 if i == j else 0.0

        ok = self._lib.FX_Robot_Kine_FK(serial, byref(joints), byref(pg))
        if not ok:
            return None

        return [[pg[i][j] for j in range(4)] for i in range(4)]

    def fk_nsp(self, joints_deg: list[float]) -> tuple[list[list[float]], list[list[float]]] | None:
        """FK with null-space parameters.  Returns (mat4x4, nsp_mat3x3)."""
        if len(joints_deg) != 7:
            raise ValueError("joints_deg must have 7 elements")

        serial = c_int32(self._robot_tag)
        joints = (c_double * 7)(*joints_deg)
        pg = ((c_double * 4) * 4)()
        nspg = ((c_double * 3) * 3)()

        ok = self._lib.FX_Robot_Kine_FK_NSP(
            serial, byref(joints), byref(pg), byref(nspg)
        )
        if not ok:
            return None

        mat4 = [[pg[i][j] for j in range(4)] for i in range(4)]
        nsp3 = [[nspg[i][j] for j in range(3)] for i in range(3)]
        return mat4, nsp3

    # ------------------------------------------------------------------
    # Matrix ↔ xyzabc conversion
    # ------------------------------------------------------------------

    def mat4x4_to_xyzabc(self, pose_mat: list[list[float]]) -> list[float]:
        """4x4 homogeneous matrix → [x, y, z, a, b, c] (mm, deg)."""
        arr = ((c_double * 4) * 4)()
        for i in range(4):
            for j in range(4):
                arr[i][j] = pose_mat[i][j]

        xyzabc = (c_double * 6)(0, 0, 0, 0, 0, 0)
        ok = self._lib.FX_Matrix42XYZABCDEG(arr, xyzabc)
        if not ok:
            raise RuntimeError("mat4x4_to_xyzabc failed")
        return [xyzabc[i] for i in range(6)]

    def xyzabc_to_mat4x4(self, xyzabc: list[float]) -> list[list[float]]:
        """[x, y, z, a, b, c] (mm, deg) → 4x4 homogeneous matrix."""
        arr = (c_double * 6)(*xyzabc)
        pg = ((c_double * 4) * 4)()
        for i in range(4):
            for j in range(4):
                pg[i][j] = 1.0 if i == j else 0.0

        self._lib.FX_XYZABC2Matrix4DEG(byref(arr), byref(pg))
        return [[pg[i][j] for j in range(4)] for i in range(4)]

    # ------------------------------------------------------------------
    # Jacobian
    # ------------------------------------------------------------------

    def joints_to_jacobian(self, joints_deg: list[float]) -> list[list[float]] | None:
        """Compute 6×7 Jacobian matrix at the given joint configuration."""
        joints = (c_double * 7)(*joints_deg)
        jacobi = FX_Jacobi()
        ok = self._lib.FX_Robot_Kine_Jacb(
            c_int32(self._robot_tag), joints, byref(jacobi)
        )
        if not ok:
            return None
        return [[jacobi.m_Jcb[i][j] for j in range(7)] for i in range(6)]

    # ------------------------------------------------------------------
    # Point-set management
    # ------------------------------------------------------------------

    def create_point_set(self, dimension: int = 7) -> c_void_p:
        pset = self._lib.FX_CPointSet_Create()
        if pset:
            self._lib.FX_CPointSet_OnInit(pset, c_int32(dimension))
        return pset

    def destroy_point_set(self, pset: c_void_p) -> None:
        if pset:
            self._lib.FX_CPointSet_Destroy(pset)

    def get_point_set_data(
        self, pset: c_void_p, dimension: int = 7
    ) -> list[list[float]]:
        if not pset:
            return []
        n = self._lib.FX_CPointSet_OnGetPointNum(pset)
        data: list[list[float]] = []
        for i in range(n):
            ptr = self._lib.FX_CPointSet_OnGetPoint(pset, i)
            if ptr:
                data.append([ptr[j] for j in range(dimension)])
        return data

    # ------------------------------------------------------------------
    # Linear planning (MOVLA)
    # ------------------------------------------------------------------

    def plan_linear(
        self,
        start_xyzabc: list[float],  # mm, deg
        end_xyzabc: list[float],    # mm, deg
        ref_joints: list[float],    # deg
        vel: float,                 # mm/s
        acc: float,                 # mm/s²
        freq_hz: int = 100,
        dimension: int = 7,
    ) -> tuple[list[list[float]], c_void_p]:
        """Plan a Cartesian linear trajectory → (point_list, pset_ptr)."""
        serial = c_int32(self._robot_tag)
        freq = c_int32(freq_hz)

        start = (c_double * 6)(*start_xyzabc)
        end = (c_double * 6)(*end_xyzabc)
        ref = (c_double * 7)(*ref_joints)
        vel_c = c_double(vel)
        acc_c = c_double(acc)

        pset = self.create_point_set(dimension)
        if not pset:
            raise RuntimeError("Failed to create CPointSet")

        try:
            ok = self._lib.FX_Robot_PLN_MOVLA_C(
                serial, start, end, ref, vel_c, acc_c, freq, pset
            )
            if not ok:
                self.destroy_point_set(pset)
                return [], None
            data = self.get_point_set_data(pset, dimension)
            return data, pset
        except Exception:
            self.destroy_point_set(pset)
            raise

    def plan_linear_keep_j(
        self,
        start_joints: list[float],  # deg
        end_joints: list[float],    # deg
        vel: float,                 # mm/s
        acc: float,                 # mm/s²
        freq_hz: int = 100,
        dimension: int = 7,
    ) -> tuple[list[list[float]], c_void_p]:
        """Plan a Cartesian linear trajectory keeping joint configuration."""
        serial = c_int32(self._robot_tag)
        freq = c_int32(freq_hz)

        start = (c_double * 7)(*start_joints)
        end = (c_double * 7)(*end_joints)
        vel_c = c_double(vel)
        acc_c = c_double(acc)

        pset = self.create_point_set(dimension)
        if not pset:
            raise RuntimeError("Failed to create CPointSet")

        try:
            ok = self._lib.FX_Robot_PLN_MOVL_KeepJA_C(
                serial, start, end, vel_c, acc_c, freq, pset
            )
            if not ok:
                self.destroy_point_set(pset)
                return [], None
            data = self.get_point_set_data(pset, dimension)
            return data, pset
        except Exception:
            self.destroy_point_set(pset)
            raise

    def plan_move_target(
        self,
        start_xyzabc: list[float],  # mm, deg
        end_xyzabc: list[float],    # mm, deg
        ref_joints: list[float],    # deg
        vel: float,                 # mm/s
        acc: float,                 # mm/s²
        freq_hz: int = 100,
        dimension: int = 7,
    ) -> tuple[list[list[float]], c_void_p]:
        """Point-to-point planning (linear first, joint as fallback)."""
        serial = c_int32(self._robot_tag)
        freq = c_int32(freq_hz)

        start = (c_double * 6)(*start_xyzabc)
        end = (c_double * 6)(*end_xyzabc)
        ref = (c_double * 7)(*ref_joints)
        vel_c = c_double(vel)
        acc_c = c_double(acc)

        pset = self.create_point_set(dimension)
        if not pset:
            raise RuntimeError("Failed to create CPointSet")

        try:
            ok = self._lib.FX_Robot_PLN_MOV_Target_C(
                serial, start, end, ref, vel_c, acc_c, freq, pset
            )
            if not ok:
                self.destroy_point_set(pset)
                return [], None
            data = self.get_point_set_data(pset, dimension)
            return data, pset
        except Exception:
            self.destroy_point_set(pset)
            raise
