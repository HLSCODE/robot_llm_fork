"""Context-managed native resource wrappers (point sets, trajectories)."""

from __future__ import annotations

import ctypes
import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tj_robot_proj.native.backend.kinematics_backend import KinematicsBackend

logger = logging.getLogger(__name__)


class PointSet:
    """RAII wrapper around a native ``CPointSet``.

    Owns the native memory; ``destroy_point_set`` is called on
    ``close()`` or context-manager exit.  Idempotent close.
    """

    def __init__(
        self,
        pset: ctypes.c_void_p,
        kinematics: KinematicsBackend,
    ) -> None:
        self._pset = pset
        self._kinematics = kinematics
        self._closed = False

    @property
    def ptr(self) -> ctypes.c_void_p:
        if self._closed:
            raise RuntimeError("PointSet has been closed")
        return self._pset

    @property
    def closed(self) -> bool:
        return self._closed

    def close(self) -> None:
        if self._closed:
            return
        if self._pset is not None:
            self._kinematics.destroy_point_set(self._pset)
            self._pset = None
        self._closed = True

    def __enter__(self) -> "PointSet":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def __del__(self) -> None:
        if not self._closed and self._pset is not None:
            logger.warning(
                "PointSet not explicitly closed; releasing in __del__. "
                "This is unreliable — use a context manager."
            )
            self.close()


class TrajectoryResource:
    """Owns a ``PointSet`` produced by a kinematic planning operation.

    Created by ``KinematicsBackend.plan_linear()`` and friends.
    The trajectory must be passed to ``session.execute_trajectory()``
    before being closed — the session takes ownership during execution.
    """

    def __init__(
        self,
        points: list[list[float]],
        point_set: PointSet,
    ) -> None:
        self.points = points
        self._point_set = point_set

    @property
    def point_count(self) -> int:
        return len(self.points)

    @property
    def pset_ptr(self) -> ctypes.c_void_p:
        return self._point_set.ptr

    def close(self) -> None:
        """Release the underlying native point set."""
        self._point_set.close()

    def __enter__(self) -> "TrajectoryResource":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def __del__(self) -> None:
        self._point_set.close()
