"""Thin wrapper around the native ``libMarvinSDK`` robot-control functions.

All public methods return typed results (no raw ctypes structures escape).
Unit conversions (mm ↔ m, deg ↔ rad) are handled at this boundary.
"""

from __future__ import annotations

import ctypes
import logging
from ctypes import (
    POINTER,
    byref,
    c_bool,
    c_char,
    c_char_p,
    c_double,
    c_int,
    c_int32,
    c_long,
    c_ubyte,
    c_void_p,
)

from tj_robot_proj.native.backend.bindings import (
    DCSS,
    FX_DOUBLE,
    FX_INT32L,
    FTCmd,
    load_robot_library,
    structure2dict,
)

logger = logging.getLogger(__name__)


def _convert_ip(ip_str: str) -> tuple[int, int, int, int]:
    """Convert an IPv4 string to four ubyte integers."""
    parts = ip_str.split(".")
    if len(parts) != 4:
        raise ValueError(f"Invalid IP: {ip_str!r}")
    return tuple(int(p) for p in parts)


class RobotBackend:
    """Wraps the ``libMarvinSDK`` native library.

    One instance per ``NativeSession``.  Not thread-safe on its own — the
    session's lock must be held when calling any method that touches the
    controller.
    """

    def __init__(self) -> None:
        self._lib = load_robot_library()
        self._connected = False

    # ------------------------------------------------------------------
    # Connection
    # ------------------------------------------------------------------

    def connect(self, ip: str) -> bool:
        ip1, ip2, ip3, ip4 = _convert_ip(ip)
        result = self._lib.OnLinkTo(
            c_ubyte(ip1), c_ubyte(ip2), c_ubyte(ip3), c_ubyte(ip4)
        )
        self._connected = bool(result)
        return self._connected

    def release(self) -> bool:
        self._connected = False
        return bool(self._lib.OnRelease())

    @property
    def connected(self) -> bool:
        return self._connected

    # ------------------------------------------------------------------
    # Subscribe
    # ------------------------------------------------------------------

    def subscribe(self, dcss: DCSS) -> dict:
        """Fill the DCSS struct from the controller and return a dict."""
        self._lib.OnGetBuf(byref(dcss))
        return structure2dict(dcss)

    # ------------------------------------------------------------------
    # Command pipeline
    # ------------------------------------------------------------------

    def clear_set(self) -> bool:
        return bool(self._lib.OnClearSet())

    def send_cmd(self) -> bool:
        return bool(self._lib.OnSetSend())

    def send_cmd_wait_response(self, timeout_ms: int = 50) -> bool:
        self._lib.OnSetSendWaitResponse.restype = c_long
        rc = self._lib.OnSetSendWaitResponse(c_long(timeout_ms))
        return rc > 0

    # ------------------------------------------------------------------
    # Error handling
    # ------------------------------------------------------------------

    def clear_error(self, arm: str) -> bool:
        if arm == "A":
            return bool(self._lib.OnClearErr_A())
        elif arm == "B":
            return bool(self._lib.OnClearErr_B())
        return False

    def soft_stop(self, arm: str) -> bool:
        if arm == "A":
            return bool(self._lib.OnEMG_A())
        elif arm == "B":
            return bool(self._lib.OnEMG_B())
        elif arm == "AB":
            return bool(self._lib.OnEMG_AB())
        return False

    def get_servo_error_code(self, arm: str) -> list[int]:
        buf = (c_long * 7)()
        if arm == "A":
            self._lib.OnGetServoErr_A.argtypes = [POINTER(c_long * 7)]
            self._lib.OnGetServoErr_A(byref(buf))
        elif arm == "B":
            self._lib.OnGetServoErr_B.argtypes = [POINTER(c_long * 7)]
            self._lib.OnGetServoErr_B(byref(buf))
        return [buf[i] for i in range(7)]

    # ------------------------------------------------------------------
    # State / mode control
    # ------------------------------------------------------------------

    def set_state(self, arm: str, state: int) -> bool:
        state_int = c_int(state)
        if arm == "A":
            return bool(self._lib.OnSetTargetState_A(state_int))
        elif arm == "B":
            return bool(self._lib.OnSetTargetState_B(state_int))
        return False

    def set_vel_acc(self, arm: str, vel_ratio: int, acc_ratio: int) -> bool:
        v = c_int(vel_ratio)
        a = c_int(acc_ratio)
        if arm == "A":
            return bool(self._lib.OnSetJointLmt_A(v, a))
        elif arm == "B":
            return bool(self._lib.OnSetJointLmt_B(v, a))
        return False

    def set_impedance_type(self, arm: str, imp_type: int) -> bool:
        t = c_int(imp_type)
        if arm == "A":
            return bool(self._lib.OnSetImpType_A(t))
        elif arm == "B":
            return bool(self._lib.OnSetImpType_B(t))
        return False

    # ------------------------------------------------------------------
    # Joint / Cartesian commands
    # ------------------------------------------------------------------

    def set_joint_cmd_pose(self, arm: str, joints_deg: list[float]) -> bool:
        arr = (c_double * 7)(*joints_deg)
        if arm == "A":
            return bool(self._lib.OnSetJointCmdPos_A(arr))
        elif arm == "B":
            return bool(self._lib.OnSetJointCmdPos_B(arr))
        return False

    def set_joint_kd_params(
        self, arm: str, k: list[float], d: list[float]
    ) -> bool:
        kv = (c_double * 7)(*k)
        dv = (c_double * 7)(*d)
        if arm == "A":
            return bool(self._lib.OnSetJointKD_A(kv, dv))
        elif arm == "B":
            return bool(self._lib.OnSetJointKD_B(kv, dv))
        return False

    # ------------------------------------------------------------------
    # Planned motion
    # ------------------------------------------------------------------

    def set_pln_cart(self, arm: str, pset: c_void_p) -> bool:
        if arm == "A":
            self._lib.OnSetPlnCart_A.argtypes = [c_void_p]
            self._lib.OnSetPlnCart_A.restype = c_bool
            return bool(self._lib.OnSetPlnCart_A(pset))
        elif arm == "B":
            self._lib.OnSetPlnCart_B.argtypes = [c_void_p]
            self._lib.OnSetPlnCart_B.restype = c_bool
            return bool(self._lib.OnSetPlnCart_B(pset))
        return False

    def stop_pln_joint(self, arm: str) -> bool:
        if arm == "A":
            return bool(self._lib.OnStopPlnJoint_A())
        elif arm == "B":
            return bool(self._lib.OnStopPlnJoint_B())
        return False

    # ------------------------------------------------------------------
    # Drag teaching
    # ------------------------------------------------------------------

    def set_drag_space(self, arm: str, drag_type: int) -> bool:
        t = c_int(drag_type)
        if arm == "A":
            return bool(self._lib.OnSetDragSpace_A(t))
        elif arm == "B":
            return bool(self._lib.OnSetDragSpace_B(t))
        return False

    # ------------------------------------------------------------------
    # Data collection
    # ------------------------------------------------------------------

    def collect_data(
        self, target_num: int, target_id: list[int], record_num: int
    ) -> bool:
        tid = (c_long * len(target_id))(*target_id)
        return bool(
            self._lib.OnStartGather(
                c_int(target_num), tid, c_int(record_num)
            )
        )

    def stop_collect_data(self) -> bool:
        return bool(self._lib.OnStopGather())

    def save_collected_data(self, path: str) -> bool:
        return bool(self._lib.OnSaveGatherData(c_char_p(path.encode("utf-8"))))

    # ------------------------------------------------------------------
    # PVT
    # ------------------------------------------------------------------

    def send_pvt_file(self, arm: str, path: str, pvt_id: int) -> bool:
        if arm == "A":
            return bool(
                self._lib.OnSendPVT_A(
                    c_char_p(path.encode("utf-8")), c_int(pvt_id)
                )
            )
        elif arm == "B":
            return bool(
                self._lib.OnSendPVT_B(
                    c_char_p(path.encode("utf-8")), c_int(pvt_id)
                )
            )
        return False

    def set_pvt_id(self, arm: str, pvt_id: int) -> bool:
        if arm == "A":
            return bool(self._lib.OnSetPVT_A(c_int(pvt_id)))
        elif arm == "B":
            return bool(self._lib.OnSetPVT_B(c_int(pvt_id)))
        return False

    # ------------------------------------------------------------------
    # Logging
    # ------------------------------------------------------------------

    def log_switch(self, on: bool) -> None:
        if on:
            self._lib.OnLogOn()
        else:
            self._lib.OnLogOff()

    def local_log_switch(self, on: bool) -> None:
        if on:
            self._lib.OnLocalLogOn()
        else:
            self._lib.OnLocalLogOff()

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------

    def sdk_version(self) -> int:
        return int(self._lib.OnGetSDKVersion())

