"""``NativeSession`` — sole owner of native SDK instances, connection, lock, and lifecycle.

One ``RobotClient`` → one ``NativeSession``.
"""

from __future__ import annotations

from contextlib import ExitStack
from datetime import datetime
import logging
import os
from pathlib import Path
import shutil
import tempfile
import threading
import time
from typing import Callable
import copy

import numpy as np

from tj_robot_proj.native.backend.bindings import DCSS
from tj_robot_proj.native.backend.kinematics_backend import KinematicsBackend
from tj_robot_proj.native.backend.resources import PointSet, TrajectoryResource
from tj_robot_proj.native.backend.robot_backend import RobotBackend
from tj_robot_proj.native.txt2fmv_tranformer import convert_file, option_supports_fmv
from tj_robot_proj.errors import (
    ClosedSessionError,
    CommunicationError,
    ConfigurationError,
    ConnectionError,
    InitializationError,
    KinematicsError,
    NativeLibraryError,
)

from tj_robot_proj.value_objects import *

logger = logging.getLogger(__name__)

_TEMP_DATA_DIR = Path(__file__).resolve().parents[3] / "temp_data"


class NativeSession:
    """Owns the native SDK, connection, lock, subscription thread, and point sets.

    All public methods that touch native state hold ``self._lock``.
    The subscription thread is the **only** background thread — every sample
    is cached in ``_sub_data_raw`` (guarded by ``_sub_data_raw_lock``) and,
    when a callback was supplied, pushed to it.  Read the cache with
    ``get_sub_data_raw()``.
    """

    def __init__(self, config: RobotConfig) -> None:
        self._config = config
        self._robot: RobotBackend | None = None
        self._kinematics: KinematicsBackend | None = None
        self._dcss: DCSS | None = None

        # Connection & lifecycle
        self._lock = threading.Lock()
        self._closed = False
        self._connected = False
        self._initialised = False

        # State subscription
        self._sub_thread: threading.Thread | None = None
        self._sub_stop_event = threading.Event()
        # Latest raw sample cached by the subscription thread
        self._sub_data_raw: dict | None = None
        self._sub_data_raw_lock = threading.Lock()

        # Active motion point sets (held until motion completes)
        self._active_point_sets: list[PointSet] = []

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def connect(self) -> None:
        """Load native libraries and connect to the controller."""
        with self._lock:
            self._check_closed()
            if self._connected:
                return

            try:
                self._robot = RobotBackend()
                self._kinematics = KinematicsBackend()
            except FileNotFoundError as exc:
                raise NativeLibraryError(
                    str(exc), operation="connect"
                ) from exc

            self._dcss = DCSS()

            ok = self._robot.connect(self._config.controller_ip)
            if not ok:
                raise ConnectionError(
                    f"Failed to connect to {self._config.controller_ip}",
                    operation="connect",
                )

            # Logging must be configured *after* OnLinkTo — the native
            # OnLogOff/OnLogOn path dereferences the robot instance that
            # OnLinkTo initialises (segfault otherwise).
            self._robot.log_switch(False)
            self._robot.local_log_switch(False)
            self._connected = True
            logger.info("Connected to %s", self._config.controller_ip)

    def initialize(self) -> None:
        """Clear errors, set position mode, and init kinematics."""
        with self._lock:
            self._check_closed()
            if not self._connected or self._robot is None:
                raise InitializationError(
                    "Must connect() before initialize()",
                    operation="initialize",
                )

            try:
                # Flush / clear errors
                time.sleep(0.05)
                self._robot.clear_set()
                self._robot.clear_error("A")
                self._robot.clear_error("B")
                self._robot.send_cmd()
                time.sleep(0.05)

                # Verify connection by reading frames
                if self._dcss is None:
                    raise InitializationError("DCSS is None", operation="initialize")
                motion_tag = 0
                frame_update = None
                for _ in range(5):
                    sub = self._robot.subscribe(self._dcss)
                    frame = sub["outputs"][0]["frame_serial"]
                    if frame != 0 and frame_update != frame:
                        motion_tag += 1
                        frame_update = frame
                    time.sleep(0.1)
                if motion_tag <= 0:
                    raise InitializationError(
                        "Robot connected but no motion frames received",
                        operation="initialize",
                    )

                # Clear errors again
                self._robot.clear_set()
                self._robot.clear_error("A")
                self._robot.clear_error("B")
                self._robot.send_cmd()
                time.sleep(0.1)

                # Set position mode for both arms
                for arm in ("A", "B"):
                    self._robot.clear_set()
                    self._robot.set_state(arm, 1)  # position mode
                    self._robot.set_vel_acc(arm, 100, 100)
                    self._robot.send_cmd()

                # Init kinematics
                self._init_kinematics()

                time.sleep(0.5) # wait for initalization of servo

                self._initialised = True
                logger.info("Robot initialised successfully")
            except InitializationError:
                raise
            except Exception as exc:
                raise InitializationError(
                    str(exc), operation="initialize"
                ) from exc

    def _init_kinematics(self) -> None:
        """Load kinematics config and initialise the library."""
        if self._kinematics is None:
            raise InitializationError("Kinematics backend not loaded")

        from importlib.resources import files

        config_path = None
        try:
            config_path = str(files("tj_robot_proj.native.backend") / "ccs_m6_40.MvKDCfg")
        except Exception:
            # Fallback: look relative to this file
            config_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),"backend", "ccs_m6_40.MvKDCfg",
            )

        self._kinematics.log_switch(0)  # disable native kinematics logging
        native_config_path, temporary_config_path = self._prepare_kinematics_config(
            config_path
        )
        try:
            cfg = self._kinematics.load_config(0, native_config_path)
        finally:
            if temporary_config_path is not None:
                try:
                    os.unlink(temporary_config_path)
                except OSError:
                    logger.warning(
                        "Failed to remove temporary kinematics config: %s",
                        temporary_config_path,
                    )
        if cfg is None:
            raise InitializationError(
                f"Failed to load kinematics config: {config_path}",
                operation="initialize",
            )

        ok = self._kinematics.initial_kine(
            robot_type=cfg["TYPE"][0],
            dh=cfg["DH"][0],
            pnva=cfg["PNVA"][0],
            j67=cfg["BD"][0],
        )
        if not ok:
            raise InitializationError(
                "Kinematics initialisation failed",
                operation="initialize",
            )

    @staticmethod
    def _prepare_kinematics_config(config_path: str) -> tuple[str, str | None]:
        """Return a config path suitable for the native ``LOADMvCfg`` parser.

        ``LOADMvCfg`` opens its input in binary mode and requires each line to
        end in LF (``0x0A``).  A CRLF checkout on Windows therefore fails even
        though the text itself is otherwise valid.  Keep an already compatible
        source file untouched; otherwise pass the native library a temporary
        LF-only, BOM-free copy and let the caller remove it after loading.
        """
        with open(config_path, "rb") as config_file:
            config_bytes = config_file.read()

        utf8_bom = b"\xef\xbb\xbf"
        requires_normalisation = (
            b"\r\n" in config_bytes or config_bytes.startswith(utf8_bom)
        )
        if not requires_normalisation:
            return config_path, None

        normalised_bytes = config_bytes.removeprefix(utf8_bom).replace(
            b"\r\n", b"\n"
        )
        config_dir = os.path.dirname(os.path.abspath(config_path))
        try:
            file_descriptor, temporary_path = tempfile.mkstemp(
                prefix=".tj_robot_",
                suffix=".MvKDCfg",
                dir=config_dir,
            )
        except OSError:
            # Installed packages may be read-only.  ``mkstemp`` then falls
            # back to the platform's writable temporary directory.
            file_descriptor, temporary_path = tempfile.mkstemp(
                prefix="tj_robot_",
                suffix=".MvKDCfg",
            )
        try:
            with os.fdopen(file_descriptor, "wb") as temporary_file:
                temporary_file.write(normalised_bytes)
        except Exception:
            os.unlink(temporary_path)
            raise

        logger.debug(
            "Using a temporary LF-normalised kinematics config: %s", temporary_path
        )
        return temporary_path, temporary_path

    def close(self) -> None:
        """Idempotent shutdown: stop threads, release native resources."""
        with self._lock:
            if self._closed:
                return

            # Stop subscription thread
            self._sub_stop_event.set()
            if self._sub_thread is not None:
                self._sub_thread.join(timeout=2.0)
                if self._sub_thread.is_alive():
                    logger.warning("Subscription thread did not stop in time")
                self._sub_thread = None

            # Release active point sets
            for ps in self._active_point_sets:
                try:
                    ps.close()
                except Exception:
                    pass
            self._active_point_sets.clear()

            # Disable arms and release
            if self._robot is not None and self._connected:
                try:
                    self._robot.clear_set()
                    self._robot.set_state("A", 0)
                    self._robot.set_state("B", 0)
                    self._robot.send_cmd()
                    time.sleep(0.1)
                    self._robot.release()
                except Exception:
                    pass

            self._connected = False
            self._initialised = False
            self._closed = True
            logger.info("Session closed")

    # ------------------------------------------------------------------
    # Data subscription
    # ------------------------------------------------------------------

    def read_state_buffer(self) -> dict:
        """Read the native state buffer (caller must hold lock)."""
        self._check_closed()
        if self._robot is None or self._dcss is None:
            raise ClosedSessionError("Session not connected")
        return self._robot.subscribe(self._dcss)

    def get_sub_data_raw(self) -> dict | None:
        """Return the latest raw subscription sample, thread-safely.

        The subscription thread writes ``_sub_data_raw`` under
        ``_sub_data_raw_lock``; this accessor reads it under the same lock.
        Returns ``None`` before the thread has produced a sample.
        """
        with self._sub_data_raw_lock:
            return copy.deepcopy(self._sub_data_raw) 

    def get_arm_data(self, arm: Arm):
        sub_data_raw = self.get_sub_data_raw()

        idx = 0 if arm == Arm.LEFT else 1
        joints_deg = sub_data_raw["outputs"][idx]["fb_joint_pos"]

        # Forward kinematics → T_end_ref_base (end-effector relative to the
        # arm base), returned by ``fk`` as a 4×4 matrix in millimetres.
        T_end_ref_base_mat = np.array(
            self._kinematics.fk(list(joints_deg)), dtype=float
        )
        T_end_ref_base_mat[:3, 3] *= 0.001  # mm → m
        T_end_ref_base = SE3.from_matrix(T_end_ref_base_mat, normalize=True)

        arm_config = (
            self._config.left_arm_config
            if arm is Arm.LEFT
            else self._config.right_arm_config
        )
        T_end_ref_world = arm_config.trans_config.T_base_ref_world @ T_end_ref_base
        T_tool_ref_world = T_end_ref_world @ arm_config.trans_config.T_tool_ref_end

        return ArmData(
            arm=arm,
            joints_pos=JointPositions.from_deg(sub_data_raw["outputs"][idx]["fb_joint_pos"],num_joints=7),
            joints_vel=JointVelocity.from_deg_s(sub_data_raw["outputs"][idx]["fb_joint_vel"],num_joints=7),
            T_end_ref_world=T_end_ref_world,
            T_tool_ref_world=T_tool_ref_world,
            num_joints=7,
            button_pressed=(sub_data_raw["outputs"][idx]["tip_di"][0] == 1)
        )

    def start_subscription(
        self, callback: Callable[[dict], None] | None = None
    ) -> None:
        """Start the background subscription thread.

        ``callback`` is an optional callable invoked with each raw sample
        dict.  When ``None``, samples are only cached — read them with
        ``get_sub_data_raw()``.
        """
        with self._lock:
            self._check_closed()
            if self._sub_thread is not None and self._sub_thread.is_alive():
                return
            self._sub_stop_event.clear()
            self._sub_thread = threading.Thread(
                target=self._subscription_loop,
                args=(callback,),
                daemon=True,
                name="tj-sdk-sub",
            )
            self._sub_thread.start()
        time.sleep(1) # wait for data

    def stop_subscription(self) -> None:
        """Signal and join the subscription thread."""
        self._sub_stop_event.set()
        if self._sub_thread is not None:
            self._sub_thread.join(timeout=2.0)
            self._sub_thread = None

    def _subscription_loop(self, callback: Callable[[dict], None] | None) -> None:
        interval = self._config.subscription_interval_seconds
        while not self._sub_stop_event.is_set():
            _start_time = time.time()
            try:
                with self._lock:
                    if self._closed or self._robot is None:
                        break
                    sub_data_raw = self.read_state_buffer()

                # Cache the latest raw sample under its own lock
                with self._sub_data_raw_lock:
                    self._sub_data_raw = copy.deepcopy(sub_data_raw)

                # Only invoke the callback when one was supplied
                if callback is not None and sub_data_raw is not None:
                    try:
                        callback(sub_data_raw)
                    except Exception:
                        logger.debug(
                            "Unhandled exception in subscription callback",
                            exc_info=True,
                        )
            except ClosedSessionError:
                break
            except Exception:
                logger.debug(
                    "Error in subscription loop", exc_info=True
                )
            _duration = time.time() - _start_time
            _wait = max(0.001, interval-_duration)
            self._sub_stop_event.wait(_wait)

    # ------------------------------------------------------------------
    # Motion execution
    # ------------------------------------------------------------------

    def change_to_drag_mode(self, arm: str) -> None:
        """Change one arm to joint-impedance drag mode.

        The complete mode-switch sequence is serialized by ``self._lock``:
        torque mode, joint impedance, then drag type 1.
        """
        if arm not in (Arm.LEFT.value, Arm.RIGHT.value):
            raise ConfigurationError(
                f"arm must be {Arm.LEFT.value!r} or {Arm.RIGHT.value!r}, got {arm!r}",
                operation="change_to_drag_mode",
                arm=arm,
            )

        with self._lock:
            self._check_closed()
            if self._robot is None:
                raise ClosedSessionError("Session not connected")

            self._robot.clear_set()
            self._robot.set_state(arm=arm, state=3)  # torque mode
            self._robot.send_cmd()
            time.sleep(0.1)

            self._robot.clear_set()
            self._robot.set_impedance_type(
                arm=arm,
                imp_type=1,
            )  # joint impedance
            self._robot.send_cmd()
            time.sleep(0.1)

            self._robot.clear_set()
            self._robot.set_drag_space(arm=arm, drag_type=1)
            self._robot.send_cmd()
            time.sleep(0.5)

    def change_to_norm_mode(self, arm: str) -> None:
        """Clear errors and return one arm to normal position mode.

        Each complete mode-switch attempt is serialized by ``self._lock``.
        After an attempt, the cached subscribed state is checked; the sequence
        is repeated until the arm reports position mode (``cur_state == 1``).
        """
        if arm not in (Arm.LEFT.value, Arm.RIGHT.value):
            raise ConfigurationError(
                f"arm must be {Arm.LEFT.value!r} or {Arm.RIGHT.value!r}, got {arm!r}",
                operation="change_to_norm_mode",
                arm=arm,
            )

        idx = 0 if arm == Arm.LEFT.value else 1
        sub_data_raw = self.get_sub_data_raw()
        if (
            sub_data_raw is not None
            and sub_data_raw["states"][idx]["cur_state"] == 1
        ):
            return
        while True:
            with self._lock:
                self._check_closed()
                if self._robot is None:
                    raise ClosedSessionError("Session not connected")

                self._robot.clear_set()
                self._robot.clear_error(arm)
                self._robot.send_cmd()
                time.sleep(0.1)

                self._robot.clear_set()
                self._robot.set_state(arm=arm, state=1)  # position mode
                self._robot.set_vel_acc(
                    arm=arm,
                    vel_ratio=100,
                    acc_ratio=100,
                )
                self._robot.send_cmd()

            # The subscription loop also needs self._lock. Wait outside it so
            # that get_sub_data_raw() can observe a post-command sample.
            time.sleep(0.2)
            sub_data_raw = self.get_sub_data_raw()
            if (
                sub_data_raw is not None
                and sub_data_raw["states"][idx]["cur_state"] == 1
            ):
                return

    def stop_planned_motion(self, arm: str) -> None:
        with self._lock:
            self._check_closed()
            if self._robot is None:
                return
            self._robot.stop_pln_joint(arm)

    def ik(
        self,
        arm: str,
        T_end_ref_world: SE3,
        vel: int = 10,
    ) -> JointPositions:
        """Return the final joint position of a planned linear trajectory.

        ``T_end_ref_world`` is converted from the world frame to the selected
        arm's base frame before planning.  The native planner works in
        millimetres/degrees; the returned :class:`JointPositions` stores the
        final seven joint angles in radians and also exposes them through
        :attr:`JointPositions.pos_deg`.

        This method only performs kinematic planning.  It does not send the
        generated trajectory to the robot.
        """
        if arm not in (Arm.LEFT.value, Arm.RIGHT.value):
            raise ConfigurationError(
                f"arm must be {Arm.LEFT.value!r} or {Arm.RIGHT.value!r}, got {arm!r}",
                operation="ik",
                arm=arm,
            )
        if not isinstance(T_end_ref_world, SE3):
            raise ConfigurationError(
                "T_end_ref_world must be an SE3",
                operation="ik",
                arm=arm,
            )
        if isinstance(vel, bool) or not isinstance(vel, int) or vel <= 0:
            raise ConfigurationError(
                f"vel must be a positive integer, got {vel!r}",
                operation="ik",
                arm=arm,
            )

        arm_enum = Arm.LEFT if arm == Arm.LEFT.value else Arm.RIGHT
        arm_config = (
            self._config.left_arm_config
            if arm_enum is Arm.LEFT
            else self._config.right_arm_config
        )

        with self._lock:
            self._check_closed()
            if self._kinematics is None:
                raise ClosedSessionError("Session not connected")

            current_arm_data = self.get_arm_data(arm_enum)
            T_world_ref_base = arm_config.trans_config.T_base_ref_world.inverse()
            start_T_end_ref_base = T_world_ref_base @ current_arm_data.T_end_ref_world
            end_T_end_ref_base = T_world_ref_base @ T_end_ref_world

            start_matrix_mm = start_T_end_ref_base.matrix.copy()
            end_matrix_mm = end_T_end_ref_base.matrix.copy()
            start_matrix_mm[:3, 3] *= 1000.0
            end_matrix_mm[:3, 3] *= 1000.0
            start_xyzabc = self._kinematics.mat4x4_to_xyzabc(start_matrix_mm)
            end_xyzabc = self._kinematics.mat4x4_to_xyzabc(end_matrix_mm)

            points, raw_pset = self._kinematics.plan_linear(
                start_xyzabc=start_xyzabc,
                end_xyzabc=end_xyzabc,
                ref_joints=list(current_arm_data.joints_pos.pos_deg),
                vel=vel * 5,
                acc=500,
            )
            if raw_pset is None:
                raise KinematicsError(
                    "Inverse kinematics planning failed",
                    operation="ik",
                    arm=arm,
                )

            with PointSet(raw_pset, self._kinematics):
                if not points or len(points[-1]) < 7:
                    raise KinematicsError(
                        "Inverse kinematics planning returned no joint position",
                        operation="ik",
                        arm=arm,
                    )
                return JointPositions.from_deg(points[-1][:7], num_joints=7)

    def send_linear_command(self, arm: str, T_end_ref_world: SE3, vel: int) -> None:
        """Plan and send a Cartesian linear motion for one arm.

        ``T_end_ref_world`` is the desired end-effector pose in the world
        frame.  The kinematics SDK plans in the corresponding arm-base frame
        and uses millimetres/degrees, while the public pose representation
        uses metres/radians.  ``vel`` is the Cartesian planning velocity in
        mm/s and is also used as the planning acceleration in mm/s².
        """
        if arm not in (Arm.LEFT.value, Arm.RIGHT.value):
            raise ConfigurationError(
                f"arm must be {Arm.LEFT.value!r} or {Arm.RIGHT.value!r}, got {arm!r}",
                operation="send_linear_command",
                arm=arm,
            )
        if not isinstance(T_end_ref_world, SE3):
            raise ConfigurationError(
                "T_end_ref_world must be an SE3",
                operation="send_linear_command",
                arm=arm,
            )
        if isinstance(vel, bool) or not isinstance(vel, int) or vel <= 0:
            raise ConfigurationError(
                f"vel must be a positive integer in mm/s, got {vel!r}",
                operation="send_linear_command",
                arm=arm,
            )

        arm_enum = Arm.LEFT if arm == Arm.LEFT.value else Arm.RIGHT
        arm_config = (
            self._config.left_arm_config
            if arm_enum is Arm.LEFT
            else self._config.right_arm_config
        )

        self.change_to_norm_mode(arm)
        
        with self._lock:
            self._check_closed()
            if self._robot is None or self._kinematics is None:
                raise ClosedSessionError("Session not connected")

            
            self._robot.clear_set()
            self._robot.set_vel_acc(arm, vel, 100)
            self._robot.send_cmd()
            time.sleep(0.001)
            
            current_arm_data = self.get_arm_data(arm_enum)
            T_world_ref_base = arm_config.trans_config.T_base_ref_world.inverse()
            start_T_end_ref_base = T_world_ref_base @ current_arm_data.T_end_ref_world
            end_T_end_ref_base = T_world_ref_base @ T_end_ref_world

            # Native matrix/xyzabc conversion uses millimetres and degrees.
            start_matrix_mm = start_T_end_ref_base.matrix.copy()
            end_matrix_mm = end_T_end_ref_base.matrix.copy()
            start_matrix_mm[:3, 3] *= 1000.0
            end_matrix_mm[:3, 3] *= 1000.0
            start_xyzabc = self._kinematics.mat4x4_to_xyzabc(start_matrix_mm)
            end_xyzabc = self._kinematics.mat4x4_to_xyzabc(end_matrix_mm)

            _, raw_pset = self._kinematics.plan_linear(
                start_xyzabc=start_xyzabc,
                end_xyzabc=end_xyzabc,
                ref_joints=list(current_arm_data.joints_pos.pos_deg),
                vel=vel*5,
                acc=500,
            )
            if raw_pset is None:
                raise KinematicsError(
                    "Linear trajectory planning failed",
                    operation="send_linear_command",
                    arm=arm,
                )

            # OnSetPlnCart consumes the planned points synchronously.  Keep
            # the CPointSet alive through that call, then release it on every
            # success/failure path.
            with PointSet(raw_pset, self._kinematics) as point_set:
                if not self._robot.set_pln_cart(arm, point_set.ptr):
                    raise ConnectionError(
                        "Controller rejected linear trajectory",
                        operation="send_linear_command",
                        arm=arm,
                    )


    def send_joint_command(self, arm: str, joints_deg: list[float], vel: int) -> None:

        self.change_to_norm_mode(arm)

        with self._lock:
            self._check_closed()
            if self._robot is None:
                raise ClosedSessionError("Session not connected")
            
            self._robot.clear_set()
            _vel_set = max(0, min(100, vel))
            self._robot.set_vel_acc(arm, _vel_set, 100)
            self._robot.set_joint_cmd_pose(arm, joints_deg)
            self._robot.send_cmd()

    def run_trajectory(self, arm: str, path: str) -> None:
        """Upload and start an FMV trajectory in the arm's PVT slot.

        Left arm ``A`` uses PVT slot 1 and right arm ``B`` uses slot 2.
        """
        if arm not in (Arm.LEFT.value, Arm.RIGHT.value):
            raise ConfigurationError(
                f"arm must be {Arm.LEFT.value!r} or {Arm.RIGHT.value!r}, got {arm!r}",
                operation="run_trajectory",
                arm=arm,
            )
        if not isinstance(path, str) or not path:
            raise ConfigurationError(
                "path must be a non-empty string",
                operation="run_trajectory",
                arm=arm,
            )

        pvt_id = 1 if arm == Arm.LEFT.value else 2
        with self._lock:
            self._check_closed()
            if self._robot is None:
                raise ClosedSessionError("Session not connected")

            # PVT mode uses the velocity and acceleration stored in the file.
            self._robot.clear_set()
            self._robot.set_state(arm=arm, state=2)
            self._robot.send_cmd()
            time.sleep(0.1)

            self._robot.send_pvt_file(
                arm=arm,
                path=path,
                pvt_id=pvt_id,
            )
            time.sleep(0.3)

            self._robot.clear_set()
            self._robot.set_pvt_id(arm=arm, pvt_id=pvt_id)
            self._robot.send_cmd()

    def soft_emergency_stop(self) -> None:
        with self._lock:
            if self._robot is not None:
                self._robot.soft_stop("AB")

    def quick_stop(self, arm: str) -> None:
        with self._lock:
            if self._robot is not None:
                self._robot.soft_stop(arm)

    def clear_error(self, arm: str) -> None:
        with self._lock:
            if self._robot is not None:
                self._robot.clear_set()
                self._robot.clear_error(arm)
                self._robot.send_cmd()

    # ------------------------------------------------------------------
    # Data collection
    # ------------------------------------------------------------------

    def collect_data(self) -> bool:
        """Start data collection using the options in ``RobotConfig``.

        Collection IDs are ordered left arm first, then right arm. The current
        implementation requests 10,000,000 records from the native SDK. The
        native SDK accepts at most 35 collection IDs per request; its
        ``target_id`` argument is padded with trailing zeroes to length 35.
        """
        left_arm_option = self._config.left_arm_collection_data_option
        right_arm_option = self._config.right_arm_collection_data_option

        target_ids = [
            *left_arm_option.target_ids,
            *right_arm_option.target_ids,
        ]
        target_num = len(target_ids)
        if target_num > 35:
            raise ConfigurationError(
                f"At most 35 collection target IDs are supported, got {target_num}",
                operation="collect_data",
            )
        target_ids.extend([0] * (35 - target_num))

        with self._lock:
            self._check_closed()
            if self._robot is None:
                raise ClosedSessionError("Session not connected")
            return self._robot.collect_data(
                target_num=target_num,
                target_id=target_ids,
                record_num=1000000,
            )

    def stop_collect_data(self) -> bool:
        """Stop native controller data collection, retrying transient failures."""
        with self._lock:
            self._check_closed()
            if self._robot is None:
                raise ClosedSessionError("Session not connected")

            max_attempts = 10
            for attempt in range(1, max_attempts + 1):
                if self._robot.stop_collect_data():
                    return True
                if attempt < max_attempts:
                    time.sleep(0.05)

            raise CommunicationError(
                f"Failed to stop data collection after {max_attempts} attempts",
                operation="stop_collect_data",
            )

    def save_collected_data(
        self,
        dir: str,
    ) -> bool:
        """Save data using the collection options in ``RobotConfig``.

        Each arm gets a split TXT file and an FMV independently when its option
        contains all joint-position IDs ``0..6``. Data for an incomplete arm
        remains available only in the native raw file.
        """
        left_arm_option = self._config.left_arm_collection_data_option
        right_arm_option = self._config.right_arm_collection_data_option
        date_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        save_dir = os.path.join(dir, date_str)
        os.makedirs(save_dir, exist_ok=True)
        raw_path = os.path.join(save_dir, f"{date_str}_raw.txt")
        left_path = os.path.join(save_dir, f"{date_str}_left_arm.txt")
        right_path = os.path.join(save_dir, f"{date_str}_right_arm.txt")
        with self._lock:
            self._check_closed()
            if self._robot is None:
                raise ClosedSessionError("Session not connected")
            max_attempts = 10
            saved = False
            for attempt in range(1, max_attempts + 1):
                saved = self._robot.save_collected_data(raw_path)
                if saved:
                    break
                if attempt < max_attempts:
                    time.sleep(0.1)
        if not saved:
            logger.error(
                "Failed to save collected data after %d attempts: %s",
                max_attempts,
                raw_path,
            )
            return False

        left_supported = option_supports_fmv(left_arm_option, Arm.LEFT)
        right_supported = option_supports_fmv(right_arm_option, Arm.RIGHT)
        if not left_supported and not right_supported:
            logger.warning(
                "Neither collection option contains complete joint-position "
                "IDs 0..6; only raw data was saved to %s",
                raw_path,
            )
            self._backup_saved_data(save_dir)
            return True

        self._split_collected_data(
            raw_path,
            left_path,
            right_path,
            left_arm_option.col,
            right_arm_option.col,
            save_left=left_supported,
            save_right=right_supported,
        )
        convert_file(
            raw_path,
            left_arm_option,
            right_arm_option,
            output_dir=save_dir,
            trajectory_frequency=self._config.trajectory_frequency,
        )
        self._backup_saved_data(save_dir)
        return True

    @staticmethod
    def _backup_saved_data(save_dir: str) -> Path:
        """Copy one complete timestamped recording into ``temp_data``."""
        source = Path(save_dir).resolve()
        _TEMP_DATA_DIR.mkdir(parents=True, exist_ok=True)
        destination = (_TEMP_DATA_DIR / source.name).resolve()
        if source == destination:
            return destination
        shutil.copytree(source, destination, dirs_exist_ok=True)
        return destination

    @staticmethod
    def cleanup_temp_data() -> None:
        """Delete old temporary recordings, retaining only the newest one."""
        if not _TEMP_DATA_DIR.is_dir():
            return
        entries = list(_TEMP_DATA_DIR.iterdir())
        if len(entries) <= 1:
            return
        latest = max(
            entries,
            key=lambda path: (path.stat().st_mtime_ns, path.name),
        )
        for path in entries:
            if path == latest:
                continue
            if path.is_dir() and not path.is_symlink():
                shutil.rmtree(path)
            else:
                path.unlink()

    @staticmethod
    def get_temp_data_dir() -> Path:
        """Return the project-level temporary recording directory."""
        return _TEMP_DATA_DIR

    @staticmethod
    def _split_collected_data(
        raw_path: str,
        left_path: str,
        right_path: str,
        left_col: int,
        right_col: int,
        *,
        save_left: bool,
        save_right: bool,
    ) -> None:
        """Split valid arm columns into their requested TXT files."""
        with open(raw_path, encoding="utf-8") as raw_file:
            lines = raw_file.readlines()
        data_lines = [line for line in lines[1:] if line.strip()]

        with ExitStack() as stack:
            left_file = (
                stack.enter_context(
                    open(left_path, "w", encoding="utf-8", newline="\n")
                )
                if save_left
                else None
            )
            right_file = (
                stack.enter_context(
                    open(right_path, "w", encoding="utf-8", newline="\n")
                )
                if save_right
                else None
            )
            if left_file is not None:
                left_file.write(f"PoinType={left_col + 2}@{len(data_lines)}\n")
            if right_file is not None:
                right_file.write(f"PoinType={right_col + 2}@{len(data_lines)}\n")
            for line in data_lines:
                fields = [field for field in line.strip().split("$") if field]
                frame_fields = fields[:2]
                left_fields = fields[2 : 2 + left_col]
                right_fields = fields[2 + left_col : 2 + left_col + right_col]
                if left_file is not None:
                    left_file.write("$".join((*frame_fields, *left_fields)) + "$\n")
                if right_file is not None:
                    right_file.write("$".join((*frame_fields, *right_fields)) + "$\n")

    # ------------------------------------------------------------------
    # Kinematics delegation
    # ------------------------------------------------------------------

    @property
    def kinematics(self) -> KinematicsBackend:
        if self._kinematics is None:
            raise ClosedSessionError("Session not connected")
        return self._kinematics

    @property
    def robot_backend(self) -> RobotBackend:
        if self._robot is None:
            raise ClosedSessionError("Session not connected")
        return self._robot

    # ------------------------------------------------------------------
    # State accessors
    # ------------------------------------------------------------------

    @property
    def connected(self) -> bool:
        return self._connected and not self._closed

    @property
    def initialised(self) -> bool:
        return self._initialised and not self._closed

    @property
    def closed(self) -> bool:
        return self._closed

    def _check_closed(self) -> None:
        if self._closed:
            raise ClosedSessionError("Session has been closed")
