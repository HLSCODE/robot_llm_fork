"""``NativeSession`` — sole owner of native SDK instances, connection, lock, and lifecycle.

One ``RobotClient`` → one ``NativeSession``.
"""

from __future__ import annotations

from datetime import datetime
import logging
import os
import threading
import time
from typing import Callable
import copy

import numpy as np

from tj_robot_proj.native.backend.bindings import DCSS
from tj_robot_proj.native.backend.kinematics_backend import KinematicsBackend
from tj_robot_proj.native.backend.resources import PointSet, TrajectoryResource
from tj_robot_proj.native.backend.robot_backend import RobotBackend
from tj_robot_proj.errors import (
    ClosedSessionError,
    ConfigurationError,
    ConnectionError,
    InitializationError,
    KinematicsError,
    NativeLibraryError,
)

from tj_robot_proj.value_objects import *

logger = logging.getLogger(__name__)


class NativeSession:
    """Owns the native SDK, connection, lock, subscription thread, and point sets.

    All public methods that touch native state hold ``self._lock``.
    The subscription thread is the **only** background thread — every sample
    is cached in ``_sub_data_raw`` (guarded by ``_sub_data_raw_lock``) and,
    when a callback was supplied, pushed to it.  Read the cache with
    ``get_sub_data_raw()``.
    """

    def __init__(self, config: RobotConfig) -> None:
        self._config = config
        self._robot: RobotBackend | None = None
        self._kinematics: KinematicsBackend | None = None
        self._dcss: DCSS | None = None

        # Connection & lifecycle
        self._lock = threading.Lock()
        self._closed = False
        self._connected = False
        self._initialised = False

        # State subscription
        self._sub_thread: threading.Thread | None = None
        self._sub_stop_event = threading.Event()
        # Latest raw sample cached by the subscription thread
        self._sub_data_raw: dict | None = None
        self._sub_data_raw_lock = threading.Lock()

        # Active motion point sets (held until motion completes)
        self._active_point_sets: list[PointSet] = []

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def connect(self) -> None:
        """Load native libraries and connect to the controller."""
        with self._lock:
            self._check_closed()
            if self._connected:
                return

            try:
                self._robot = RobotBackend()
                self._kinematics = KinematicsBackend()
            except FileNotFoundError as exc:
                raise NativeLibraryError(
                    str(exc), operation="connect"
                ) from exc

            self._dcss = DCSS()

            ok = self._robot.connect(self._config.controller_ip)
            if not ok:
                raise ConnectionError(
                    f"Failed to connect to {self._config.controller_ip}",
                    operation="connect",
                )

            # Logging must be configured *after* OnLinkTo — the native
            # OnLogOff/OnLogOn path dereferences the robot instance that
            # OnLinkTo initialises (segfault otherwise).
            self._robot.log_switch(False)
            self._robot.local_log_switch(False)
            self._connected = True
            logger.info("Connected to %s", self._config.controller_ip)

    def initialize(self) -> None:
        """Clear errors, set position mode, and init kinematics."""
        with self._lock:
            self._check_closed()
            if not self._connected or self._robot is None:
                raise InitializationError(
                    "Must connect() before initialize()",
                    operation="initialize",
                )

            try:
                # Flush / clear errors
                time.sleep(0.05)
                self._robot.clear_set()
                self._robot.clear_error("A")
                self._robot.clear_error("B")
                self._robot.send_cmd()
                time.sleep(0.05)

                # Verify connection by reading frames
                if self._dcss is None:
                    raise InitializationError("DCSS is None", operation="initialize")
                motion_tag = 0
                frame_update = None
                for _ in range(5):
                    sub = self._robot.subscribe(self._dcss)
                    frame = sub["outputs"][0]["frame_serial"]
                    if frame != 0 and frame_update != frame:
                        motion_tag += 1
                        frame_update = frame
                    time.sleep(0.1)
                if motion_tag <= 0:
                    raise InitializationError(
                        "Robot connected but no motion frames received",
                        operation="initialize",
                    )

                # Clear errors again
                self._robot.clear_set()
                self._robot.clear_error("A")
                self._robot.clear_error("B")
                self._robot.send_cmd()
                time.sleep(0.1)

                # Set position mode for both arms
                for arm in ("A", "B"):
                    self._robot.clear_set()
                    self._robot.set_state(arm, 1)  # position mode
                    self._robot.set_vel_acc(arm, 100, 100)
                    self._robot.send_cmd()

                # Init kinematics
                self._init_kinematics()

                time.sleep(0.5) # wait for initalization of servo

                self._initialised = True
                logger.info("Robot initialised successfully")
            except InitializationError:
                raise
            except Exception as exc:
                raise InitializationError(
                    str(exc), operation="initialize"
                ) from exc

    def _init_kinematics(self) -> None:
        """Load kinematics config and initialise the library."""
        if self._kinematics is None:
            raise InitializationError("Kinematics backend not loaded")

        from importlib.resources import files

        config_path = None
        try:
            config_path = str(files("tj_robot_proj.native.backend") / "ccs_m6_40.MvKDCfg")
        except Exception:
            # Fallback: look relative to this file
            import os
            config_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),"backend", "ccs_m6_40.MvKDCfg",
            )

        self._kinematics.log_switch(0)  # disable native kinematics logging
        cfg = self._kinematics.load_config(0, config_path)
        if cfg is None:
            raise InitializationError(
                f"Failed to load kinematics config: {config_path}",
                operation="initialize",
            )

        ok = self._kinematics.initial_kine(
            robot_type=cfg["TYPE"][0],
            dh=cfg["DH"][0],
            pnva=cfg["PNVA"][0],
            j67=cfg["BD"][0],
        )
        if not ok:
            raise InitializationError(
                "Kinematics initialisation failed",
                operation="initialize",
            )

    def close(self) -> None:
        """Idempotent shutdown: stop threads, release native resources."""
        with self._lock:
            if self._closed:
                return

            # Stop subscription thread
            self._sub_stop_event.set()
            if self._sub_thread is not None:
                self._sub_thread.join(timeout=2.0)
                if self._sub_thread.is_alive():
                    logger.warning("Subscription thread did not stop in time")
                self._sub_thread = None

            # Release active point sets
            for ps in self._active_point_sets:
                try:
                    ps.close()
                except Exception:
                    pass
            self._active_point_sets.clear()

            # Disable arms and release
            if self._robot is not None and self._connected:
                try:
                    self._robot.clear_set()
                    self._robot.set_state("A", 0)
                    self._robot.set_state("B", 0)
                    self._robot.send_cmd()
                    time.sleep(0.1)
                    self._robot.release()
                except Exception:
                    pass

            self._connected = False
            self._initialised = False
            self._closed = True
            logger.info("Session closed")

    # ------------------------------------------------------------------
    # Data subscription
    # ------------------------------------------------------------------

    def read_state_buffer(self) -> dict:
        """Read the native state buffer (caller must hold lock)."""
        self._check_closed()
        if self._robot is None or self._dcss is None:
            raise ClosedSessionError("Session not connected")
        return self._robot.subscribe(self._dcss)

    def get_sub_data_raw(self) -> dict | None:
        """Return the latest raw subscription sample, thread-safely.

        The subscription thread writes ``_sub_data_raw`` under
        ``_sub_data_raw_lock``; this accessor reads it under the same lock.
        Returns ``None`` before the thread has produced a sample.
        """
        with self._sub_data_raw_lock:
            return copy.deepcopy(self._sub_data_raw) 

    def get_arm_data(self, arm: Arm):
        sub_data_raw = self.get_sub_data_raw()

        idx = 0 if arm == Arm.LEFT else 1
        joints_deg = sub_data_raw["outputs"][idx]["fb_joint_pos"]

        # Forward kinematics → T_end_ref_base (end-effector relative to the
        # arm base), returned by ``fk`` as a 4×4 matrix in millimetres.
        T_end_ref_base_mat = np.array(
            self._kinematics.fk(list(joints_deg)), dtype=float
        )
        T_end_ref_base_mat[:3, 3] *= 0.001  # mm → m
        T_end_ref_base = SE3.from_matrix(T_end_ref_base_mat, normalize=True)

        arm_config = (
            self._config.left_arm_config
            if arm is Arm.LEFT
            else self._config.right_arm_config
        )
        T_end_ref_world = arm_config.trans_config.T_base_ref_world @ T_end_ref_base
        T_tool_ref_world = T_end_ref_world @ arm_config.trans_config.T_tool_ref_end

        return ArmData(
            arm=arm,
            joints_pos=JointPositions.from_deg(sub_data_raw["outputs"][idx]["fb_joint_pos"],num_joints=7),
            joints_vel=JointVelocity.from_deg_s(sub_data_raw["outputs"][idx]["fb_joint_vel"],num_joints=7),
            T_end_ref_world=T_end_ref_world,
            T_tool_ref_world=T_tool_ref_world,
            num_joints=7,
            button_pressed=(sub_data_raw["outputs"][idx]["tip_di"][0] == 1)
        )

    def start_subscription(
        self, callback: Callable[[dict], None] | None = None
    ) -> None:
        """Start the background subscription thread.

        ``callback`` is an optional callable invoked with each raw sample
        dict.  When ``None``, samples are only cached — read them with
        ``get_sub_data_raw()``.
        """
        with self._lock:
            self._check_closed()
            if self._sub_thread is not None and self._sub_thread.is_alive():
                return
            self._sub_stop_event.clear()
            self._sub_thread = threading.Thread(
                target=self._subscription_loop,
                args=(callback,),
                daemon=True,
                name="tj-sdk-sub",
            )
            self._sub_thread.start()
        time.sleep(1) # wait for data

    def stop_subscription(self) -> None:
        """Signal and join the subscription thread."""
        self._sub_stop_event.set()
        if self._sub_thread is not None:
            self._sub_thread.join(timeout=2.0)
            self._sub_thread = None

    def _subscription_loop(self, callback: Callable[[dict], None] | None) -> None:
        interval = self._config.subscription_interval_seconds
        while not self._sub_stop_event.is_set():
            _start_time = time.time()
            try:
                with self._lock:
                    if self._closed or self._robot is None:
                        break
                    sub_data_raw = self.read_state_buffer()

                # Cache the latest raw sample under its own lock
                with self._sub_data_raw_lock:
                    self._sub_data_raw = copy.deepcopy(sub_data_raw)

                # Only invoke the callback when one was supplied
                if callback is not None and sub_data_raw is not None:
                    try:
                        callback(sub_data_raw)
                    except Exception:
                        logger.debug(
                            "Unhandled exception in subscription callback",
                            exc_info=True,
                        )
            except ClosedSessionError:
                break
            except Exception:
                logger.debug(
                    "Error in subscription loop", exc_info=True
                )
            _duration = time.time() - _start_time
            _wait = max(0.001, interval-_duration)
            self._sub_stop_event.wait(_wait)

    # ------------------------------------------------------------------
    # Motion execution
    # ------------------------------------------------------------------

    # def execute_trajectory(self, arm: str, trajectory: TrajectoryResource) -> None:
    #     """Send a planned trajectory to the controller."""
    #     with self._lock:
    #         self._check_closed()
    #         if self._robot is None:
    #             raise ClosedSessionError("Session not connected")
    #         ok = self._robot.set_pln_cart(arm, trajectory.pset_ptr)
    #         if not ok:
    #             raise ConnectionError(
    #                 "Controller rejected trajectory",
    #                 operation="execute_trajectory",
    #                 arm=arm,
    #             )
    #         # Track the point set so we don't release it mid-motion
    #         self._active_point_sets.append(trajectory._point_set)  # noqa: SLF001

    def stop_planned_motion(self, arm: str) -> None:
        with self._lock:
            self._check_closed()
            if self._robot is None:
                return
            self._robot.stop_pln_joint(arm)

    def send_linear_command(self, arm: str, T_end_ref_world: SE3, vel: int) -> None:
        """Plan and send a Cartesian linear motion for one arm.

        ``T_end_ref_world`` is the desired end-effector pose in the world
        frame.  The kinematics SDK plans in the corresponding arm-base frame
        and uses millimetres/degrees, while the public pose representation
        uses metres/radians.  ``vel`` is the Cartesian planning velocity in
        mm/s and is also used as the planning acceleration in mm/s².
        """
        if arm not in (Arm.LEFT.value, Arm.RIGHT.value):
            raise ConfigurationError(
                f"arm must be {Arm.LEFT.value!r} or {Arm.RIGHT.value!r}, got {arm!r}",
                operation="send_linear_command",
                arm=arm,
            )
        if not isinstance(T_end_ref_world, SE3):
            raise ConfigurationError(
                "T_end_ref_world must be an SE3",
                operation="send_linear_command",
                arm=arm,
            )
        if isinstance(vel, bool) or not isinstance(vel, int) or vel <= 0:
            raise ConfigurationError(
                f"vel must be a positive integer in mm/s, got {vel!r}",
                operation="send_linear_command",
                arm=arm,
            )

        arm_enum = Arm.LEFT if arm == Arm.LEFT.value else Arm.RIGHT
        arm_config = (
            self._config.left_arm_config
            if arm_enum is Arm.LEFT
            else self._config.right_arm_config
        )

        with self._lock:
            self._check_closed()
            if self._robot is None or self._kinematics is None:
                raise ClosedSessionError("Session not connected")

            self._robot.clear_set()
            self._robot.set_vel_acc(arm, vel, 100)
            self._robot.send_cmd()
            time.sleep(0.001)
            
            current_arm_data = self.get_arm_data(arm_enum)
            T_world_ref_base = arm_config.trans_config.T_base_ref_world.inverse()
            start_T_end_ref_base = T_world_ref_base @ current_arm_data.T_end_ref_world
            end_T_end_ref_base = T_world_ref_base @ T_end_ref_world

            # Native matrix/xyzabc conversion uses millimetres and degrees.
            start_matrix_mm = start_T_end_ref_base.matrix.copy()
            end_matrix_mm = end_T_end_ref_base.matrix.copy()
            start_matrix_mm[:3, 3] *= 1000.0
            end_matrix_mm[:3, 3] *= 1000.0
            start_xyzabc = self._kinematics.mat4x4_to_xyzabc(start_matrix_mm)
            end_xyzabc = self._kinematics.mat4x4_to_xyzabc(end_matrix_mm)

            _, raw_pset = self._kinematics.plan_linear(
                start_xyzabc=start_xyzabc,
                end_xyzabc=end_xyzabc,
                ref_joints=list(current_arm_data.joints_pos.pos_deg),
                vel=vel*5,
                acc=500,
            )
            if raw_pset is None:
                raise KinematicsError(
                    "Linear trajectory planning failed",
                    operation="send_linear_command",
                    arm=arm,
                )

            # OnSetPlnCart consumes the planned points synchronously.  Keep
            # the CPointSet alive through that call, then release it on every
            # success/failure path.
            with PointSet(raw_pset, self._kinematics) as point_set:
                if not self._robot.set_pln_cart(arm, point_set.ptr):
                    raise ConnectionError(
                        "Controller rejected linear trajectory",
                        operation="send_linear_command",
                        arm=arm,
                    )


    def send_joint_command(self, arm: str, joints_deg: list[float], vel: int) -> None:
        with self._lock:
            self._check_closed()
            if self._robot is None:
                raise ClosedSessionError("Session not connected")
            self._robot.clear_set()
            _vel_set = max(0, min(100, vel))
            self._robot.set_vel_acc(arm, _vel_set, 100)
            self._robot.set_joint_cmd_pose(arm, joints_deg)
            self._robot.send_cmd()

    def soft_emergency_stop(self) -> None:
        with self._lock:
            if self._robot is not None:
                self._robot.soft_stop("AB")

    def quick_stop(self, arm: str) -> None:
        with self._lock:
            if self._robot is not None:
                self._robot.soft_stop(arm)

    def clear_error(self, arm: str) -> None:
        with self._lock:
            if self._robot is not None:
                self._robot.clear_set()
                self._robot.clear_error(arm)
                self._robot.send_cmd()

    # ------------------------------------------------------------------
    # Data collection
    # ------------------------------------------------------------------

    def collect_data(
        self,
        left_arm_option: ArmCollectionDataOption | None = None,
        right_arm_option: ArmCollectionDataOption | None = None,
    ) -> bool:
        """Start data collection for the selected arms.

        Collection IDs are ordered left arm first, then right arm. The current
        implementation requests 10,000,000 records from the native SDK. The
        native SDK accepts at most 35 collection IDs per request; its
        ``target_id`` argument is padded with trailing zeroes to length 35.
        """
        if left_arm_option is not None and left_arm_option.arm is not Arm.LEFT:
            raise ConfigurationError(
                "left_arm_option.arm must be Arm.LEFT", operation="collect_data"
            )
        if right_arm_option is not None and right_arm_option.arm is not Arm.RIGHT:
            raise ConfigurationError(
                "right_arm_option.arm must be Arm.RIGHT", operation="collect_data"
            )

        target_ids = [
            *(left_arm_option.target_ids if left_arm_option is not None else ()),
            *(right_arm_option.target_ids if right_arm_option is not None else ()),
        ]
        target_num = len(target_ids)
        if target_num == 0:
            raise ConfigurationError(
                "Provide at least one arm collection option",
                operation="collect_data",
            )
        if target_num > 35:
            raise ConfigurationError(
                f"At most 35 collection target IDs are supported, got {target_num}",
                operation="collect_data",
            )
        target_ids.extend([0] * (35 - target_num))

        with self._lock:
            self._check_closed()
            if self._robot is None:
                raise ClosedSessionError("Session not connected")
            return self._robot.collect_data(
                target_num=target_num,
                target_id=target_ids,
                record_num=1000000,
            )

    def stop_collect_data(self) -> bool:
        """Stop native controller data collection."""
        with self._lock:
            self._check_closed()
            if self._robot is None:
                raise ClosedSessionError("Session not connected")
            return self._robot.stop_collect_data()

    def save_collected_data(
        self,
        dir: str,
        left_arm_option: ArmCollectionDataOption,
        right_arm_option: ArmCollectionDataOption,
    ) -> bool:
        """Save raw and split arm data into timestamped TXT files.

        Args:
            left_arm_option: The same left-arm collection option passed to
                :meth:`collect_data`.
            right_arm_option: The same right-arm collection option passed to
                :meth:`collect_data`.

        The output directory contains the native raw file plus left- and
        right-arm files. The options determine how native left-then-right
        columns are split into the two arm files.
        """
        if left_arm_option.arm is not Arm.LEFT:
            raise ConfigurationError(
                "left_arm_option.arm must be Arm.LEFT",
                operation="save_collected_data",
            )
        if right_arm_option.arm is not Arm.RIGHT:
            raise ConfigurationError(
                "right_arm_option.arm must be Arm.RIGHT",
                operation="save_collected_data",
            )

        date_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        save_dir = os.path.join(dir, date_str)
        os.makedirs(save_dir, exist_ok=True)
        raw_path = os.path.join(save_dir, f"{date_str}_raw.txt")
        left_path = os.path.join(save_dir, f"{date_str}_left_arm.txt")
        right_path = os.path.join(save_dir, f"{date_str}_right_arm.txt")
        with self._lock:
            self._check_closed()
            if self._robot is None:
                raise ClosedSessionError("Session not connected")
            saved = self._robot.save_collected_data(raw_path)
        if not saved:
            return False

        self._split_collected_data(
            raw_path,
            left_path,
            right_path,
            left_arm_option.col,
            right_arm_option.col,
        )
        return True

    @staticmethod
    def _split_collected_data(
        raw_path: str,
        left_path: str,
        right_path: str,
        left_col: int,
        right_col: int,
    ) -> None:
        """Split native left-then-right collection columns into two TXT files."""
        with open(raw_path, encoding="utf-8") as raw_file:
            lines = raw_file.readlines()
        data_lines = [line for line in lines[1:] if line.strip()]

        with (
            open(left_path, "w", encoding="utf-8", newline="\n") as left_file,
            open(right_path, "w", encoding="utf-8", newline="\n") as right_file,
        ):
            left_file.write(f"PoinType={left_col + 2}@{len(data_lines)}\n")
            right_file.write(f"PoinType={right_col + 2}@{len(data_lines)}\n")
            for line in data_lines:
                fields = [field for field in line.strip().split("$") if field]
                frame_fields = fields[:2]
                left_fields = fields[2 : 2 + left_col]
                right_fields = fields[2 + left_col : 2 + left_col + right_col]
                left_file.write("$".join((*frame_fields, *left_fields)) + "$\n")
                right_file.write("$".join((*frame_fields, *right_fields)) + "$\n")

    # ------------------------------------------------------------------
    # Kinematics delegation
    # ------------------------------------------------------------------

    @property
    def kinematics(self) -> KinematicsBackend:
        if self._kinematics is None:
            raise ClosedSessionError("Session not connected")
        return self._kinematics

    @property
    def robot_backend(self) -> RobotBackend:
        if self._robot is None:
            raise ClosedSessionError("Session not connected")
        return self._robot

    # ------------------------------------------------------------------
    # State accessors
    # ------------------------------------------------------------------

    @property
    def connected(self) -> bool:
        return self._connected and not self._closed

    @property
    def initialised(self) -> bool:
        return self._initialised and not self._closed

    @property
    def closed(self) -> bool:
        return self._closed

    def _check_closed(self) -> None:
        if self._closed:
            raise ClosedSessionError("Session has been closed")
