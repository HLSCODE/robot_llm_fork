"""Convert TJ robot data-collection ``.txt`` recordings to ``.fmv`` files.

The converter is intentionally independent of a fixed project data directory:
pass the saved recording path to :func:`convert_file`. By default, the two
converted files are written beside the source recording as ``*_L.fmv`` and
``*_R.fmv``.
"""

from __future__ import annotations

import argparse
from collections.abc import Iterable
from pathlib import Path
import re

# A-arm: direct mapping (same field names).
# B-arm: map source fields to the FMV field order.
FMV_FIELDS = ("Z", "A", "B", "C", "U", "V", "W")
B_ARM_SOURCE_FIELDS = ("O", "P", "Q", "I", "J", "K", "L")
_HEADER_PATTERN = re.compile(r"PoinType=(\d+)@(\d+)")


def parse_line(line: str) -> dict[str, float]:
    """Parse a ``X 1.0$Y 2.0$...`` recording line into field values."""
    values: dict[str, float] = {}
    for token in line.strip().split("$"):
        if not token:
            continue
        field = token.strip().split()
        if len(field) != 2:
            continue
        values[field[0]] = float(field[1])
    return values


def format_fmv_line(joint_angles: Iterable[float]) -> str:
    """Format seven joint angles as one FMV data line."""
    parts = [
        f"{field} {float(angle):.6f}"
        for field, angle in zip(FMV_FIELDS, joint_angles, strict=True)
    ]
    parts.extend(("X 0.000000", "Y 0.000000"))
    return "$".join(parts) + "$\n"


def convert_file(
    src_path: str | Path,
    output_dir: str | Path | None = None,
) -> tuple[Path, Path] | None:
    """Convert one data-collection recording into left/right FMV files.

    Args:
        src_path: Path of the native SDK ``.txt`` recording.
        output_dir: FMV output directory. Defaults to the source recording's
            directory.

    Returns:
        The left- and right-arm FMV paths, or ``None`` for an empty recording.

    Raises:
        ValueError: The recording header is not in the expected format.
    """
    source = Path(src_path)
    if source.suffix.lower() != ".txt":
        raise ValueError(f"Expected a .txt recording, got {source}")

    destination = Path(output_dir) if output_dir is not None else source.parent
    left_path = destination / f"{source.stem}_L.fmv"
    right_path = destination / f"{source.stem}_R.fmv"

    with source.open("r", encoding="utf-8") as recording:
        lines = recording.readlines()
    if not lines:
        return None

    header = lines[0].strip()
    if _HEADER_PATTERN.fullmatch(header) is None:
        raise ValueError(f"Invalid recording header in {source}: {header!r}")

    samples = [parse_line(line) for line in lines[1:] if line.strip()]
    destination.mkdir(parents=True, exist_ok=True)

    with (
        left_path.open("w", encoding="utf-8", newline="\n") as left_file,
        right_path.open("w", encoding="utf-8", newline="\n") as right_file,
    ):
        left_file.write(f"PoinType=9@{len(samples)}\n")
        right_file.write(f"PoinType=9@{len(samples)}\n")
        for sample in samples:
            left_file.write(
                format_fmv_line(sample.get(field, 0.0) for field in FMV_FIELDS)
            )
            right_file.write(
                format_fmv_line(
                    sample.get(field, 0.0) for field in B_ARM_SOURCE_FIELDS
                )
            )

    return left_path, right_path


def main() -> None:
    """Convert one recording or all ``.txt`` recordings in a directory."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path, help="Recording file or directory")
    parser.add_argument(
        "--output-dir",
        type=Path,
        help="FMV output root (defaults next to each source recording)",
    )
    args = parser.parse_args()

    sources = (
        sorted(args.source.glob("*.txt"))
        if args.source.is_dir()
        else [args.source]
    )
    for source in sources:
        result = convert_file(source, args.output_dir)
        if result is not None:
            left_path, right_path = result
            print(f"{source} -> {left_path}, {right_path}")


if __name__ == "__main__":
    main()
