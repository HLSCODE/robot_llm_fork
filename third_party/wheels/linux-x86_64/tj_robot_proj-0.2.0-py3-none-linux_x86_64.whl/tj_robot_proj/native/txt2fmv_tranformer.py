"""Convert native data-collection TXT recordings to FMV trajectories.

Native recording rows contain two millisecond timestamps followed by the
selected left-arm columns and then the selected right-arm columns. Column
labels are deliberately ignored: values are interpreted only by their order
and the corresponding :class:`ArmCollectionDataOption`.
"""

from __future__ import annotations

import argparse
from collections.abc import Iterable, Iterator
import math
from pathlib import Path
import re

from tj_robot_proj.value_objects import Arm, ArmCollectionDataOption


FMV_FIELDS = ("Z", "A", "B", "C", "U", "V", "W")
SOURCE_TRAJECTORY_FREQUENCY_HZ = 1000
_JOINT_POSITION_IDS = tuple(range(7))
_HEADER_PATTERN = re.compile(r"PoinType=(\d+)@(\d+)")

_ArmJoints = tuple[float, ...] | None
_Frame = tuple[float, _ArmJoints, _ArmJoints]


def parse_line(line: str) -> tuple[float, ...]:
    """Return numeric values in appearance order, ignoring field labels."""
    values: list[float] = []
    for token in line.strip().split("$"):
        token = token.strip()
        if not token:
            continue
        try:
            values.append(float(token.rsplit(maxsplit=1)[-1]))
        except ValueError as exc:
            raise ValueError(f"Invalid numeric recording token: {token!r}") from exc
    return tuple(values)


def format_fmv_line(joint_angles: Iterable[float]) -> str:
    """Format seven joint angles and two zero tool columns as one FMV row."""
    angles = tuple(float(angle) for angle in joint_angles)
    if len(angles) != len(FMV_FIELDS):
        raise ValueError(f"Expected 7 joint angles, got {len(angles)}")
    parts = [
        f"{field} {angle:.6f}"
        for field, angle in zip(FMV_FIELDS, angles, strict=True)
    ]
    parts.extend(("X 0.000000", "Y 0.000000"))
    return "$".join(parts) + "$\n"


def _joint_offsets(option: ArmCollectionDataOption) -> tuple[int, ...] | None:
    """Locate joint-position IDs 0..6 in one option's ordered columns."""
    if not all(joint_id in option.data_types for joint_id in _JOINT_POSITION_IDS):
        return None
    return tuple(option.data_types.index(joint_id) for joint_id in _JOINT_POSITION_IDS)


def option_supports_fmv(
    option: ArmCollectionDataOption,
    expected_arm: Arm,
) -> bool:
    """Return whether one option can produce a complete seven-joint FMV."""
    return (
        isinstance(option, ArmCollectionDataOption)
        and option.arm is expected_arm
        and _joint_offsets(option) is not None
    )


def _iter_frames(
    source: Path,
    left_arm_option: ArmCollectionDataOption,
    right_arm_option: ArmCollectionDataOption,
    left_offsets: tuple[int, ...] | None,
    right_offsets: tuple[int, ...] | None,
) -> Iterator[_Frame]:
    """Yield timestamp and optional arm joint values from one recording."""
    expected_columns = 2 + left_arm_option.col + right_arm_option.col
    with source.open("r", encoding="utf-8-sig") as recording:
        header = recording.readline().strip()
        if _HEADER_PATTERN.fullmatch(header) is None:
            raise ValueError(f"Invalid recording header in {source}: {header!r}")

        for line_number, line in enumerate(recording, start=2):
            if not line.strip():
                continue
            values = parse_line(line)
            if len(values) < expected_columns:
                raise ValueError(
                    f"Recording row {line_number} in {source} contains "
                    f"{len(values)} values; expected at least {expected_columns}"
                )

            left_joints = (
                tuple(values[2 + offset] for offset in left_offsets)
                if left_offsets is not None
                else None
            )
            right_start = 2 + left_arm_option.col
            right_joints = (
                tuple(values[right_start + offset] for offset in right_offsets)
                if right_offsets is not None
                else None
            )
            yield values[0], left_joints, right_joints


def _missing_frame_count(previous_time_ms: float, current_time_ms: float) -> int:
    """Return the number of evenly spaced frames needed for a time gap."""
    delta_ms = current_time_ms - previous_time_ms
    if not math.isfinite(delta_ms) or delta_ms <= 1.0:
        return 0
    rounded_delta = round(delta_ms)
    if math.isclose(delta_ms, rounded_delta, abs_tol=1e-6):
        delta_ms = float(rounded_delta)
    return max(0, math.ceil(delta_ms) - 1)


def _interpolate_joints(
    previous: _ArmJoints,
    current: _ArmJoints,
    fraction: float,
) -> _ArmJoints:
    if previous is None or current is None:
        return None
    return tuple(
        previous_value + (current_value - previous_value) * fraction
        for previous_value, current_value in zip(previous, current, strict=True)
    )


def _expanded_frame_count(frames: Iterator[_Frame]) -> int:
    """Count source and interpolated frames without retaining the recording."""
    previous = next(frames, None)
    if previous is None:
        return 0
    count = 1
    for current in frames:
        count += 1 + _missing_frame_count(previous[0], current[0])
        previous = current
    return count


def _validate_trajectory_frequency(trajectory_frequency: int) -> None:
    if (
        isinstance(trajectory_frequency, bool)
        or not isinstance(trajectory_frequency, int)
        or not 1 <= trajectory_frequency <= SOURCE_TRAJECTORY_FREQUENCY_HZ
    ):
        raise ValueError(
            "trajectory_frequency must be an integer in [1, 1000] Hz, "
            f"got {trajectory_frequency!r}"
        )


def _downsampled_frame_count(frame_count: int, trajectory_frequency: int) -> int:
    """Return the target count while retaining both ends when possible."""
    if frame_count <= 1:
        return frame_count
    proportional_count = math.ceil(
        frame_count
        * trajectory_frequency
        / SOURCE_TRAJECTORY_FREQUENCY_HZ
    )
    return min(frame_count, max(2, proportional_count))


def _evenly_spaced_indices(
    source_count: int,
    target_count: int,
) -> Iterator[int]:
    """Yield target indices spread across the source, including both ends."""
    if target_count <= 0:
        return
    if target_count == 1:
        yield 0
        return

    source_last = source_count - 1
    target_last = target_count - 1
    for index in range(target_count):
        # Integer half-up rounding avoids Python's ties-to-even behaviour.
        yield (index * source_last * 2 + target_last) // (2 * target_last)


def _downsample_fmv(
    raw_path: Path,
    output_path: Path,
    trajectory_frequency: int,
) -> Path:
    """Downsample a 1000 Hz FMV and remove it after successful conversion."""
    temporary_path = output_path.with_name(f"{output_path.name}.tmp")
    try:
        with raw_path.open("r", encoding="utf-8-sig") as source:
            header = source.readline().strip()
            header_match = _HEADER_PATTERN.fullmatch(header)
            if header_match is None or int(header_match.group(1)) != 9:
                raise ValueError(f"Invalid FMV header in {raw_path}: {header!r}")

            source_count = int(header_match.group(2))
            target_count = _downsampled_frame_count(
                source_count,
                trajectory_frequency,
            )
            selected_indices = iter(
                _evenly_spaced_indices(source_count, target_count)
            )
            next_selected = next(selected_indices, None)
            actual_count = 0

            with temporary_path.open("w", encoding="utf-8", newline="\n") as output:
                output.write(f"PoinType=9@{target_count}\n")
                for source_index, line in enumerate(source):
                    if source_index == next_selected:
                        output.write(line.rstrip("\r\n") + "\n")
                        next_selected = next(selected_indices, None)
                    actual_count += 1

            if actual_count != source_count:
                raise ValueError(
                    f"FMV declares {source_count} rows but contains "
                    f"{actual_count}: {raw_path}"
                )
            if next_selected is not None:
                raise ValueError(f"Unable to downsample all frames from {raw_path}")

        temporary_path.replace(output_path)
        raw_path.unlink()
        return output_path
    except Exception:
        temporary_path.unlink(missing_ok=True)
        raise


def convert_file(
    src_path: str | Path,
    left_arm_option: ArmCollectionDataOption,
    right_arm_option: ArmCollectionDataOption,
    output_dir: str | Path | None = None,
    trajectory_frequency: int = 500,
) -> tuple[Path | None, Path | None] | None:
    """Convert one native TXT recording into applicable arm FMV files.

    Each arm FMV is generated independently when that arm's option contains
    all seven joint position IDs ``0..6``. Other selected data types are
    skipped according to their positions in each option. Gaps over one
    millisecond are first filled with linearly interpolated joint frames to
    produce a 1000 Hz intermediate FMV. Each valid arm FMV is then
    downsampled to ``trajectory_frequency`` while retaining its first and
    final frame. The intermediate file containing ``raw_`` is deleted after
    successful processing.

    Returns the left/right FMV paths (``None`` for an incomplete arm), or
    ``None`` when the recording contains no data rows.
    """
    source = Path(src_path)
    if source.suffix.lower() != ".txt":
        raise ValueError(f"Expected a .txt recording, got {source}")
    _validate_trajectory_frequency(trajectory_frequency)
    left_offsets = (
        _joint_offsets(left_arm_option)
        if option_supports_fmv(left_arm_option, Arm.LEFT)
        else None
    )
    right_offsets = (
        _joint_offsets(right_arm_option)
        if option_supports_fmv(right_arm_option, Arm.RIGHT)
        else None
    )
    if left_offsets is None and right_offsets is None:
        return None, None

    frame_count = _expanded_frame_count(
        _iter_frames(
            source,
            left_arm_option,
            right_arm_option,
            left_offsets,
            right_offsets,
        )
    )
    if frame_count == 0:
        return None

    destination = Path(output_dir) if output_dir is not None else source.parent
    destination.mkdir(parents=True, exist_ok=True)
    output_stem = (
        source.stem.removesuffix("_raw")
        if source.stem.endswith("_raw")
        else source.stem
    )
    left_raw_path = (
        destination / f"{output_stem}_raw_L.fmv" if left_offsets else None
    )
    right_raw_path = (
        destination / f"{output_stem}_raw_R.fmv" if right_offsets else None
    )
    left_path = destination / f"{output_stem}_L.fmv" if left_offsets else None
    right_path = destination / f"{output_stem}_R.fmv" if right_offsets else None

    frames = _iter_frames(
        source,
        left_arm_option,
        right_arm_option,
        left_offsets,
        right_offsets,
    )
    previous = next(frames)
    with (
        left_raw_path.open("w", encoding="utf-8", newline="\n")
        if left_raw_path is not None
        else _NullWriter()
    ) as left_file, (
        right_raw_path.open("w", encoding="utf-8", newline="\n")
        if right_raw_path is not None
        else _NullWriter()
    ) as right_file:
        if left_raw_path is not None:
            left_file.write(f"PoinType=9@{frame_count}\n")
            left_file.write(format_fmv_line(previous[1]))
        if right_raw_path is not None:
            right_file.write(f"PoinType=9@{frame_count}\n")
            right_file.write(format_fmv_line(previous[2]))

        for current in frames:
            missing_frames = _missing_frame_count(previous[0], current[0])
            for index in range(1, missing_frames + 1):
                fraction = index / (missing_frames + 1)
                if left_raw_path is not None:
                    left_file.write(
                        format_fmv_line(
                            _interpolate_joints(previous[1], current[1], fraction)
                        )
                    )
                if right_raw_path is not None:
                    right_file.write(
                        format_fmv_line(
                            _interpolate_joints(previous[2], current[2], fraction)
                        )
                    )
            if left_raw_path is not None:
                left_file.write(format_fmv_line(current[1]))
            if right_raw_path is not None:
                right_file.write(format_fmv_line(current[2]))
            previous = current

    if left_raw_path is not None and left_path is not None:
        _downsample_fmv(left_raw_path, left_path, trajectory_frequency)
    if right_raw_path is not None and right_path is not None:
        _downsample_fmv(right_raw_path, right_path, trajectory_frequency)

    return left_path, right_path


class _NullWriter:
    """No-op context manager used when one arm has no FMV output."""

    def __enter__(self) -> "_NullWriter":
        return self

    def __exit__(self, *args: object) -> None:
        return None

    def write(self, value: str) -> int:
        return len(value)


def _data_types(value: str) -> tuple[int, ...]:
    return tuple(int(item.strip()) for item in value.split(",") if item.strip())


def main() -> None:
    """Convert one recording or all TXT recordings in a directory."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path, help="Recording file or directory")
    parser.add_argument(
        "--output-dir",
        type=Path,
        help="FMV output root (defaults next to each source recording)",
    )
    parser.add_argument("--left-data-types", default="0,1,2,3,4,5,6")
    parser.add_argument("--right-data-types", default="0,1,2,3,4,5,6")
    parser.add_argument(
        "--trajectory-frequency",
        type=int,
        default=500,
        help="Output FMV frequency in Hz (1..1000, default: 500)",
    )
    args = parser.parse_args()

    left_option = ArmCollectionDataOption(
        arm=Arm.LEFT,
        data_types=_data_types(args.left_data_types),
    )
    right_option = ArmCollectionDataOption(
        arm=Arm.RIGHT,
        data_types=_data_types(args.right_data_types),
    )
    sources = (
        sorted(args.source.glob("*_raw.txt"))
        if args.source.is_dir()
        else [args.source]
    )
    for source in sources:
        result = convert_file(
            source,
            left_option,
            right_option,
            args.output_dir,
            args.trajectory_frequency,
        )
        if result is not None:
            print(f"{source} -> {result[0]}, {result[1]}")


if __name__ == "__main__":
    main()
