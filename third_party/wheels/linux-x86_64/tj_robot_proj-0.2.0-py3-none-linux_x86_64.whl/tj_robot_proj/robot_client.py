"""``RobotClient`` — the single, typed, production-grade public entry point.

Lifecycle::

    client = RobotClient(config)   # no side effects
    client.initialize()            # connect, initialise, and start state subscription
    # ... use ...
    client.close()                 # idempotent shutdown

Context-manager support::

    with RobotClient(config) as client:
        client.initialize()
"""

from __future__ import annotations

import logging
import math
import time
from types import TracebackType
from typing import Iterable, Type

from tj_robot_proj.errors import ConfigurationError
from tj_robot_proj.native.session import NativeSession

from tj_robot_proj.value_objects import *

logger = logging.getLogger(__name__)


class RobotClient:
    """Top-level entry point for controlling a dual-arm robot.

    One ``RobotClient`` corresponds to one controller session.
    """

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    def __init__(self, config: RobotConfig) -> None:
        """Create a client with the given *config*.

        **No hardware is touched at this point** — the constructor only
        stores the validated configuration.
        """
        self._config = config
        self._session = NativeSession(config)

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> "RobotClient":
        return self

    def __exit__(
        self,
        exc_type: Type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self.close()

    def __del__(self) -> None:
        if not self._session.closed:
            logger.warning(
                "RobotClient was not explicitly closed; "
                "releasing in __del__.  This is unreliable — use a "
                "context manager or call close() explicitly."
            )
            self.close()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def initialize(self) -> None:
        """Connect to and initialise the robot.

        Loads the native libraries, establishes the TCP connection, clears
        errors, sets position mode, initialises kinematics, and starts the
        background state subscription.

        Raises:
            NativeLibraryError: The native DLL/SO could not be loaded.
            ConnectionError: TCP connection to the controller failed.
            InitializationError: Initialisation failed (errors, kinematics, etc.).
        """
        self._session.connect()
        self._session.initialize()
        # Start the background state subscription.
        self._session.start_subscription()

    def close(self) -> None:
        """Idempotent shutdown.

        Stops the background subscription, releases the native connection,
        and frees native resources.  Safe to call multiple times.
        """
        self._session.stop_subscription()
        self._session.close()

    # ------------------------------------------------------------------
    # Get robot state
    # ------------------------------------------------------------------
    def get_arm_data(self, arm: Arm) -> ArmData :
        return self._session.get_arm_data(arm=arm)

    # ------------------------------------------------------------------
    # Motion
    # ------------------------------------------------------------------

    def movej(
        self,
        arm: Arm,
        joints_rad: Iterable[float] | None = None,
        joints_deg: Iterable[float] | None = None,
        vel: int = 10,
        is_block: bool = True,
        tolerance: float = 0.07,
    ) -> None:
        """Move *arm* to a joint-space target.

        Supply either ``joints_rad`` or ``joints_deg``.  When both are
        supplied, ``joints_rad`` takes precedence.  Joint limits come from
        the corresponding arm entry in :class:`RobotConfig`.

        ``vel`` is percentage 1~100

        When ``is_block`` is true, this method polls feedback every 50 ms and
        returns only after every joint is within ``tolerance`` radians of the
        effective target. Targets outside configured joint limits are clipped
        to the nearest limit before they are sent.

        Raises:
            ConfigurationError: The command parameters are invalid.
        """
        if not isinstance(arm, Arm):
            raise ConfigurationError(
                f"arm must be an Arm, got {arm!r}", operation="movej"
            )
        if joints_rad is None and joints_deg is None:
            raise ConfigurationError(
                "Provide joints_rad or joints_deg", operation="movej", arm=arm.value
            )
        try:
            tolerance = float(tolerance)
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(
                f"tolerance must be a positive finite value, got {tolerance!r}",
                operation="movej",
                arm=arm.value,
            ) from exc
        if tolerance <= 0 or not math.isfinite(tolerance):
            raise ConfigurationError(
                f"tolerance must be a positive finite value, got {tolerance}",
                operation="movej",
                arm=arm.value,
            )

        limits = (
            self._config.left_arm_config.joints_limit
            if arm is Arm.LEFT
            else self._config.right_arm_config.joints_limit
        )
        try:
            target_rad = tuple(
                float(value)
                for value in (joints_rad if joints_rad is not None else joints_deg)
            )
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(
                "Joint targets must be numeric", operation="movej", arm=arm.value
            ) from exc
        if joints_rad is None:
            target_rad = tuple(math.radians(value) for value in target_rad)

        if len(target_rad) != limits.num_joints:
            raise ConfigurationError(
                f"Expected {limits.num_joints} joint targets, got {len(target_rad)}",
                operation="movej",
                arm=arm.value,
            )
        for index, target in enumerate(target_rad):
            if not math.isfinite(target):
                raise ConfigurationError(
                    f"joints_rad[{index}] must be finite, got {target}",
                    operation="movej",
                    arm=arm.value,
                )
        target_rad = tuple(
            min(max(target, minimum), maximum)
            for target, (minimum, maximum) in zip(target_rad, limits, strict=True)
        )

        if isinstance(vel, bool) or not isinstance(vel, int) or not 0 <= vel <= 100:
            raise ConfigurationError(
                f"vel must be an integer in [0, 100], got {vel!r}",
                operation="movej",
                arm=arm.value,
            )

        self._session.send_joint_command(
            arm.value,
            list(map(math.degrees, target_rad)),
            vel,
        )

        if not is_block:
            return

        while True:
            feedback_rad = self.get_arm_data(arm).joints_pos.pos_rad
            if all(
                abs(feedback - target) < tolerance
                for feedback, target in zip(feedback_rad, target_rad, strict=True)
            ):
                return
            time.sleep(0.05)

    def movej_step(
        self,
        arm: Arm,
        joints_step_rad: Iterable[float] | None = None,
        joints_step_deg: Iterable[float] | None = None,
        vel: int = 10,
        is_block: bool = True,
        tolerance: float = 0.07,
    ) -> None:
        """Move *arm* by a joint-space increment from its current position.

        Supply either ``joints_step_rad`` or ``joints_step_deg``. When both
        are supplied, the radian increment takes precedence. The resulting
        absolute target is sent through :meth:`movej`, where it is clipped to
        the configured joint limits before sending and blocking.
        """
        if not isinstance(arm, Arm):
            raise ConfigurationError(
                f"arm must be an Arm, got {arm!r}", operation="movej_step"
            )
        if joints_step_rad is None and joints_step_deg is None:
            raise ConfigurationError(
                "Provide joints_step_rad or joints_step_deg",
                operation="movej_step",
                arm=arm.value,
            )

        current_positions = self.get_arm_data(arm).joints_pos
        steps = joints_step_rad if joints_step_rad is not None else joints_step_deg
        try:
            steps = tuple(float(value) for value in steps)
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(
                "Joint steps must be numeric", operation="movej_step", arm=arm.value
            ) from exc
        if len(steps) != current_positions.num_joints:
            raise ConfigurationError(
                f"Expected {current_positions.num_joints} joint steps, got {len(steps)}",
                operation="movej_step",
                arm=arm.value,
            )

        if joints_step_rad is not None:
            target_rad = tuple(
                current + step
                for current, step in zip(current_positions.pos_rad, steps, strict=True)
            )
            self.movej(
                arm,
                joints_rad=target_rad,
                vel=vel,
                is_block=is_block,
                tolerance=tolerance,
            )
            return

        target_deg = tuple(
            current + step
            for current, step in zip(current_positions.pos_deg, steps, strict=True)
        )
        self.movej(
            arm,
            joints_deg=target_deg,
            vel=vel,
            is_block=is_block,
            tolerance=tolerance,
        )

    def movel(
        self,
        arm: Arm,
        T_end_ref_world: SE3,
        vel: int = 10,
        is_block: bool = True,
        tolerance: float = 0.02,
    ) -> None:
        """Move *arm* linearly to ``T_end_ref_world``.

        ``vel`` is a percentage in ``[1, 100]``. When ``is_block`` is true,
        the current end-effector pose is sampled every 50 ms. The motion is
        considered complete when every component of the relative pose error
        ``current_T.inverse() @ target_T`` in ``se(3)`` is smaller than
        ``tolerance``. Its first three components are radians and its last
        three components are metres.
        """
        if not isinstance(arm, Arm):
            raise ConfigurationError(
                f"arm must be an Arm, got {arm!r}", operation="movel"
            )
        if not isinstance(T_end_ref_world, SE3):
            raise ConfigurationError(
                "T_end_ref_world must be an SE3", operation="movel", arm=arm.value
            )
        try:
            tolerance = float(tolerance)
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(
                f"tolerance must be a positive finite value, got {tolerance!r}",
                operation="movel",
                arm=arm.value,
            ) from exc
        if tolerance <= 0 or not math.isfinite(tolerance):
            raise ConfigurationError(
                f"tolerance must be a positive finite value, got {tolerance}",
                operation="movel",
                arm=arm.value,
            )

        self._session.send_linear_command(
            arm.value,
            T_end_ref_world,
            vel,
        )

        if not is_block:
            return

        while True:
            current_T_end_ref_world = self.get_arm_data(arm).T_end_ref_world
            pose_error_se3 = (
                current_T_end_ref_world.inverse() @ T_end_ref_world
            ).log()
            if all(abs(float(error)) < tolerance for error in pose_error_se3):
                return
            time.sleep(0.05)

    def movel_step(
        self,
        arm: Arm,
        T_end_ref_current_end: SE3,
        vel: int = 10,
        is_block: bool = True,
        tolerance: float = 0.02,
    ) -> None:
        """Move *arm* by an end-effector pose increment.

        The increment is expressed in the current end-effector frame. The
        next world-frame target is therefore ``current_T_end_ref_world @
        T_end_ref_current_end``. A pure rotational increment with zero
        translation preserves the current end-effector world position.
        """
        if not isinstance(arm, Arm):
            raise ConfigurationError(
                f"arm must be an Arm, got {arm!r}", operation="movel_step"
            )
        if not isinstance(T_end_ref_current_end, SE3):
            raise ConfigurationError(
                "T_end_ref_current_end must be an SE3",
                operation="movel_step",
                arm=arm.value,
            )

        current_T_end_ref_world = self.get_arm_data(arm).T_end_ref_world
        target_T_end_ref_world = (
            current_T_end_ref_world @ T_end_ref_current_end
        )
        self.movel(
            arm,
            target_T_end_ref_world,
            vel=vel,
            is_block=is_block,
            tolerance=tolerance,
        )

    # ------------------------------------------------------------------
    # Data Collection
    # ------------------------------------------------------------------

    def collect_data(
        self,
        left_arm_option: ArmCollectionDataOption | None = None,
        right_arm_option: ArmCollectionDataOption | None = None,
    ) -> bool:
        """Start controller data collection with 1,000,000 requested records.

        Args:
            left_arm_option: Optional left-arm collection data selection.
            right_arm_option: Optional right-arm collection data selection.

        The left-arm selection is sent before the right-arm selection. Their
        combined target ID count must not exceed 35; unused native list slots
        are padded with zeroes.
        """
        return self._session.collect_data(left_arm_option, right_arm_option)

    def stop_collect_data(self) -> bool:
        """Stop controller data collection."""
        return self._session.stop_collect_data()

    def save_collected_data(
        self,
        dir: str,
        left_arm_option: ArmCollectionDataOption,
        right_arm_option: ArmCollectionDataOption,
    ) -> bool:
        """Save raw and split arm data into timestamped TXT files.

        Args:
            left_arm_option: The same left-arm collection option passed to
                :meth:`collect_data`.
            right_arm_option: The same right-arm collection option passed to
                :meth:`collect_data`.

        The output directory contains the native raw file plus left- and
        right-arm files. The options determine how native left-then-right
        columns are split into the two arm files.
        """
        return self._session.save_collected_data(
            dir,
            left_arm_option,
            right_arm_option,
        )

    # ------------------------------------------------------------------
    # Lifecycle state
    # ------------------------------------------------------------------

    @property
    def connected(self) -> bool:
        """Whether the controller connection is currently established."""
        return self._session.connected

    @property
    def initialised(self) -> bool:
        """Whether ``initialize()`` has completed successfully."""
        return self._session.initialised

    @property
    def closed(self) -> bool:
        """Whether the client has been closed."""
        return self._session.closed
