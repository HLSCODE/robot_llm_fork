# 值对象（Value Objects）

不可变、类型化的数据模型，基于 `frozen=True, slots=True` 的 dataclass 构建。

- `arm` — 单臂对象：`Arm` / `ArmConfig` / `JointPositions` /
  `JointVelocity` / `ArmData` / `JointsLimit` / `TransformationConfig`
- `robot_config` — 会话与采集配置：`ArmCollectionDataOption` / `RobotConfig`
- `lie_group` — 李群值对象：`SO3` / `SE3`（见 [lie_group/README.md](lie_group/README.md)）

```python
from tj_robot_proj.value_objects.arm import (
    Arm, ArmConfig, ArmData,
    JointsLimit,
    JointPositions,
    TransformationConfig,
    JointVelocity,
)
from tj_robot_proj.value_objects.robot_config import (
    ArmCollectionDataOption,
    RobotConfig,
)
from tj_robot_proj.value_objects.lie_group import SE3
```

所有类都是不可变且可哈希的（它们本身是纯数据容器，无群运算），因此实例可用作字典键或集合成员。

---

## arm 包

### arm_enum 模块

#### Arm

双臂标识枚举：`Arm.LEFT` 的底层值为 `"A"`，`Arm.RIGHT` 的底层值为
`"B"`。

```python
Arm.LEFT.value   # "A"
Arm.RIGHT.value  # "B"
```

### arm_data 模块

#### JointPositions

关节角度。规范内部表示是 **弧度**（`pos_rad`）；在 API 边界提供了度的构造器与访问器。

**构造**

`num_joints` 是 **必传** 参数，没有默认值。

```python
import math
import numpy as np

# 从度构造（内部转换为弧度）
p = JointPositions.from_deg([10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0], num_joints=7)

# 从弧度构造（原样存储）
p = JointPositions.from_rad([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7], num_joints=7)

# 直接构造（弧度）
p = JointPositions(pos_rad=(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7), num_joints=7)

# 支持任意关节数
p3 = JointPositions.from_deg([1.0, 2.0, 3.0], num_joints=3)
```

**访问**

```python
p.pos_rad      # 浮点元组 —— 弧度（内部表示）
p.pos_deg      # 浮点元组 —— 度

len(p)         # 关节数（== num_joints）
p[0]           # 弧度（序列协议基于弧度）
list(p)        # 按弧度迭代
```

> 注意：度 ↔ 弧度的转换存在浮点舍入误差，因此 `from_deg(...).pos_deg`
> 可能与输入相差约 1e-15。

**校验**

构造器会拒绝与 `num_joints` 不匹配或非有限的值：

```python
JointPositions.from_deg([1] * 6, num_joints=7)          # ValueError: 长度错误
JointPositions(pos_rad=(0.0, float("nan"), 0, 0, 0, 0, 0), num_joints=7)  # ValueError: 非有限值
```

#### JointVelocity

关节速度。规范内部表示是 **rad/s**（`vel_rad_s`）；提供了度/秒（deg/s）的构造器与访问器。

**构造**

```python
# 从度/秒构造
v = JointVelocity.from_deg_s([5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0], num_joints=7)

# 从 rad/s 构造
v = JointVelocity.from_rad_s([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7], num_joints=7)

# 直接构造（rad/s）
v = JointVelocity(vel_rad_s=(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7), num_joints=7)
```

**访问**

```python
v.vel_rad_s    # 浮点元组 —— rad/s（内部表示）
v.vel_deg_s    # 浮点元组 —— 度/秒

len(v)         # 关节数（== num_joints）
v[0]           # rad/s
list(v)        # 按 rad/s 迭代
```

#### ArmData

单条机械臂的完整状态快照：关节位置与速度、两个 SE(3) 变换、末端按钮状态。

##### 字段

| 字段 | 类型 | 含义 |
|------|------|------|
| `arm` | `Arm` | 哪条臂（`LEFT` / `RIGHT`） |
| `joints_pos` | `JointPositions` | 关节角度（内部为弧度） |
| `joints_vel` | `JointVelocity` | 关节速度（内部为 rad/s） |
| `T_end_ref_world` | `SE3` | 末端坐标系 → 世界坐标系 |
| `T_tool_ref_world` | `SE3` | 工具坐标系 → 世界坐标系 |
| `num_joints` | `int` | 关节数 |
| `button_pressed` | `bool` | 末端按钮状态（默认 `False`） |

**构造**

```python
T = SE3.identity()

ad = ArmData(
    arm=Arm.LEFT,
    joints_pos=JointPositions.from_deg([0, 10, 20, 30, 40, 50, 60], num_joints=7),
    joints_vel=JointVelocity.from_deg_s([0, 0, 0, 0, 0, 0, 0], num_joints=7),
    T_end_ref_world=T,
    T_tool_ref_world=T,
    num_joints=7,
    button_pressed=False,
)
```

`ArmData` 会校验 `num_joints` 与 `joints_pos.num_joints`、`joints_vel.num_joints`
三者一致：

```python
ArmData(
    arm=Arm.LEFT,
    joints_pos=JointPositions.from_deg([1, 2, 3], num_joints=3),   # 3 个关节
    joints_vel=JointVelocity.from_deg_s([0, 0, 0, 0, 0, 0, 0], num_joints=7),  # 7 个关节
    T_end_ref_world=T, T_tool_ref_world=T,
    num_joints=7,
)  # ValueError: joints_pos.num_joints (3) != num_joints (7)
```

**访问**

```python
ad.arm               # Arm.LEFT
ad.joints_pos        # JointPositions
ad.joints_vel        # JointVelocity
ad.joints_pos.pos_deg   # 度
ad.joints_vel.vel_deg_s # 度/秒
ad.T_end_ref_world   # SE3 —— 可用 .matrix / .rotation / .translation 等
ad.num_joints        # 7
ad.button_pressed    # False
```

### arm_config 模块

#### JointsLimit

每个关节的位置范围。`limits_rad` 保存 `num_joints` 组 `(min, max)`，规范
内部表示是 **弧度**。未提供限位时，每个关节默认使用 `(-π, π)`。

**构造**

```python
# 默认：每个关节均为 (-π, π)
limits = JointsLimit(num_joints=7)

# 从弧度构造，每项为 (min, max)
limits = JointsLimit.from_rad(
    [(-3.14, 3.14), (-1.5, 1.5), (-2.0, 2.0)],
    num_joints=3,
)

# 从度构造
limits = JointsLimit.from_deg(
    [(-180.0, 180.0), (-90.0, 90.0), (-120.0, 120.0)],
    num_joints=3,
)

# 直接构造（弧度）
limits = JointsLimit(
    num_joints=3,
    limits_rad=((-3.14, 3.14), (-1.5, 1.5), (-2.0, 2.0)),
)
```

**访问**

```python
limits.limits_rad  # ((min_rad, max_rad), ...) —— 弧度（内部表示）
limits.limits_deg  # ((min_deg, max_deg), ...) —— 度

len(limits)        # 关节数（== num_joints）
limits[0]          # (min_rad, max_rad)
list(limits)       # 按弧度的 (min, max) 对迭代
```

**校验**

`JointsLimit` 会校验关节数、限位对数量、限位值有限性，以及每对限位满足
`min <= max`：

```python
JointsLimit.from_rad([(-1.0, 1.0)], num_joints=2)  # ValueError: 长度错误
JointsLimit.from_rad([(1.0, -1.0)], num_joints=1)  # ValueError: min > max
```

#### TransformationConfig

单条机械臂的坐标系变换配置，两个字段均为 `SE3`（必传）。

##### 字段

| 字段 | 类型 | 含义 |
|------|------|------|
| `T_base_ref_world` | `SE3` | 基座参考坐标系 → 世界坐标系 |
| `T_tool_ref_end` | `SE3` | 工具坐标系 → 末端坐标系 |

**构造**

```python
tc = TransformationConfig(
    T_base_ref_world=SE3.identity(),
    T_tool_ref_end=SE3.identity(),
)
```

**访问**

```python
tc.T_base_ref_world   # SE3 —— 基座参考 → 世界
tc.T_tool_ref_end     # SE3 —— 工具 → 末端
```

#### ArmConfig

单臂配置，聚合机械臂标识、坐标系变换与关节限位。

##### 字段

| 字段 | 类型 | 含义 |
|------|------|------|
| `arm` | `Arm` | 该配置对应的机械臂 |
| `trans_config` | `TransformationConfig` | 该臂的坐标系变换 |
| `joints_limit` | `JointsLimit` | 该臂的关节位置限位 |

**构造与访问**

```python
left_arm = ArmConfig(
    arm=Arm.LEFT,
    trans_config=tc,
    joints_limit=JointsLimit(num_joints=7),
)

left_arm.arm                    # Arm.LEFT
left_arm.trans_config           # TransformationConfig
left_arm.joints_limit           # JointsLimit
```

---

## robot_config 模块

### ArmCollectionDataOption

单臂数据采集配置。`data_types` 是不可变元组，每项表示一个采集数据类型；
`col` 会在构造时自动计算为数据类型数量，不能单独传入。

| ID 范围 | 采集数据 |
|---------|----------|
| `0`–`6` | 关节位置 |
| `10`–`16` | 关节速度 |
| `20`–`26` | 外编位置 |
| `30`–`36` | 关节指令位置 |
| `40`–`46` | 关节电流（千分比） |
| `50`–`56` | 关节传感器扭矩（Nm） |
| `60`–`66` | 关节摩擦力估计值 |
| `70`–`76` | 关节摩擦力速度估计值 |
| `80`–`85` | 关节外力估计值 |
| `90`–`95` | 末端点外力估计值 |

**构造与访问**

```python
# 采集第 1～7 关节的位置与速度
option = ArmCollectionDataOption(
    arm=Arm.RIGHT,
    data_types=(0, 1, 2, 3, 4, 5, 6, 10, 11, 12, 13, 14, 15, 16),
)

option.col         # 14：单帧采集数据长度
option.data_types  # 本地数据类型 ID 元组
option.target_ids  # 原生 SDK 目标 ID；右臂自动加 100
```

**校验**

`arm` 必须为 `Arm`；`data_types` 必须非空、全部来自上表且不能重复。值对象
本身不限制条目数；`RobotConfig` 中左右臂选项的列数合计最多为 35，SDK 会在
原生 `target_id` 列表末尾补 `0` 至固定 35 项。

### RobotConfig

`RobotClient` 会话配置。

#### 字段

| 字段 | 类型 | 含义 |
|------|------|------|
| `controller_ip` | `str` | 机器人控制器 IPv4 地址（必传） |
| `left_arm_config` | `ArmConfig` | 左臂配置（必传） |
| `right_arm_config` | `ArmConfig` | 右臂配置（必传） |
| `left_arm_collection_data_option` | `ArmCollectionDataOption` | 左臂采集配置（必传） |
| `right_arm_collection_data_option` | `ArmCollectionDataOption` | 右臂采集配置（必传） |
| `subscription_interval_seconds` | `float` | 状态订阅线程周期（默认 `0.01`） |
| `trajectory_frequency` | `int` | 轨迹频率，单位 Hz（默认 `500`） |
| `traj_data_dir` | `str` | 轨迹数据保存根目录；Linux 默认 `/tmp/tj_trajectory_data`，Windows 默认 `C:\tj_trajectory_data` |

**构造**

```python
limits = JointsLimit.from_rad(
    [(-3.1067, 3.1067), (-2.0944, 2.0944), (-3.1067, 3.1067),
     (-2.5307, 1.0472), (-3.1067, 3.1067), (-1.0472, 1.0472),
     (-1.5708, 1.5708)],
    num_joints=7,
)
left_option = ArmCollectionDataOption(Arm.LEFT, (0, 1, 2, 3, 4, 5, 6))
right_option = ArmCollectionDataOption(Arm.RIGHT, (0, 1, 2, 3, 4, 5, 6))

cfg = RobotConfig(
    controller_ip="192.168.1.190",
    left_arm_config=ArmConfig(
        arm=Arm.LEFT,
        trans_config=tc,
        joints_limit=limits,
    ),
    right_arm_config=ArmConfig(
        arm=Arm.RIGHT,
        trans_config=tc,
        joints_limit=limits,
    ),
    left_arm_collection_data_option=left_option,
    right_arm_collection_data_option=right_option,
    subscription_interval_seconds=0.01,
    trajectory_frequency=500,
    # 可选覆盖；不传时自动使用当前平台的默认目录
    traj_data_dir="/data/tj_trajectory_data",
)
```

**访问**

```python
cfg.controller_ip                  # "192.168.1.190"
cfg.left_arm_config                # ArmConfig
cfg.right_arm_config               # ArmConfig
cfg.left_arm_collection_data_option   # ArmCollectionDataOption
cfg.right_arm_collection_data_option  # ArmCollectionDataOption
cfg.left_arm_config.trans_config   # TransformationConfig
cfg.left_arm_config.joints_limit   # JointsLimit
cfg.subscription_interval_seconds  # 0.01
cfg.trajectory_frequency           # 500
cfg.traj_data_dir                  # 已创建并规范化的绝对目录路径
```

**校验**

`controller_ip` 必须是合法 IPv4；两侧采集选项必须分别属于左、右臂，且合计不超过
35 列；`subscription_interval_seconds` 必须 > 0；
`trajectory_frequency` 必须是 `1` 到 `1000` 之间的整数，单位为 Hz。保存轨迹时，
原始 `1000 Hz` FMV 会按该字段分频。`traj_data_dir` 必须是非空字符串；目录不存在
时自动递归创建，已有路径必须是可写目录。

```python
RobotConfig(controller_ip="not-an-ip",
            left_arm_config=ArmConfig(Arm.LEFT, tc, JointsLimit(num_joints=7)),
            right_arm_config=ArmConfig(Arm.RIGHT, tc, JointsLimit(num_joints=7)),
            left_arm_collection_data_option=left_option,
            right_arm_collection_data_option=right_option)         # ValueError: 非法 IPv4

RobotConfig(controller_ip="192.168.1.1",
            left_arm_config=ArmConfig(Arm.LEFT, tc, JointsLimit(num_joints=7)),
            right_arm_config=ArmConfig(Arm.RIGHT, tc, JointsLimit(num_joints=7)),
            left_arm_collection_data_option=left_option,
            right_arm_collection_data_option=right_option,
            subscription_interval_seconds=0)                       # ValueError: 非正数

RobotConfig(controller_ip="192.168.1.1",
            left_arm_config=ArmConfig(Arm.LEFT, tc, JointsLimit(num_joints=7)),
            right_arm_config=ArmConfig(Arm.RIGHT, tc, JointsLimit(num_joints=7)),
            left_arm_collection_data_option=left_option,
            right_arm_collection_data_option=right_option,
            trajectory_frequency=1001)                             # ValueError: 超出范围
```
