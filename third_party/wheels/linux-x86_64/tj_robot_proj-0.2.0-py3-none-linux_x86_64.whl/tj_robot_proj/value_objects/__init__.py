"""Value objects — immutable configuration and domain models.

This subpackage holds the SDK's pure-data types:

- ``arm`` — ``Arm`` / ``ArmConfig`` / ``JointPositions`` / ``JointVelocity`` /
  ``ArmData`` / ``JointsLimit`` / ``TransformationConfig``
- ``robot_config`` — ``ArmCollectionDataOption`` / ``RobotConfig``
- ``lie_group`` — ``SO3`` / ``SE3``
"""

from tj_robot_proj.value_objects.arm import (
    ArmData,
    Arm,
    ArmConfig,
    JointPositions,
    JointVelocity,
    JointsLimit,
    TransformationConfig,
)
from tj_robot_proj.value_objects.robot_config import (
    ArmCollectionDataOption,
    RobotConfig,
)
from tj_robot_proj.value_objects.lie_group import SE3, SO3

__all__ = [
    "Arm",
    "ArmConfig",
    "ArmCollectionDataOption",
    "ArmData",
    "JointPositions",
    "JointsLimit",
    "JointVelocity",
    "TransformationConfig",
    "RobotConfig",
    "SO3",
    "SE3",
]
