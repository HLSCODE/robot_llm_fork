from __future__ import annotations

from dataclasses import dataclass, field
from typing import ClassVar

from tj_robot_proj.value_objects.arm.arm_enum import Arm


@dataclass(frozen=True, slots=True)
class ArmCollectionDataOption:
    """Data types to collect for one arm.

    ``data_types`` 保存采集数据类型 ID。元组中的每项对应单帧中的一个值，
    因此 :attr:`col` 在构造时自动计算为所选 ID 数量。:attr:`target_ids`
    会根据 :attr:`arm` 自动生成原生 SDK 所需的目标 ID。

    数据类型 ID：

    - ``0``–``6``：关节位置
    - ``10``–``16``：关节速度
    - ``20``–``26``：外编位置
    - ``30``–``36``：关节指令位置
    - ``40``–``46``：关节电流（千分比）
    - ``50``–``56``：关节传感器扭矩（Nm）
    - ``60``–``66``：关节摩擦力估计值
    - ``70``–``76``：关节摩擦力速度估计值
    - ``80``–``85``：关节外力估计值
    - ``90``–``95``：末端点外力估计值
    """

    arm: Arm
    data_types: tuple[int, ...]
    col: int = field(init=False)

    _VALID_DATA_TYPES: ClassVar[frozenset[int]] = frozenset(
        (*range(0, 7), *range(10, 17), *range(20, 27), *range(30, 37),
         *range(40, 47), *range(50, 57), *range(60, 67), *range(70, 77),
         *range(80, 86), *range(90, 96))
    )

    def __post_init__(self) -> None:
        if not isinstance(self.arm, Arm):
            raise ValueError(f"arm must be an Arm, got {self.arm!r}")
        values = tuple(int(value) for value in self.data_types)
        if not values:
            raise ValueError("data_types must not be empty")
        invalid = tuple(value for value in values if value not in self._VALID_DATA_TYPES)
        if invalid:
            raise ValueError(f"Unsupported collection data type IDs: {invalid}")
        if len(set(values)) != len(values):
            raise ValueError("data_types must not contain duplicates")

        object.__setattr__(self, "data_types", values)
        object.__setattr__(self, "col", len(values))

    @property
    def target_ids(self) -> tuple[int, ...]:
        """Native SDK target IDs for this arm."""
        offset = 0 if self.arm is Arm.LEFT else 100
        return tuple(offset + value for value in self.data_types)
