"""Immutable configuration for connecting to and controlling a dual-arm robot."""

from __future__ import annotations

import math
from dataclasses import dataclass

from tj_robot_proj.value_objects.arm.arm_enum import Arm
from tj_robot_proj.value_objects.lie_group import SE3


@dataclass(frozen=True, slots=True)
class JointsLimit:
    """Per-joint position limits, stored internally in radians.

    ``limits_rad`` contains one ``(min, max)`` pair for each joint.  When no
    limits are supplied, every joint defaults to ``(-pi, pi)``.  Construct
    from degrees with :meth:`from_deg` (or radians with :meth:`from_rad`) and
    read back degrees with :attr:`limits_deg`.

    The sequence protocol (``len`` / indexing / iteration) operates on the
    internal radians.
    """

    num_joints: int
    limits_rad: tuple[tuple[float, float], ...] = ()

    def __post_init__(self) -> None:
        num_joints = int(self.num_joints)
        if num_joints < 1:
            raise ValueError(f"num_joints must be >= 1, got {self.num_joints}")

        values = tuple(
            (float(minimum), float(maximum))
            for minimum, maximum in self.limits_rad
        )
        if not values:
            values = ((-math.pi, math.pi),) * num_joints
        if len(values) != num_joints:
            raise ValueError(
                f"JointsLimit requires exactly {num_joints} limit pairs, "
                f"got {len(values)}"
            )
        for index, (minimum, maximum) in enumerate(values):
            if not math.isfinite(minimum) or not math.isfinite(maximum):
                raise ValueError(
                    f"limits_rad[{index}] must contain finite values, "
                    f"got ({minimum}, {maximum})"
                )
            if minimum > maximum:
                raise ValueError(
                    f"limits_rad[{index}] minimum ({minimum}) must be <= "
                    f"maximum ({maximum})"
                )

        object.__setattr__(self, "num_joints", num_joints)
        object.__setattr__(self, "limits_rad", values)

    @classmethod
    def from_rad(
        cls, values_rad, num_joints: int
    ) -> "JointsLimit":
        """Construct from ``(min, max)`` joint limits in radians."""
        return cls(
            num_joints=num_joints,
            limits_rad=tuple(
                (float(minimum), float(maximum))
                for minimum, maximum in values_rad
            ),
        )

    @classmethod
    def from_deg(
        cls, values_deg, num_joints: int
    ) -> "JointsLimit":
        """Construct from ``(min, max)`` joint limits in degrees."""
        return cls(
            num_joints=num_joints,
            limits_rad=tuple(
                (math.radians(float(minimum)), math.radians(float(maximum)))
                for minimum, maximum in values_deg
            ),
        )

    @property
    def limits_deg(self) -> tuple[tuple[float, float], ...]:
        """Per-joint ``(min, max)`` limits in degrees."""
        return tuple(
            (math.degrees(minimum), math.degrees(maximum))
            for minimum, maximum in self.limits_rad
        )

    def __len__(self) -> int:
        return len(self.limits_rad)

    def __getitem__(self, index: int) -> tuple[float, float]:
        return self.limits_rad[index]

    def __iter__(self):
        return iter(self.limits_rad)


@dataclass(frozen=True, slots=True)
class TransformationConfig:
    """Per-arm frame transforms relating arm frames to the world frame.

    Attributes:
        T_base_ref_world: Base reference frame → world frame.
        T_tool_ref_end: Tool frame → end-effector frame.
    """

    T_base_ref_world: SE3
    T_tool_ref_end: SE3


@dataclass(frozen=True, slots=True)
class ArmConfig:
    """Immutable configuration for one arm."""

    arm: Arm
    trans_config: TransformationConfig
    joints_limit: JointsLimit

    def __post_init__(self) -> None:
        if not isinstance(self.arm, Arm):
            raise ValueError(f"arm must be an Arm, got {self.arm!r}")
