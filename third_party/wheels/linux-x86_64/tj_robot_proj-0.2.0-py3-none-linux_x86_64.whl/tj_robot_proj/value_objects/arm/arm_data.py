"""Arm-related immutable data models.

Joint-space values are stored internally in **radians** (positions) and
**radians/second** (velocities) — the natural units for kinematics and
control.  Degree / degree-per-second constructors and accessors are provided
for convenience at the API boundary.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from tj_robot_proj.value_objects.arm.arm_enum import Arm
from tj_robot_proj.value_objects.lie_group import SE3


@dataclass(frozen=True, slots=True)
class JointPositions:
    """Joint-space positions, stored internally in radians.

    ``pos_rad`` is the canonical internal representation.  Construct from
    degrees with :meth:`from_deg` (or radians with :meth:`from_rad`) and read
    back degrees with :attr:`pos_deg`.

    The sequence protocol (``len`` / indexing / iteration) operates on the
    internal radians.
    """

    pos_rad: tuple[float, ...]
    num_joints: int

    def __post_init__(self) -> None:
        num_joints = int(self.num_joints)
        if num_joints < 1:
            raise ValueError(f"num_joints must be >= 1, got {self.num_joints}")
        values = tuple(float(v) for v in self.pos_rad)
        if len(values) != num_joints:
            raise ValueError(
                f"JointPositions requires exactly {num_joints} values, "
                f"got {len(values)}"
            )
        for i, v in enumerate(values):
            if not math.isfinite(v):
                raise ValueError(f"pos_rad[{i}] must be finite, got {v}")
        object.__setattr__(self, "num_joints", num_joints)
        object.__setattr__(self, "pos_rad", values)

    # -- constructors ---------------------------------------------------

    @classmethod
    def from_rad(cls, values_rad, num_joints: int) -> "JointPositions":
        """Construct from joint angles in radians."""
        return cls(
            pos_rad=tuple(float(v) for v in values_rad),
            num_joints=num_joints,
        )

    @classmethod
    def from_deg(cls, values_deg, num_joints: int) -> "JointPositions":
        """Construct from joint angles in degrees."""
        return cls(
            pos_rad=tuple(math.radians(float(v)) for v in values_deg),
            num_joints=num_joints,
        )

    # -- accessors ------------------------------------------------------

    @property
    def pos_deg(self) -> tuple[float, ...]:
        """Joint angles in degrees."""
        return tuple(math.degrees(v) for v in self.pos_rad)

    # -- sequence protocol (radians) ------------------------------------

    def __len__(self) -> int:
        return len(self.pos_rad)

    def __getitem__(self, index: int) -> float:
        return self.pos_rad[index]

    def __iter__(self):
        return iter(self.pos_rad)


@dataclass(frozen=True, slots=True)
class JointVelocity:
    """Joint-space velocities, stored internally in rad/s.

    ``vel_rad_s`` is the canonical internal representation.  Construct from
    degrees/second with :meth:`from_deg_s` (or rad/s with
    :meth:`from_rad_s`) and read back degrees/second with :attr:`vel_deg_s`.
    """

    vel_rad_s: tuple[float, ...]
    num_joints: int

    def __post_init__(self) -> None:
        num_joints = int(self.num_joints)
        if num_joints < 1:
            raise ValueError(f"num_joints must be >= 1, got {self.num_joints}")
        values = tuple(float(v) for v in self.vel_rad_s)
        if len(values) != num_joints:
            raise ValueError(
                f"JointVelocity requires exactly {num_joints} values, "
                f"got {len(values)}"
            )
        for i, v in enumerate(values):
            if not math.isfinite(v):
                raise ValueError(f"vel_rad_s[{i}] must be finite, got {v}")
        object.__setattr__(self, "num_joints", num_joints)
        object.__setattr__(self, "vel_rad_s", values)

    # -- constructors ---------------------------------------------------

    @classmethod
    def from_rad_s(cls, values_rad_s, num_joints: int) -> "JointVelocity":
        """Construct from joint velocities in rad/s."""
        return cls(
            vel_rad_s=tuple(float(v) for v in values_rad_s),
            num_joints=num_joints,
        )

    @classmethod
    def from_deg_s(cls, values_deg_s, num_joints: int) -> "JointVelocity":
        """Construct from joint velocities in degrees/second."""
        return cls(
            vel_rad_s=tuple(math.radians(float(v)) for v in values_deg_s),
            num_joints=num_joints,
        )

    # -- accessors ------------------------------------------------------

    @property
    def vel_deg_s(self) -> tuple[float, ...]:
        """Joint velocities in degrees/second."""
        return tuple(math.degrees(v) for v in self.vel_rad_s)

    # -- sequence protocol (rad/s) --------------------------------------

    def __len__(self) -> int:
        return len(self.vel_rad_s)

    def __getitem__(self, index: int) -> float:
        return self.vel_rad_s[index]

    def __iter__(self):
        return iter(self.vel_rad_s)


@dataclass(frozen=True, slots=True)
class ArmData:
    """Complete state snapshot of a single arm.

    Holds joint positions and velocities plus the SE(3) transforms for the
    end-effector and tool frames (each relative to the world frame), together
    with the end-effector button state.
    """

    arm: Arm
    joints_pos: JointPositions
    joints_vel: JointVelocity
    T_end_ref_world: SE3
    T_tool_ref_world: SE3
    num_joints: int
    button_pressed: bool = False

    def __post_init__(self) -> None:
        num_joints = int(self.num_joints)
        if num_joints < 1:
            raise ValueError(f"num_joints must be >= 1, got {self.num_joints}")
        object.__setattr__(self, "num_joints", num_joints)
        if self.joints_pos.num_joints != num_joints:
            raise ValueError(
                "joints_pos.num_joints "
                f"({self.joints_pos.num_joints}) != num_joints ({num_joints})"
            )
        if self.joints_vel.num_joints != num_joints:
            raise ValueError(
                "joints_vel.num_joints "
                f"({self.joints_vel.num_joints}) != num_joints ({num_joints})"
            )
