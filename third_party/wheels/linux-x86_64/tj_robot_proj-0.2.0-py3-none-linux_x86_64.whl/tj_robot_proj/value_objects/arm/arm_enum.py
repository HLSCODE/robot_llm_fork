from enum import Enum

class Arm(str, Enum):
    """Dual-arm identifiers used throughout the SDK."""

    LEFT = "A"
    RIGHT = "B"
