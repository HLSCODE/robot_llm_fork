# Lie Group Value Objects

Immutable, typed representations of the Lie groups used in robotics, built as
frozen dataclasses with slots. Group operations always return **new**
instances — they never mutate the receiver.

- `SO3` — the 3D rotation group
- `SE3` — the 3D rigid-body transformation group

```python
from tj_robot_proj.value_objects.lie_group import SO3, SE3
```

---

## SO(3)

`SO3` is a proper rotation: an orthonormal 3×3 matrix with determinant +1. It
is stored canonically as a **read-only** rotation matrix. Alternate
representations (rotation vector, axis-angle, quaternion, Euler angles) are
provided as constructors and accessors.

### Conventions

- Right-handed coordinate system.
- Angles are in **radians**.
- Euler angles are **extrinsic** (rotations about the fixed world axes):
  - `from_xyz_euler(rx, ry, rz)` → `R = Rz(rz) · Ry(ry) · Rx(rx)` (roll-pitch-yaw)
  - `from_zyx_euler(rx, ry, rz)` → `R = Rx(rx) · Ry(ry) · Rz(rz)`
- Quaternions are `(w, x, y, z)`, normalised on construction.
- `exp(ω)` / `log()` use the **rotation vector** `ω = axis · angle`; `log()`
  returns the principal angle in `[0, π]`.

### Construction

```python
import numpy as np
from tj_robot_proj.value_objects.lie_group import SO3

# Identity
R_id = SO3.identity()

# From a rotation vector (axis × angle), the exponential map so(3) → SO(3)
R = SO3.exp([0.1, -0.2, 0.3])              # equivalent to:
R = SO3.from_rotation_vector([0.1, -0.2, 0.3])

# From an axis and an angle (axis is normalised for you)
R = SO3.from_axis_angle([0, 0, 1], np.pi / 2)

# From a quaternion (normalised for you)
R = SO3.from_quaternion(0.7071, 0.0, 0.0, 0.7071)

# From extrinsic Euler angles
R = SO3.from_xyz_euler(0.1, 0.2, 0.3)      # roll-pitch-yaw
R = SO3.from_zyx_euler(0.1, 0.2, 0.3)

# From a 3×3 matrix (validated), optionally snapped onto SO(3) via SVD
R = SO3.from_matrix(some_3x3, normalize=True)
```

### Group operations

```python
R1 = SO3.from_xyz_euler(0.1, 0.2, 0.3)
R2 = SO3.from_zyx_euler(-0.1, 0.4, 0.2)

# Composition (group multiplication) — `compose` or `@`
R12 = R1.compose(R2)
R12 = R1 @ R2                      # same thing

# Inverse (matrix transpose)
R1_inv = R1.inverse()
R1 @ R1.inverse()                  # == SO3.identity()

# Rotate vectors — `rotate` or `@`
v = np.array([1.0, 0.0, 0.0])
v_rot = R1.rotate(v)
v_rot = R1 @ v                     # same thing

# Rotate a batch of column vectors (3×N)
V = np.eye(3)                      # three basis vectors
V_rot = R1 @ V

# Adjoint (for SO(3), Ad_R == R itself)
Ad = R1.adjoint()

# Logarithm map SO(3) → so(3): the rotation vector
omega = R1.log()
```

### Alternate representations (accessors)

```python
R = SO3.from_quaternion(0.7071, 0.0, 0.0, 0.7071)

R.matrix            # the canonical 3×3 matrix (read-only)
R.rotation_vector   # np.ndarray(3), axis × angle
R.axis_angle        # (unit_axis: np.ndarray(3), angle_rad: float)
R.quaternion        # (w, x, y, z)
R.xyz_euler         # (rx, ry, rz) — extrinsic XYZ
R.zyx_euler         # (rx, ry, rz) — extrinsic ZYX
```

Round trips work in both directions, for example:

```python
R == SO3.exp(R.log())                    # True
R == SO3.from_quaternion(*R.quaternion)  # True
R == SO3.from_xyz_euler(*R.xyz_euler)    # True (away from gimbal lock)
```

### Value semantics

`SO3` is immutable and hashable, so instances can be used as dict keys or set
members. Equality and hashing are based on the matrix quantised to 9 decimal
places.

```python
a = SO3.exp([0.1, 0.2, 0.3])
b = SO3.exp([0.1, 0.2, 0.3])

assert a == b
assert hash(a) == hash(b)

poses = {SO3.identity(): "home"}
```

Immutability is enforced both ways:

```python
R.matrix[0, 0] = 1.0   # ValueError: read-only array
R.matrix = np.eye(3)   # FrozenInstanceError: frozen dataclass
```

### Validation

The constructor rejects anything that is not a proper rotation:

```python
SO3(np.eye(3) * 2.0)   # ValueError: not orthonormal
SO3(np.diag([1, 1, -1]))  # ValueError: determinant -1 (improper rotation)
```

Use `from_matrix(..., normalize=True)` to project a slightly-off matrix onto
SO(3) instead of raising.

### Worked example

Compose two rotations and use the result to rotate a point:

```python
import numpy as np
from tj_robot_proj.value_objects.lie_group import SO3

# Rotate 30° about Z, then 20° about Y
R = SO3.from_zyx_euler(0.0, np.deg2rad(20), np.deg2rad(30))

p = np.array([1.0, 0.0, 0.0])
p_rot = R @ p

# Recover the axis and angle of the combined rotation
axis, angle = R.axis_angle
print("axis:", axis, "angle (deg):", np.rad2deg(angle))
```

---

## SE(3)

`SE3` is a rigid-body transform: a rotation `R ∈ SO(3)` and a translation
`t ∈ ℝ³`, applied to points as `p' = R p + t`. It is stored canonically as an
`SO3` (rotation) plus a read-only 3-vector (translation); the 4×4 homogeneous
matrix is available via `.matrix`.

### Conventions

- The twist 6-vector ordering is `[ω; v]` — the first three entries are the
  rotation vector (axis × angle) and the last three are the linear part.
- `exp` / `log` use this twist; the rotation part follows the same `SO3`
  conventions (radians, right-handed).
- `transform` applies the full transform (rotation + translation); use
  `transform_direction` to rotate a vector without translating it.

### Construction

```python
import numpy as np
from tj_robot_proj.value_objects.lie_group import SE3, SO3

# Identity
T = SE3.identity()

# From a rotation and a translation
T = SE3(SO3.from_xyz_euler(0.1, 0.2, 0.3), [1.0, 2.0, 3.0])
T = SE3(np.eye(3), [1.0, 2.0, 3.0])       # raw rotation matrix is coerced

# From a 4×4 homogeneous matrix (bottom row [0,0,0,1] validated)
T = SE3.from_matrix(np.eye(4))

# From a twist — the exponential map se(3) → SE(3)
T = SE3.exp([0.1, -0.2, 0.3, 0.5, 0.6, -0.7])       # [ω; v]
T = SE3.from_twist([0.1, -0.2, 0.3, 0.5, 0.6, -0.7])  # alias
```

### Group operations

```python
T1 = SE3.exp([0.1, 0.2, 0.3, 0.4, 0.5, 0.6])
T2 = SE3.exp([-0.2, 0.1, 0.05, 0.3, -0.4, 0.2])

# Composition — `compose` or `@`
T12 = T1.compose(T2)
T12 = T1 @ T2                       # same thing

# Inverse
T1_inv = T1.inverse()
T1 @ T1.inverse()                   # == SE3.identity()

# Logarithm map SE(3) → se(3): the twist [ω; v]
xi = T1.log()
xi = T1.twist                       # same as log()

# 6×6 adjoint matrix
Ad = T1.adjoint()
```

### Transforming points and directions

```python
p = np.array([1.0, 2.0, 3.0])
p_tf = T1.transform(p)              # R p + t
p_tf = T1 @ p                       # same (a 3-vector is treated as a point)

# Homogeneous coordinates (4-vector) — full matrix product
ph = np.array([1.0, 2.0, 3.0, 1.0])
ph_tf = T1 @ ph

# Batch of column points (3×N)
P = np.column_stack([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]])
P_tf = T1.transform(P)

# Directions: rotate only, no translation
d = np.array([1.0, 0.0, 0.0])
d_tf = T1.transform_direction(d)
```

### Accessors

```python
T = SE3(SO3.from_quaternion(0.7071, 0.0, 0.0, 0.7071), [1.0, 2.0, 3.0])

T.rotation        # SO3
T.translation     # np.ndarray(3) — read-only
T.matrix          # 4×4 homogeneous matrix
T.twist           # np.ndarray(6) — [ω; v]
```

Round trips work in both directions:

```python
T == SE3.exp(T.log())              # True
T == SE3.from_matrix(T.matrix)     # True
```

### Value semantics & validation

Same as `SO3`: immutable, hashable, safe as dict keys / set members; equality
and hashing quantise the translation to 9 decimal places.

```python
a = SE3.exp([0.1, 0.2, 0.3, 0.4, 0.5, 0.6])
b = SE3.exp([0.1, 0.2, 0.3, 0.4, 0.5, 0.6])
assert a == b and hash(a) == hash(b)

a.translation[0] = 1.0          # ValueError: read-only array
a.translation = np.zeros(3)     # FrozenInstanceError
```

`from_matrix` validates the bottom row and the rotation block:

```python
SE3.from_matrix(bad_matrix)     # ValueError if bottom row ≠ [0,0,0,1]
```

### Worked example

Compose a rotation and a translation, then transform a point:

```python
import numpy as np
from tj_robot_proj.value_objects.lie_group import SE3, SO3

T = SE3(SO3.from_zyx_euler(0.0, 0.0, np.deg2rad(30)), [0.5, 0.0, 0.0])

p = np.array([1.0, 0.0, 0.0])
p_tf = T.transform(p)

# Recover the twist
xi = T.log()
print("twist:", xi)
```
