"""SE(3) — the 3D rigid-body transformation group, as an immutable value object.

``SE3`` represents a rigid-body transform: a rotation ``R ∈ SO(3)`` and a
translation ``t ∈ ℝ³``, applied as ``p' = R p + t``.  It is a frozen dataclass
with slots; group operations return new instances and never mutate ``self``.

Internally it composes ``SO3`` for the rotation with a read-only 3-vector for
the translation.  The 6-vector twist convention for ``exp``/``log`` is
``[ω; v]`` — the first three entries are the rotation vector and the last
three are the linear part.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from tj_robot_proj.value_objects.lie_group.SO3 import SO3

# ---------------------------------------------------------------------------
# Tolerances
# ---------------------------------------------------------------------------

_EPS = 1e-12       # near-zero threshold (exp/log singularities)
_ORTHO_TOL = 1e-8  # bottom-row / rotation validation tolerance


def _skew(v: np.ndarray) -> np.ndarray:
    """Map a 3-vector to its skew-symmetric so(3) matrix."""
    x, y, z = v
    return np.array([[0.0, -z, y], [z, 0.0, -x], [-y, x, 0.0]])


@dataclass(frozen=True, slots=True)
class SE3:
    """An element of SE(3): a rotation and a translation.

    ``rotation`` may be an ``SO3`` or a raw 3×3 rotation matrix (coerced and
    validated on construction).  ``translation`` is a 3-vector in the parent
    frame, stored read-only.
    """

    rotation: SO3
    translation: np.ndarray

    def __post_init__(self) -> None:
        if not isinstance(self.rotation, SO3):
            object.__setattr__(self, "rotation", SO3(self.rotation))
        t = np.array(self.translation, dtype=float)
        if t.shape != (3,):
            raise ValueError(f"translation must be a 3-vector, got {t.shape}")
        if not np.all(np.isfinite(t)):
            raise ValueError("translation must be finite")
        t.setflags(write=False)
        object.__setattr__(self, "translation", t)

    # ------------------------------------------------------------------
    # Value semantics (see SO3 for why explicit __eq__/__hash__ is needed)
    # ------------------------------------------------------------------

    def _translation_key(self) -> tuple[float, ...]:
        """Quantised translation values used for equality/hashing."""
        return tuple(round(float(v), 9) for v in self.translation)

    def __eq__(self, other: object) -> bool:
        if other.__class__ is not self.__class__:
            return NotImplemented
        return self.rotation == other.rotation and (
            self._translation_key() == other._translation_key()
        )

    def __hash__(self) -> int:
        return hash((self.rotation, self._translation_key()))

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def identity(cls) -> "SE3":
        """The identity transform (no rotation, no translation)."""
        return cls(SO3.identity(), np.zeros(3))

    @classmethod
    def from_matrix(cls, matrix, *, normalize: bool = False) -> "SE3":
        """Construct from a 4×4 homogeneous transformation matrix.

        With ``normalize=True`` the rotation block is snapped onto SO(3)
        (SVD projection) instead of raising on slight violations.
        """
        T = np.array(matrix, dtype=float)
        if T.shape != (4, 4):
            raise ValueError(f"matrix must be 4×4, got {T.shape}")
        if not np.allclose(T[3, :], [0.0, 0.0, 0.0, 1.0], atol=_ORTHO_TOL):
            raise ValueError("bottom row must be [0, 0, 0, 1]")
        R = SO3.from_matrix(T[:3, :3], normalize=normalize)
        return cls(R, T[:3, 3])

    @classmethod
    def exp(cls, xi) -> "SE3":
        """Exponential map se(3) → SE(3); ``xi`` is the 6-vector ``[ω; v]``.

        ``ω`` is the rotation vector (axis × angle) and ``v`` the linear part.
        """
        xi = np.asarray(xi, dtype=float)
        if xi.shape != (6,):
            raise ValueError(f"xi must be a 6-vector, got {xi.shape}")
        omega = xi[:3]
        v = xi[3:]
        theta = float(np.linalg.norm(omega))
        Omega = _skew(omega)
        R = SO3.exp(omega)
        if theta < _EPS:
            V = np.eye(3) + 0.5 * Omega + (1.0 / 6.0) * (Omega @ Omega)
        else:
            sin_t = math.sin(theta)
            cos_t = math.cos(theta)
            V = (
                np.eye(3)
                + ((1.0 - cos_t) / theta**2) * Omega
                + ((theta - sin_t) / theta**3) * (Omega @ Omega)
            )
        return cls(R, V @ v)

    from_twist = exp  # alias

    # ------------------------------------------------------------------
    # Group operations
    # ------------------------------------------------------------------

    def inverse(self) -> "SE3":
        """Group inverse: ``T⁻¹ = [Rᵀ, -Rᵀ t; 0, 1]``."""
        t_inv = -(self.rotation.matrix.T @ self.translation)
        return SE3(self.rotation.inverse(), t_inv)

    def compose(self, other: "SE3") -> "SE3":
        """Group multiplication ``self ∘ other``."""
        return SE3(
            self.rotation @ other.rotation,
            self.rotation.matrix @ other.translation + self.translation,
        )

    def transform(self, p) -> np.ndarray:
        """Transform a 3-vector point (or 3×N column points): ``R p + t``."""
        p = np.asarray(p, dtype=float)
        if p.ndim == 1:
            if p.shape[0] != 3:
                raise ValueError(f"point must have 3 elements, got {p.shape}")
            return self.rotation.matrix @ p + self.translation
        if p.ndim == 2 and p.shape[0] == 3:
            return self.rotation.matrix @ p + self.translation[:, None]
        raise ValueError(f"expected a 3-vector or 3×N matrix, got {p.shape}")

    def transform_direction(self, d) -> np.ndarray:
        """Transform a 3-vector direction (no translation): ``R d``."""
        d = np.asarray(d, dtype=float)
        if d.ndim == 1:
            if d.shape[0] != 3:
                raise ValueError(f"direction must have 3 elements, got {d.shape}")
            return self.rotation.matrix @ d
        if d.ndim == 2 and d.shape[0] == 3:
            return self.rotation.matrix @ d
        raise ValueError(f"expected a 3-vector or 3×N matrix, got {d.shape}")

    def __matmul__(self, other):
        """``self @ other`` — compose with another ``SE3``, transform a point,
        or multiply a homogeneous 4-vector."""
        if isinstance(other, SE3):
            return self.compose(other)
        arr = np.asarray(other, dtype=float)
        if arr.ndim == 1 and arr.shape[0] == 4:
            return self.matrix @ arr
        if arr.ndim == 2 and arr.shape[0] == 4:
            return self.matrix @ arr
        return self.transform(arr)

    def adjoint(self) -> np.ndarray:
        """The 6×6 adjoint matrix (for the ``[ω; v]`` twist ordering)."""
        R = self.rotation.matrix
        Ad = np.zeros((6, 6))
        Ad[:3, :3] = R
        Ad[3:, 3:] = R
        Ad[3:, :3] = _skew(self.translation) @ R
        return Ad

    def log(self) -> np.ndarray:
        """Logarithmic map SE(3) → se(3): the 6-vector twist ``[ω; v]``."""
        omega = self.rotation.log()
        theta = float(np.linalg.norm(omega))
        if theta < _EPS:
            v = self.translation
        else:
            Omega = _skew(omega)
            sin_t = math.sin(theta)
            cos_t = math.cos(theta)
            V = (
                np.eye(3)
                + ((1.0 - cos_t) / theta**2) * Omega
                + ((theta - sin_t) / theta**3) * (Omega @ Omega)
            )
            v = np.linalg.solve(V, self.translation)
        return np.concatenate([omega, v])

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------

    @property
    def matrix(self) -> np.ndarray:
        """The 4×4 homogeneous transformation matrix."""
        T = np.eye(4)
        T[:3, :3] = self.rotation.matrix
        T[:3, 3] = self.translation
        return T

    @property
    def twist(self) -> np.ndarray:
        """The 6-vector twist ``[ω; v]``, i.e. the se(3) logarithm."""
        return self.log()
