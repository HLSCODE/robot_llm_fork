"""SO(3) — the 3D rotation group, as an immutable value object.

``SO3`` represents a proper rotation (an orthonormal 3×3 matrix with
determinant +1).  It is a frozen dataclass with slots: instances are
immutable, and every group operation returns a new instance rather than
mutating ``self``.

The canonical internal representation is the 3×3 rotation matrix, stored
read-only.  Alternate representations (rotation vector, axis-angle,
quaternion, Euler angles) are provided as constructors and accessors.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

# ---------------------------------------------------------------------------
# Tolerances
# ---------------------------------------------------------------------------

_EPS = 1e-12       # near-zero threshold (exp/log singularities)
_ORTHO_TOL = 1e-8  # orthonormality / determinant validation tolerance
_PI_TOL = 1e-7     # threshold for the θ = π branch of log()


# ---------------------------------------------------------------------------
# so(3) helpers
# ---------------------------------------------------------------------------


def _skew(v: np.ndarray) -> np.ndarray:
    """Map a 3-vector to its skew-symmetric so(3) matrix."""
    x, y, z = v
    return np.array([[0.0, -z, y], [z, 0.0, -x], [-y, x, 0.0]])


def _vee(K: np.ndarray) -> np.ndarray:
    """Inverse of :func:`_skew`: so(3) matrix → 3-vector."""
    return np.array([K[2, 1], K[0, 2], K[1, 0]])


# ---------------------------------------------------------------------------
# Elementary rotations (for the Euler-angle constructors)
# ---------------------------------------------------------------------------


def _rot_x(a: float) -> np.ndarray:
    c, s = math.cos(a), math.sin(a)
    return np.array([[1.0, 0.0, 0.0], [0.0, c, -s], [0.0, s, c]])


def _rot_y(a: float) -> np.ndarray:
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, 0.0, s], [0.0, 1.0, 0.0], [-s, 0.0, c]])


def _rot_z(a: float) -> np.ndarray:
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


def _matrix_to_xyz_euler(R: np.ndarray) -> tuple[float, float, float]:
    """Extrinsic XYZ (``R = Rz·Ry·Rx``) → ``(rx, ry, rz)``."""
    sy = math.hypot(R[0, 0], R[1, 0])
    if sy > 1e-6:
        rx = math.atan2(R[2, 1], R[2, 2])
        ry = math.atan2(-R[2, 0], sy)
        rz = math.atan2(R[1, 0], R[0, 0])
    else:  # gimbal lock
        rx = math.atan2(-R[1, 2], R[1, 1])
        ry = math.atan2(-R[2, 0], sy)
        rz = 0.0
    return (rx, ry, rz)


def _matrix_to_zyx_euler(R: np.ndarray) -> tuple[float, float, float]:
    """Extrinsic ZYX (``R = Rx·Ry·Rz``) → ``(rx, ry, rz)``."""
    sy = R[0, 2]
    if abs(sy) < 1 - 1e-6:
        rx = math.atan2(-R[1, 2], R[2, 2])
        ry = math.asin(sy)
        rz = math.atan2(-R[0, 1], R[0, 0])
    else:  # gimbal lock
        rx = 0.0
        ry = math.copysign(math.pi / 2, sy)
        rz = math.atan2(R[1, 0], R[1, 1])
    return (rx, ry, rz)


@dataclass(frozen=True, slots=True)
class SO3:
    """An element of SO(3), stored canonically as a 3×3 rotation matrix.

    The constructor validates that ``matrix`` is a proper rotation
    (orthonormal with determinant +1).  Prefer the alternate constructors
    (``exp``, ``from_axis_angle``, ``from_quaternion``, ``from_*_euler``),
    which are guaranteed to produce valid elements.
    """

    matrix: np.ndarray

    def __post_init__(self) -> None:
        R = np.array(self.matrix, dtype=float)
        if R.shape != (3, 3):
            raise ValueError(f"matrix must be 3×3, got {R.shape}")
        if not np.all(np.isfinite(R)):
            raise ValueError("matrix must be finite")
        if not np.allclose(R @ R.T, np.eye(3), atol=_ORTHO_TOL):
            raise ValueError("matrix must be orthonormal (RᵀR = I)")
        if abs(float(np.linalg.det(R)) - 1.0) > _ORTHO_TOL:
            raise ValueError("matrix must have determinant +1 (proper rotation)")
        R.setflags(write=False)
        object.__setattr__(self, "matrix", R)

    # ------------------------------------------------------------------
    # Value semantics — numpy-backed fields need explicit __eq__/__hash__
    # (the dataclass-generated versions break on element-wise comparison).
    # ------------------------------------------------------------------

    def _canonical(self) -> tuple[float, ...]:
        """Quantised matrix values used consistently for equality/hashing."""
        return tuple(round(float(v), 9) for v in self.matrix.ravel())

    def __eq__(self, other: object) -> bool:
        if other.__class__ is not self.__class__:
            return NotImplemented
        return self._canonical() == other._canonical()

    def __hash__(self) -> int:
        return hash(self._canonical())

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def identity(cls) -> "SO3":
        """The identity rotation."""
        return cls(np.eye(3))

    @classmethod
    def from_matrix(cls, matrix, *, normalize: bool = False) -> "SO3":
        """Construct from a 3×3 matrix, optionally snapping onto SO(3).

        With ``normalize=True`` the nearest proper rotation (SVD
        projection) is computed instead of raising on slight violations.
        """
        R = np.array(matrix, dtype=float)
        if R.shape != (3, 3):
            raise ValueError(f"matrix must be 3×3, got {R.shape}")
        if normalize:
            U, _, Vt = np.linalg.svd(R)
            R = U @ Vt
            if np.linalg.det(R) < 0.0:
                Vt[2, :] *= -1.0
                R = U @ Vt
        return cls(R)

    @classmethod
    def exp(cls, omega) -> "SO3":
        """Exponential map so(3) → SO(3) (Rodrigues' formula).

        ``omega`` is a 3-vector (rotation vector: axis × angle).
        """
        omega = np.asarray(omega, dtype=float)
        if omega.shape != (3,):
            raise ValueError(f"omega must be a 3-vector, got {omega.shape}")
        theta = float(np.linalg.norm(omega))
        if theta < _EPS:
            return cls.identity()
        k = omega / theta
        K = _skew(k)
        R = np.eye(3) + math.sin(theta) * K + (1.0 - math.cos(theta)) * (K @ K)
        return cls(R)

    from_rotation_vector = exp  # alias

    @classmethod
    def from_axis_angle(cls, axis, angle_rad: float) -> "SO3":
        """Construct from a unit axis and an angle (radians)."""
        axis = np.asarray(axis, dtype=float)
        if axis.shape != (3,):
            raise ValueError(f"axis must be a 3-vector, got {axis.shape}")
        n = float(np.linalg.norm(axis))
        if n < _EPS:
            raise ValueError("axis must be non-zero")
        return cls.exp(axis / n * angle_rad)

    @classmethod
    def from_quaternion(cls, w: float, x: float, y: float, z: float) -> "SO3":
        """Construct from a quaternion ``(w, x, y, z)`` (normalised)."""
        n = math.sqrt(w * w + x * x + y * y + z * z)
        if n < _EPS:
            raise ValueError("quaternion must be non-zero")
        w, x, y, z = w / n, x / n, y / n, z / n
        R = np.array(
            [
                [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
                [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
                [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
            ]
        )
        return cls(R)

    @classmethod
    def from_xyz_euler(cls, rx_rad: float, ry_rad: float, rz_rad: float) -> "SO3":
        """Construct from extrinsic XYZ Euler angles (roll-pitch-yaw, radians).

        ``R = Rz(rz)·Ry(ry)·Rx(rx)``.
        """
        return cls(_rot_z(rz_rad) @ _rot_y(ry_rad) @ _rot_x(rx_rad))

    @classmethod
    def from_zyx_euler(cls, rx_rad: float, ry_rad: float, rz_rad: float) -> "SO3":
        """Construct from extrinsic ZYX Euler angles (radians).

        ``R = Rx(rx)·Ry(ry)·Rz(rz)``.
        """
        return cls(_rot_x(rx_rad) @ _rot_y(ry_rad) @ _rot_z(rz_rad))

    # ------------------------------------------------------------------
    # Group operations
    # ------------------------------------------------------------------

    def inverse(self) -> "SO3":
        """Group inverse (matrix transpose)."""
        return SO3(self.matrix.T)

    def compose(self, other: "SO3") -> "SO3":
        """Group multiplication ``self ∘ other`` (matrix product)."""
        return SO3(self.matrix @ other.matrix)

    def rotate(self, v) -> np.ndarray:
        """Rotate a 3-vector (or a 3×N matrix of column vectors)."""
        v = np.asarray(v, dtype=float)
        if v.ndim == 1:
            if v.shape[0] != 3:
                raise ValueError(f"vector must have 3 elements, got {v.shape}")
            return self.matrix @ v
        if v.ndim == 2 and v.shape[0] == 3:
            return self.matrix @ v
        raise ValueError(f"expected a 3-vector or 3×N matrix, got {v.shape}")

    def __matmul__(self, other):
        """``self @ other`` — compose with another ``SO3``, or rotate a vector."""
        if isinstance(other, SO3):
            return self.compose(other)
        return self.rotate(other)

    def adjoint(self) -> np.ndarray:
        """Adjoint representation of this element (for SO(3), ``Ad_R = R``)."""
        return self.matrix

    def log(self) -> np.ndarray:
        """Logarithmic map SO(3) → so(3): the rotation vector (axis × angle)."""
        R = self.matrix
        cos_t = float(np.clip((np.trace(R) - 1.0) / 2.0, -1.0, 1.0))
        half_vee = 0.5 * _vee(R - R.T)
        sin_t = float(np.linalg.norm(half_vee))
        theta = math.atan2(sin_t, cos_t)  # principal angle in [0, π]

        if theta < _EPS:
            return np.zeros(3)

        if math.pi - theta < _PI_TOL:
            # θ ≈ π: R is symmetric; extract the axis from R + I = 2·k·kᵀ.
            A = R + np.eye(3)
            i = int(np.argmax(np.diag(A)))
            k = A[:, i].copy()
            n = float(np.linalg.norm(k))
            if n < _EPS:
                raise ArithmeticError("failed to extract rotation axis at θ = π")
            k /= n
            if k[i] < 0.0:
                k = -k
            return math.pi * k

        return (theta / sin_t) * half_vee

    # ------------------------------------------------------------------
    # Accessors (alternate representations)
    # ------------------------------------------------------------------

    @property
    def rotation_vector(self) -> np.ndarray:
        """Rotation vector (axis × angle), i.e. the so(3) logarithm."""
        return self.log()

    @property
    def axis_angle(self) -> tuple[np.ndarray, float]:
        """Axis-angle ``(unit_axis, angle_rad)``."""
        omega = self.log()
        theta = float(np.linalg.norm(omega))
        if theta < _EPS:
            return (np.array([1.0, 0.0, 0.0]), 0.0)
        return (omega / theta, theta)

    @property
    def quaternion(self) -> tuple[float, float, float, float]:
        """Unit quaternion ``(w, x, y, z)`` (Shepperd's method)."""
        R = self.matrix
        trace = R[0, 0] + R[1, 1] + R[2, 2]
        if trace > 0.0:
            s = 2.0 * math.sqrt(trace + 1.0)
            w = 0.25 * s
            x = (R[2, 1] - R[1, 2]) / s
            y = (R[0, 2] - R[2, 0]) / s
            z = (R[1, 0] - R[0, 1]) / s
        elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
            s = 2.0 * math.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2])
            w = (R[2, 1] - R[1, 2]) / s
            x = 0.25 * s
            y = (R[0, 1] + R[1, 0]) / s
            z = (R[0, 2] + R[2, 0]) / s
        elif R[1, 1] > R[2, 2]:
            s = 2.0 * math.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2])
            w = (R[0, 2] - R[2, 0]) / s
            x = (R[0, 1] + R[1, 0]) / s
            y = 0.25 * s
            z = (R[1, 2] + R[2, 1]) / s
        else:
            s = 2.0 * math.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1])
            w = (R[1, 0] - R[0, 1]) / s
            x = (R[0, 2] + R[2, 0]) / s
            y = (R[1, 2] + R[2, 1]) / s
            z = 0.25 * s
        return (w, x, y, z)

    @property
    def xyz_euler(self) -> tuple[float, float, float]:
        """Extrinsic XYZ Euler angles ``(rx_rad, ry_rad, rz_rad)``."""
        return _matrix_to_xyz_euler(self.matrix)

    @property
    def zyx_euler(self) -> tuple[float, float, float]:
        """Extrinsic ZYX Euler angles ``(rx_rad, ry_rad, rz_rad)``."""
        return _matrix_to_zyx_euler(self.matrix)
