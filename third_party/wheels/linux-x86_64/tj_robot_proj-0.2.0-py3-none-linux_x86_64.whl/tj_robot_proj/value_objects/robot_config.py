"""Immutable configuration for a dual-arm robot session."""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass

from tj_robot_proj.value_objects.arm import Arm, ArmConfig


@dataclass(frozen=True, slots=True)
class RobotConfig:
    """Configuration for a ``RobotClient`` session.

    Each arm's transforms and joint limits are grouped in an
    :class:`~tj_robot_proj.value_objects.arm.ArmConfig`.
    """

    controller_ip: str
    left_arm_config: ArmConfig
    right_arm_config: ArmConfig
    subscription_interval_seconds: float = 0.01

    def __post_init__(self) -> None:
        try:
            ipaddress.IPv4Address(self.controller_ip)
        except (ipaddress.AddressValueError, ValueError) as exc:
            raise ValueError(
                f"controller_ip must be a valid IPv4 address, got {self.controller_ip!r}"
            ) from exc
        if self.left_arm_config.arm is not Arm.LEFT:
            raise ValueError("left_arm_config.arm must be Arm.LEFT")
        if self.right_arm_config.arm is not Arm.RIGHT:
            raise ValueError("right_arm_config.arm must be Arm.RIGHT")
        if self.subscription_interval_seconds <= 0:
            raise ValueError(
                f"subscription_interval_seconds must be > 0, "
                f"got {self.subscription_interval_seconds}"
            )
