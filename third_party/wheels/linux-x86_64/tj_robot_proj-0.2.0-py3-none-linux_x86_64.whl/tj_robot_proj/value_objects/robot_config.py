"""Immutable robot-session and data-collection configuration values."""

from __future__ import annotations

import ipaddress
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import ClassVar

from tj_robot_proj.value_objects.arm import Arm, ArmConfig


def _default_traj_data_dir() -> str:
    """Return the platform-specific default trajectory data directory."""
    return r"C:\tj_trajectory_data" if os.name == "nt" else "/tmp/tj_trajectory_data"


def _prepare_traj_data_dir(value: str) -> str:
    """Validate, create, and normalize a trajectory data directory."""
    if not isinstance(value, str) or not value.strip():
        raise ValueError(
            f"traj_data_dir must be a non-empty directory path, got {value!r}"
        )

    try:
        directory = Path(value).expanduser()
        directory.mkdir(parents=True, exist_ok=True)
        directory = directory.resolve()
    except (OSError, ValueError) as exc:
        raise ValueError(
            f"Unable to create or access traj_data_dir {value!r}: {exc}"
        ) from exc

    if not directory.is_dir():
        raise ValueError(f"traj_data_dir is not a directory: {directory}")
    if not os.access(directory, os.W_OK):
        raise ValueError(f"traj_data_dir is not writable: {directory}")
    return str(directory)


@dataclass(frozen=True, slots=True)
class ArmCollectionDataOption:
    """Data types to collect for one arm.

    ``data_types`` 保存采集数据类型 ID。元组中的每项对应单帧中的一个值，
    因此 :attr:`col` 在构造时自动计算为所选 ID 数量。:attr:`target_ids`
    会根据 :attr:`arm` 自动生成原生 SDK 所需的目标 ID。

    数据类型 ID：

    - ``0``–``6``：关节位置
    - ``10``–``16``：关节速度
    - ``20``–``26``：外编位置
    - ``30``–``36``：关节指令位置
    - ``40``–``46``：关节电流（千分比）
    - ``50``–``56``：关节传感器扭矩（Nm）
    - ``60``–``66``：关节摩擦力估计值
    - ``70``–``76``：关节摩擦力速度估计值
    - ``80``–``85``：关节外力估计值
    - ``90``–``95``：末端点外力估计值
    """

    arm: Arm
    data_types: tuple[int, ...]
    col: int = field(init=False)

    _VALID_DATA_TYPES: ClassVar[frozenset[int]] = frozenset(
        (
            *range(0, 7),
            *range(10, 17),
            *range(20, 27),
            *range(30, 37),
            *range(40, 47),
            *range(50, 57),
            *range(60, 67),
            *range(70, 77),
            *range(80, 86),
            *range(90, 96),
        )
    )

    def __post_init__(self) -> None:
        if not isinstance(self.arm, Arm):
            raise ValueError(f"arm must be an Arm, got {self.arm!r}")
        values = tuple(int(value) for value in self.data_types)
        if not values:
            raise ValueError("data_types must not be empty")
        invalid = tuple(
            value for value in values if value not in self._VALID_DATA_TYPES
        )
        if invalid:
            raise ValueError(f"Unsupported collection data type IDs: {invalid}")
        if len(set(values)) != len(values):
            raise ValueError("data_types must not contain duplicates")

        object.__setattr__(self, "data_types", values)
        object.__setattr__(self, "col", len(values))

    @property
    def target_ids(self) -> tuple[int, ...]:
        """Native SDK target IDs for this arm."""
        offset = 0 if self.arm is Arm.LEFT else 100
        return tuple(offset + value for value in self.data_types)


@dataclass(frozen=True, slots=True)
class RobotConfig:
    """Configuration for a ``RobotClient`` session.

    Each arm's transforms and joint limits are grouped in an
    :class:`~tj_robot_proj.value_objects.arm.ArmConfig`.
    """

    controller_ip: str
    left_arm_config: ArmConfig
    right_arm_config: ArmConfig
    left_arm_collection_data_option: ArmCollectionDataOption
    right_arm_collection_data_option: ArmCollectionDataOption
    subscription_interval_seconds: float = 0.01
    trajectory_frequency: int = 500
    traj_data_dir: str = field(default_factory=_default_traj_data_dir)

    def __post_init__(self) -> None:
        try:
            ipaddress.IPv4Address(self.controller_ip)
        except (ipaddress.AddressValueError, ValueError) as exc:
            raise ValueError(
                f"controller_ip must be a valid IPv4 address, got {self.controller_ip!r}"
            ) from exc
        if self.left_arm_config.arm is not Arm.LEFT:
            raise ValueError("left_arm_config.arm must be Arm.LEFT")
        if self.right_arm_config.arm is not Arm.RIGHT:
            raise ValueError("right_arm_config.arm must be Arm.RIGHT")
        if not isinstance(
            self.left_arm_collection_data_option,
            ArmCollectionDataOption,
        ):
            raise ValueError(
                "left_arm_collection_data_option must be an "
                "ArmCollectionDataOption"
            )
        if self.left_arm_collection_data_option.arm is not Arm.LEFT:
            raise ValueError("left_arm_collection_data_option.arm must be Arm.LEFT")
        if not isinstance(
            self.right_arm_collection_data_option,
            ArmCollectionDataOption,
        ):
            raise ValueError(
                "right_arm_collection_data_option must be an "
                "ArmCollectionDataOption"
            )
        if self.right_arm_collection_data_option.arm is not Arm.RIGHT:
            raise ValueError(
                "right_arm_collection_data_option.arm must be Arm.RIGHT"
            )
        collection_columns = (
            self.left_arm_collection_data_option.col
            + self.right_arm_collection_data_option.col
        )
        if collection_columns > 35:
            raise ValueError(
                "Combined collection data columns must not exceed 35, "
                f"got {collection_columns}"
            )
        if self.subscription_interval_seconds <= 0:
            raise ValueError(
                f"subscription_interval_seconds must be > 0, "
                f"got {self.subscription_interval_seconds}"
            )
        if (
            isinstance(self.trajectory_frequency, bool)
            or not isinstance(self.trajectory_frequency, int)
            or not 1 <= self.trajectory_frequency <= 1000
        ):
            raise ValueError(
                "trajectory_frequency must be an integer in [1, 1000] Hz, "
                f"got {self.trajectory_frequency!r}"
            )
        object.__setattr__(
            self,
            "traj_data_dir",
            _prepare_traj_data_dir(self.traj_data_dir),
        )
