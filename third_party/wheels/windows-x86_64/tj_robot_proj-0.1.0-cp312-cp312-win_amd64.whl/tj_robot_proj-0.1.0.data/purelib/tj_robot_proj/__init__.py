from tj_robot_proj.app.tj_arms_app.tj_arms_app import TJArmsApp
