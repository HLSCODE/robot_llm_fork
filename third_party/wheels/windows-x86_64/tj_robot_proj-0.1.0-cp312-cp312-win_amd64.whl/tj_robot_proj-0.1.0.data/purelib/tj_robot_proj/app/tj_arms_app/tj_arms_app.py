import os
import shutil
# from tj_robot_proj.app.tj_arms_app.SDK_PYTHON.fx_kine import Marvin_Kine
# from tj_robot_proj.app.tj_arms_app.SDK_PYTHON.fx_robot import Marvin_Robot, DCSS
from .SDK_PYTHON.fx_kine import Marvin_Kine
from .SDK_PYTHON.fx_robot import Marvin_Robot, DCSS
import time
import logging
import threading
from datetime import datetime
import numpy as np
from collections import deque
import matplotlib
matplotlib.use('TkAgg')  # matplotlib 用 Tk 后端，避免被 QT_QPA_PLATFORM=offscreen 影响
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.gridspec import GridSpec
import queue
os.environ['QT_QPA_PLATFORM'] = 'offscreen'  # 禁用 OpenCV 的 Qt GUI，画面用 matplotlib 显示
import cv2

from dataclasses import dataclass,field
from tj_robot_proj.data.txt2fmv_tranformer import convert_file

# 项目根目录（所有路径均从此变量派生）
_PROJ_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class TJArmsApp:
    # ==================================================================
    #  内部数据类
    # ==================================================================
    # 多线程维护类，需要加锁
    @dataclass
    class ArmData:
        joint_pos_rad:list = field(default_factory=lambda :[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        joint_pos_degree:list = field(default_factory=lambda :[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        joint_vel_rad_per_s:list = field(default_factory=lambda :[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        joint_vel_degree_per_s:list = field(default_factory=lambda :[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        est_joint_force:list = field(default_factory=lambda :[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        botton_pressed: bool = False
        world_T_end: np.ndarray = field(default_factory=lambda: np.eye(4))  # 末端坐标系关于世界坐标系的变换矩阵 (4x4, 单位 m)
        thread_lock: threading.Lock = field(default_factory=threading.Lock)

    # constant
    @dataclass(frozen=True)
    class ArmT: #位移单位m
        armA_B_W: tuple = (
            (1.0, 0.0, 0.0, 0.0),
            (0.0, 0.0, 1.0, 0.1),
            (0.0, -1.0, 0.0, 0.6),
            (0.0, 0.0, 0.0, 1.0),
        )
        armA_tool_l7: tuple = (
            (0.0, 0.0, -1.0, 0.0),
            (0.0, 1.0, 0.0, 0.0),
            (1.0, 0.0, 0.0, 0.0),
            (0.0, 0.0, 0.0, 1.0),
        )
        armB_B_W: tuple = (
            (1.0, 0.0, 0.0, 0.0),
            (0.0, 0.0, -1.0, -0.1),
            (0.0, 1.0, 0.0, 0.6),
            (0.0, 0.0, 0.0, 1.0),
        )
        armB_tool_l7: tuple = (
            (0.0, 0.0, -1.0, 0.0),
            (0.0, 1.0, 0.0, 0.0),
            (1.0, 0.0, 0.0, 0.0),
            (0.0, 0.0, 0.0, 1.0),
        )

    # ==================================================================
    #  Magic/Dunder Method
    # ==================================================================

    def __init__(self):
        self._released = False  # 防止 __exit__ / __del__ 双重清理

        self._robot_init()

        self._thread_logger = logging.getLogger('thread_logger')
        self._thread_logger.setLevel(logging.INFO)

        self.left_arm_data = self.ArmData()
        self.right_arm_data = self.ArmData()

        self._queue1 = queue.Queue()
        self._queue2 = queue.Queue()

        # ==================================================================
        #  Threads and Lock (python全局锁GIL)
        # ==================================================================

        self._robot_ctrl_lock = threading.Lock()
        # 写数据线程：500Hz 自动订阅
        self._subscribe_thread = None
        self._subscribe_stop_event = threading.Event()
        self._start_auto_subscribe()
        # 用户线程
        self._user_thread = None
        self._user_thread_stop_event = threading.Event()
        # 按钮边沿检测（两臂各一个线程）
        self._button_monitor_threads = {'A': None, 'B': None}
        self._button_monitor_stop_events = {'A': threading.Event(), 'B': threading.Event()}
        for arm in ('A', 'B'):
            self._start_button_monitor(arm)
        # consumer1 线程：消费 queue1 中的数据
        self._consumer1_thread = None
        self._consumer1_stop_event = threading.Event()
        self._start_consumer1()
        # consumer2 线程：消费 queue2 中的数据
        self._consumer2_thread = None
        self._consumer2_stop_event = threading.Event()
        self._start_consumer2()
        # 相机：独立线程读帧 + 共享给 animation 显示
        self._camera_frame = None
        self._camera_lock = threading.Lock()
        self._camera_thread = None
        self._camera_stop_event = threading.Event()
        self._camera_cap = None
        self._camera_available = False
        self._start_camera()

        self._plot_init()

        time.sleep(0.5) # necessary

    def __del__(self):
        if self._released:
            return
        self._released = True
        # 先通知用户线程退出
        self._user_thread_stop_event.set()
        if self._user_thread is not None:
            self._user_thread.join(timeout=2.0)
        # 停止按钮监控线程
        for arm in ('A', 'B'):
            self._stop_button_monitor(arm)
        self._stop_consumer1()
        self._stop_consumer2()
        self._stop_camera()
        self._stop_auto_subscribe()
        self._stop_plot_data()
        self._release()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.__del__()
        print("=====del  TJArmsApp obj in __exit__=====")
    # ==================================================================
    #  Public 方法
    # ==================================================================

    def get_arm_data(self, arm: str) -> dict:
        """返回指定臂的数据拷贝（线程安全，不含锁）。

        Parameters
        ----------
        arm : 'A' | 'B'

        Returns
        -------
        dict — 包含 joint_pos_rad, joint_pos_degree, joint_vel_rad_per_s,
              joint_vel_degree_per_s, est_joint_force, botton_pressed, world_T_end
        """
        data = self.left_arm_data if arm == 'A' else self.right_arm_data
        with data.thread_lock:
            return {
                'joint_pos_rad':          list(data.joint_pos_rad),
                'joint_pos_degree':       list(data.joint_pos_degree),
                'joint_vel_rad_per_s':    list(data.joint_vel_rad_per_s),
                'joint_vel_degree_per_s': list(data.joint_vel_degree_per_s),
                'est_joint_force':        list(data.est_joint_force),
                'botton_pressed':         data.botton_pressed,
                'world_T_end':            data.world_T_end.copy(),
            }

    def start_ui(self, user_thread_func = None, if_start_plt: bool = True):
        """启动用户线程，可选启动绘图界面（阻塞主线程）。

        Parameters
        ----------
        user_thread_func : callable | None
            在新线程中执行的用户函数，应通过 self._user_thread_stop_event 检查退出信号。
            为 None 时不启动用户线程。
        if_start_plt : bool
            是否启动 matplotlib 绘图界面。
        """
        if user_thread_func is not None:
            def user_thread_target():
                with self._robot_ctrl_lock:
                    user_thread_func()
            self._user_thread_stop_event.clear()
            self._user_thread = threading.Thread(
                target=user_thread_target, daemon=True, name='user-thread')
            self._user_thread.start()
            self._arm_logger.info('用户线程已启动')
        else:
            self._arm_logger.info('未设置用户线程函数，跳过启动')

        if if_start_plt:
            self._start_plotting()  # 阻塞主线程，窗口关闭后返回

    def moveL(self, arm: str,
              target_xyz: list | None = None,
              target_rotate_mat: list | None = None,
              target_quat_wxyz: list | None = None,
              target_euler_zyx: list | None = None,
              target_aa_xyz: list | None = None,
              vel: float = 0.1):
        """
        笛卡尔直线运动。所有 target_* 参数均相对于**世界坐标系**。

        至少需要 target_xyz(单位 m)；姿态来源五选一，优先级：
        target_rotate_mat > target_quat_wxyz > target_euler_zyx > target_aa_xyz > 保持当前姿态

        Parameters
        ----------
        arm : 'A' | 'B'
        target_xyz : list(3,) — 目标位置，单位 m(世界坐标系)
        target_rotate_mat : list(9,) | list(3,list(3,)) — 目标旋转矩阵
        target_quat_wxyz : list(4,) — 目标四元数 (w,x,y,z)
        target_euler_zyx : list(3,) — 目标欧拉角 ZYX (yaw,pitch,roll)，单位 deg
        target_aa_xyz : list(3,) — 目标轴角，单位 rad
        vel : 收敛速度，单位 m/s (0~0.5)
        """
        if target_xyz is None:
            self._arm_logger.error('target_xyz is required')
            return

        # ---- 实例化(拷贝外部 list，防止污染) --------------------------
        target_xyz = list(target_xyz)
        if target_rotate_mat is not None:
            target_rotate_mat = list(target_rotate_mat)
        if target_quat_wxyz is not None:
            target_quat_wxyz = list(target_quat_wxyz)
        if target_euler_zyx is not None:
            target_euler_zyx = list(target_euler_zyx)
        if target_aa_xyz is not None:
            target_aa_xyz = list(target_aa_xyz)

        if arm not in ('A', 'B'):
            self._arm_logger.error(f'invalid arm: {arm}')
            return

        # ---- 读取当前位姿（线程安全拷贝）-------------------------------
        _d = self.get_arm_data(arm)
        ref_joints = _d['joint_pos_degree']
        _world_T = _d['world_T_end']

        # ---- 世界系 4x4 → 臂基系 xyzabc (m) ---------------------------
        _world_T_arm = np.asarray(
            self.ArmT.armA_B_W if arm == 'A' else self.ArmT.armB_B_W,
            dtype=float,
        )
        _arm_T = np.linalg.inv(_world_T_arm) @ _world_T  # 臂基系 4x4 (m)
        start_xyzabc = list(self._kk.mat4x4_to_xyzabc(pose_mat=_arm_T.tolist()))  # m

        # ---- 组装目标 xyzabc(世界坐标系，m / deg)---------------------
        xyz = list(target_xyz)  # 已是 m

        if target_rotate_mat is not None:
            end_xyzabc_world = self._rot_mat_to_xyz_euler_xyz(target_rotate_mat, xyz)

        elif target_quat_wxyz is not None:
            end_xyzabc_world = self._rot_mat_to_xyz_euler_xyz(
                self._quat_wxyz_to_rot_mat(target_quat_wxyz), xyz)

        elif target_euler_zyx is not None:
            end_xyzabc_world = self._rot_mat_to_xyz_euler_xyz(
                self._euler_zyx_to_rot_mat(target_euler_zyx), xyz)

        elif target_aa_xyz is not None:
            end_xyzabc_world = self._rot_mat_to_xyz_euler_xyz(
                self._aa_xyz_to_rot_mat(target_aa_xyz), xyz)

        else:
            # 保持当前姿态，只平移（直接取自世界系 4x4，避免 xyzabc 往返）
            start_xyzabc_world = list(self._kk.mat4x4_to_xyzabc(pose_mat=_world_T.tolist()))  # m
            end_xyzabc_world = list(start_xyzabc_world)
            end_xyzabc_world[0:3] = xyz

        # ---- 目标：世界系 → 臂基系 -----------------------------------
        end_xyzabc = self._world_to_arm_xyzabc(end_xyzabc_world, arm)

        # ---- 直线规划(臂基坐标系，m → mm) ----------------------------
        start_mm = [v * 1000.0 if i < 3 else v for i, v in enumerate(start_xyzabc)]
        end_mm   = [v * 1000.0 if i < 3 else v for i, v in enumerate(end_xyzabc)]
        vel_mm = vel * 1000.0  # m/s → mm/s
        _, pset = self._kk.movLA(
            start_xyzabc=start_mm,
            end_xyzabc=end_mm,
            ref_joints=ref_joints,
            vel=vel_mm, acc=500, freq_hz=100)

        # ---- 下发执行 ------------------------------------------------
        if pset:
            self._robot.setPln_Cart(arm=arm, pset=pset)

    def moveJ(self, arm: str, joints: list):
        """关节空间运动 — 直接下发目标关节角度（度）。

        Parameters
        ----------
        arm : 'A' | 'B'
        joints : list(7,) — 7 个关节的目标角度，单位 deg
        """
        if arm not in ('A', 'B'):
            self._arm_logger.error(f'moveJ: invalid arm "{arm}"')
            return
        if len(joints) != 7:
            self._arm_logger.error(f'moveJ: joints 长度应为 7，实际 {len(joints)}')
            return

        joints = list(joints)  # 拷贝，防止外部污染
        self._robot.clear_set()
        self._robot.set_joint_cmd_pose(arm=arm, joints=joints)
        self._robot.send_cmd()

    def start_collect_data(self, arm: str):
        """开始采集指定臂的轨迹数据（向 consumer2 线程发送采集指令）。

        Parameters
        ----------
        arm : 'A' | 'B'
        """
        if arm not in ('A', 'B'):
            self._arm_logger.error(f'start_collect_data: invalid arm "{arm}"')
            return
        self._queue2.put({"arm": arm, "collect": True})

    def save_data(self, arm: str, user_path: str = None):
        """停止采集并保存数据，可选将 fmv 拷贝到 user_path。

        Parameters
        ----------
        arm : 'A' | 'B'
        user_path : str | None — 目标目录路径，不为 None 时拷贝对应臂的 fmv 文件
                  （自动添加 armA_ 或 armB_ 前缀）
        """
        if arm not in ('A', 'B'):
            self._arm_logger.error(f'save_data: invalid arm "{arm}"')
            return
        self._queue2.put({"arm": arm, "collect": False, "user_path": user_path})

    def _robot_init(self):
        logging.basicConfig(format='%(message)s')
        self._arm_logger = logging.getLogger('debug_printer')
        self._arm_logger.setLevel(logging.WARNING)

        # ---- data structures -----------------------------------------
        self._dcss = DCSS()

        # ---- connect to robot ----------------------------------------
        self._robot = Marvin_Robot()
        init = self._robot.connect('192.168.1.190')
        if init == 0:
            self._arm_logger.error('failed to connect to the robot, port is occupied')
            exit(0)

        # flush bus errors
        time.sleep(0.05)
        self._robot.clear_set()
        self._robot.clear_error('A')
        self._robot.clear_error('B')
        self._robot.send_cmd()
        time.sleep(0.05)

        motion_tag = 0
        frame_update = None
        for _ in range(5):
            sub_data = self._robot.subscribe(self._dcss)
            print(f"connect frames :{sub_data['outputs'][0]['frame_serial']}")
            if (sub_data['outputs'][0]['frame_serial'] != 0
                    and frame_update != sub_data['outputs'][0]['frame_serial']):
                motion_tag += 1
                frame_update = sub_data['outputs'][0]['frame_serial']
            time.sleep(0.1)
        if motion_tag > 0:
            self._arm_logger.info('success: 机器人连接成功!')
        else:
            self._arm_logger.error('failed: 机器人连接失败!')
           

        # ---- logging switches ----------------------------------------
        self._robot.log_switch('1')
        self._robot.local_log_switch('1')

        # ---- clear errors again --------------------------------------
        self._robot.clear_set()
        self._robot.clear_error('A')
        self._robot.clear_error('B')
        self._robot.send_cmd()
        time.sleep(0.1)
        # ---- set position / velocity mode -----------------------------
        self._robot.clear_set()
        self._robot.set_state(arm='A',state=1)#state=1位置模式
        self._robot.set_vel_acc(arm='A',velRatio=100, AccRatio=100)
        self._robot.set_state(arm='B',state=1)#state=1位置模式
        self._robot.set_vel_acc(arm='B',velRatio=100, AccRatio=100)
        self._robot.send_cmd()

        '''实列化计算'''
        self._kk = Marvin_Kine()

        '''数据采集配置'''
        self._collect_cols = 14
        self._collect_idx = [0, 1, 2, 3, 4, 5, 6,
                             100, 101, 102, 103, 104, 105, 106,
                             0, 0, 0, 0, 0, 0, 0,
                             0, 0, 0, 0, 0, 0, 0,
                             0, 0, 0, 0, 0, 0, 0]
        self._traj_dir = os.path.join(_PROJ_ROOT, 'data/tj_arms_traj')
        os.makedirs(self._traj_dir, exist_ok=True)
        '''关闭日志'''
        self._kk.log_switch(0)  # 0 off, 1 on
        current_dir = os.path.dirname(os.path.abspath(__file__))
        ini_result = self._kk.load_config(arm_type=0, config_path=os.path.join(current_dir,'SDK_PYTHON/ccs_m6_40.MvKDCfg'))
        '''
        初始化动力学
        '''
        _ = self._kk.initial_kine(
            robot_type=ini_result['TYPE'][0],
            dh=ini_result['DH'][0],
            pnva=ini_result['PNVA'][0],
            j67=ini_result['BD'][0])

    # 订阅数据，在写数据线程中调用
    def _subscribe_data(self):
        sub_data = self._robot.subscribe(self._dcss)
        D2R = np.pi / 180.0

        with self.left_arm_data.thread_lock:
            # 左臂 - 位置
            self.left_arm_data.joint_pos_degree = list(sub_data["outputs"][0]["fb_joint_pos"])
            self.left_arm_data.joint_pos_rad = [d * D2R for d in self.left_arm_data.joint_pos_degree]
            # 左臂 - 速度
            self.left_arm_data.joint_vel_degree_per_s = list(sub_data["outputs"][0]["fb_joint_vel"])
            self.left_arm_data.joint_vel_rad_per_s = [d * D2R for d in self.left_arm_data.joint_vel_degree_per_s]
            # 左臂 - 估计关节力
            self.left_arm_data.est_joint_force = list(sub_data["outputs"][0]["est_joint_force"])
            # 按钮状态
            self.left_arm_data.botton_pressed = (sub_data["outputs"][0]["tip_di"][0] == 1)
            # ---- 拷贝关节角，供后续 FK 计算（不加锁） ----
            _left_joints_deg = list(self.left_arm_data.joint_pos_degree)

        with self.right_arm_data.thread_lock:
            # 右臂 - 位置
            self.right_arm_data.joint_pos_degree = list(sub_data["outputs"][1]["fb_joint_pos"])
            self.right_arm_data.joint_pos_rad = [d * D2R for d in self.right_arm_data.joint_pos_degree]
            # 右臂 - 速度
            self.right_arm_data.joint_vel_degree_per_s = list(sub_data["outputs"][1]["fb_joint_vel"])
            self.right_arm_data.joint_vel_rad_per_s = [d * D2R for d in self.right_arm_data.joint_vel_degree_per_s]
            # 右臂 - 估计关节力
            self.right_arm_data.est_joint_force = list(sub_data["outputs"][1]["est_joint_force"])
            # 按钮状态
            self.right_arm_data.botton_pressed = (sub_data["outputs"][1]["tip_di"][0] == 1)
            # ---- 拷贝关节角，供后续 FK 计算（不加锁） ----
            _right_joints_deg = list(self.right_arm_data.joint_pos_degree)

        # ================================================================
        #  FK → 世界坐标系 4x4 位姿矩阵（不加锁，避免阻塞订阅线程）
        #  参考 moveL 计算流程：fk(deg) → mm→m → 臂基系 × arm_B_W → 世界系
        # ================================================================
        _left_world_T  = self._compute_world_pose('A', _left_joints_deg)
        _right_world_T = self._compute_world_pose('B', _right_joints_deg)

        # ---- 加锁写入计算结果 ----
        if _left_world_T is not None:
            with self.left_arm_data.thread_lock:
                self.left_arm_data.world_T_end = _left_world_T
        if _right_world_T is not None:
            with self.right_arm_data.thread_lock:
                self.right_arm_data.world_T_end = _right_world_T
    # 写数据线程
    def _auto_subscribe_cb(self):
        """500Hz 自动订阅回调"""
        # ---- init ----
        pass
        # ---- loop ----
        while not self._subscribe_stop_event.is_set():
            self._subscribe_data()
            self._subscribe_stop_event.wait(0.002)

    def _start_auto_subscribe(self):
        """启动 500Hz 自动订阅线程"""
        if self._subscribe_thread is not None and self._subscribe_thread.is_alive():
            return
        self._subscribe_stop_event.clear()
        self._subscribe_thread = threading.Thread(
            target=self._auto_subscribe_cb, daemon=True)
        self._subscribe_thread.start()

    def _stop_auto_subscribe(self):
        """停止自动订阅线程"""
        self._subscribe_stop_event.set()
        if self._subscribe_thread is not None:
            self._subscribe_thread.join(timeout=1.0)
            self._subscribe_thread = None

    #  按钮边沿检测线程（两臂各一个，100Hz 轮询）
    def _button_monitor_cb(self, arm: str):
        """按钮上升沿检测循环 — 在独立线程中运行"""
        # ---- init ----
        data = self.left_arm_data if arm == 'A' else self.right_arm_data
        prev = False
        drag_active = False
        false_start_time = None
        # ---- loop ----
        while not self._button_monitor_stop_events[arm].is_set():
            with data.thread_lock:
                curr = data.botton_pressed
            if curr and not prev:
                self._thread_logger.info(f'{arm} 臂按钮按下')
                self._queue1.put({"arm":arm,"drag": True})
                self._queue2.put({"arm": arm, "collect": True})
                self._thread_logger.info(f'{arm} 臂拖动设置完毕')
                drag_active = True
                false_start_time = None  # 新一次拖动，复位计时

            if drag_active and not curr:
                if false_start_time is None:
                    false_start_time = time.time()
                elif time.time() - false_start_time > 1.5:
                    self._queue1.put({"arm": arm, "drag": False})
                    self._queue2.put({"arm": arm, "collect": False})
                    self._thread_logger.info(f'{arm} 臂按钮释放超时，设置 drag=False')
                    drag_active = False
                    false_start_time = None
            elif curr:
                false_start_time = None

            prev = curr
            self._button_monitor_stop_events[arm].wait(0.01)  # 100Hz

    def _start_button_monitor(self, arm: str):
        """启动按钮监控线程"""
        if (self._button_monitor_threads[arm] is not None
                and self._button_monitor_threads[arm].is_alive()):
            return
        self._button_monitor_stop_events[arm].clear()
        self._button_monitor_threads[arm] = threading.Thread(
            target=self._button_monitor_cb, args=(arm,),
            daemon=True, name=f'button-monitor-{arm}')
        self._button_monitor_threads[arm].start()
        self._thread_logger.info(f'{arm} 臂按钮监控已启动')

    def _stop_button_monitor(self, arm: str):
        """停止按钮监控线程"""
        self._button_monitor_stop_events[arm].set()
        t = self._button_monitor_threads[arm]
        if t is not None:
            t.join(timeout=1.0)
            self._button_monitor_threads[arm] = None

    # consumer1 线程：消费 queue1 中的数据
    def _consumer1_cb(self):
        """consumer1 回调 — 从 queue1 中消费数据，执行拖动设置"""
        # ---- init ----
        pass
        # ---- loop ----
        while not self._consumer1_stop_event.is_set():
            try:
                item = self._queue1.get(timeout=0.1)
                self._thread_logger.info(f'consumer1 收到消息: {item}')
                if item.get("drag"):
                    arm = item["arm"]
                    self._thread_logger.info(f'consumer1 为 {arm} 臂执行拖动设置')
                    with self._robot_ctrl_lock:
                        self._robot.clear_set()
                        self._robot.set_joint_kd_params(
                            arm=arm, K=[12, 12, 12, 10, 9, 9, 7],
                            D=[0.003, 0.003, 0.003, 0.002, 0.002, 0.002, 0.002],
                        )
                        self._robot.send_cmd()
                    time.sleep(0.1)
                    '''进拖动前先切换扭矩模式和切到关节阻抗模式'''
                    with self._robot_ctrl_lock:
                        self._robot.clear_set()
                        self._robot.set_state(arm=arm, state=3)  # torque mode
                        self._robot.send_cmd()
                    time.sleep(0.1)
                    with self._robot_ctrl_lock:
                        self._robot.clear_set()
                        self._robot.set_impedance_type(arm=arm, type=1)  # type=1 关节阻抗; type=2 坐标阻抗; type=3 力控
                        self._robot.send_cmd()
                    time.sleep(0.1)
                    '''设置拖动类型'''
                    with self._robot_ctrl_lock:
                        self._robot.clear_set()
                        self._robot.set_drag_space(arm=arm, dgType=1)
                        self._robot.send_cmd()
                    time.sleep(0.5)
                    self._thread_logger.info(f'consumer1 {arm} 臂拖动设置完毕')
                else:
                    arm = item["arm"]
                    self._thread_logger.info(f'consumer1 {arm} 臂 drag=False')
                    with self._robot_ctrl_lock:
                        self._robot.clear_set()
                        self._robot.clear_error(arm)
                        self._robot.send_cmd()
                        time.sleep(0.5)
                        self._robot.clear_set()
                        self._robot.set_state(arm=arm,state=1)#state=1位置模式
                        self._robot.set_vel_acc(arm=arm,velRatio=100, AccRatio=100)
                        self._robot.send_cmd()
                    time.sleep(0.5)
                    self._thread_logger.info(f'consumer1 {arm} 臂拖动设置关闭')
            except queue.Empty:
                pass
            self._consumer1_stop_event.wait(0.01)  # 100Hz

    def _start_consumer1(self):
        """启动 consumer1 线程"""
        if self._consumer1_thread is not None and self._consumer1_thread.is_alive():
            return
        self._consumer1_stop_event.clear()
        self._consumer1_thread = threading.Thread(
            target=self._consumer1_cb, daemon=True, name='consumer1')
        self._consumer1_thread.start()
        self._thread_logger.info('consumer1 线程已启动')

    def _stop_consumer1(self):
        """停止 consumer1 线程"""
        self._consumer1_stop_event.set()
        if self._consumer1_thread is not None:
            self._consumer1_thread.join(timeout=1.0)
            self._consumer1_thread = None

    # consumer2 线程：消费 queue2 中的数据
    def _consumer2_cb(self):
        """consumer2 回调 — 从 queue2 中消费数据"""
        # ---- init ----
        pass
        # ---- loop ----
        while not self._consumer2_stop_event.is_set():
            try:
                item = self._queue2.get(timeout=0.1)
                self._thread_logger.info(f'consumer2 收到消息: {item}')
                if item.get("collect"):
                    arm = item["arm"]
                    self._thread_logger.info(f'consumer2 开始采集 {arm} 臂数据')
                    with self._robot_ctrl_lock:
                        self._robot.clear_set()
                        self._robot.collect_data(targetNum=self._collect_cols,
                                                 targetID=self._collect_idx,
                                                 recordNum=1000000)
                        self._robot.send_cmd()
                        self._consumer2_stop_event.wait(0.1)
                else:
                    arm = item["arm"]
                    self._thread_logger.info(f'consumer2 停止采集 {arm} 臂数据')
                    with self._robot_ctrl_lock:
                        self._robot.clear_set()
                        self._robot.stop_collect_data()
                        self._robot.send_cmd()
                        self._consumer2_stop_event.wait(0.1)

                    # save collected data to file
                    date_str = datetime.now().strftime('%Y%m%d_%H%M%S')
                    path = os.path.join(self._traj_dir, f'{date_str}.txt')
                    self._robot.save_collected_data_to_path(path)
                    self._thread_logger.info(f'consumer2 数据已保存至: {path}')

                    # convert to .fmv
                    try:
                        result = convert_file(path)
                        if result:
                            l_path, r_path = result
                            self._thread_logger.info(f'consumer2 fmv saved: {l_path}, {r_path}')
                            # 用户指定路径 → 拷贝对应臂的 fmv
                            _user_path = item.get("user_path")
                            if _user_path is not None:
                                _src = l_path if arm == 'A' else r_path
                                _prefix = 'armA_' if arm == 'A' else 'armB_'
                                _dst = os.path.join(_user_path, _prefix + os.path.basename(_src))
                                shutil.copy2(_src, _dst)
                                self._thread_logger.info(f'consumer2 fmv 已拷贝至: {_dst}')
                    except Exception as exc:
                        self._thread_logger.error(f'consumer2 fmv conversion failed: {exc}')
            except queue.Empty:
                pass
            self._consumer2_stop_event.wait(0.01)  # 100Hz

    def _start_consumer2(self):
        """启动 consumer2 线程"""
        if self._consumer2_thread is not None and self._consumer2_thread.is_alive():
            return
        self._consumer2_stop_event.clear()
        self._consumer2_thread = threading.Thread(
            target=self._consumer2_cb, daemon=True, name='consumer2')
        self._consumer2_thread.start()
        self._thread_logger.info('consumer2 线程已启动')

    def _stop_consumer2(self):
        """停止 consumer2 线程"""
        self._consumer2_stop_event.set()
        if self._consumer2_thread is not None:
            self._consumer2_thread.join(timeout=1.0)
            self._consumer2_thread = None

    # camera 线程：读取相机帧供 animation 显示
    def _camera_cb(self):
        """camera 回调 — 30fps 读取相机帧"""
        # ---- init ----
        try:
            self._camera_cap = cv2.VideoCapture(2, cv2.CAP_V4L2)
            if not self._camera_cap.isOpened():
                self._thread_logger.warning('相机打开失败，camera 线程退出')
                self._camera_available = False
                return
            self._camera_cap.set(cv2.CAP_PROP_FRAME_WIDTH, 2560)
            self._camera_cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1440)
            self._camera_available = True
            self._thread_logger.info('相机已打开，camera 线程运行中')
        except Exception as e:
            self._thread_logger.warning(f'相机初始化异常: {e}，camera 线程退出')
            self._camera_available = False
            return
        # ---- loop ----
        while not self._camera_stop_event.is_set():
            ret, frame = self._camera_cap.read()
            if ret:
                with self._camera_lock:
                    self._camera_frame = frame
            self._camera_stop_event.wait(0.033)  # 30fps

    def _start_camera(self):
        """启动 camera 线程（失败不影响其他模块）"""
        if self._camera_thread is not None and self._camera_thread.is_alive():
            return
        self._camera_stop_event.clear()
        self._camera_thread = threading.Thread(
            target=self._camera_cb, daemon=True, name='camera')
        self._camera_thread.start()

    def _stop_camera(self):
        """停止 camera 线程并释放相机资源"""
        self._camera_stop_event.set()
        if self._camera_thread is not None:
            self._camera_thread.join(timeout=1.0)
            self._camera_thread = None
        if self._camera_cap is not None:
            self._camera_cap.release()
            self._camera_cap = None
            self._thread_logger.info('相机资源已释放')

    # ==================================================================
    #  Matplotlib Animation 方法
    # ==================================================================
    def _plot_init(self):
            # layout: 左侧(力矩+位置)，右侧相机
            self._plot_t0: float | None = None
            self._hist_t: deque = deque(maxlen=250)
            self._hist_left_force: deque = deque(maxlen=250)
            self._hist_yz: deque = deque(maxlen=150)  # world 坐标系下的 (y, z) 轨迹，50Hz × 3s

            self._fig = plt.figure(figsize=(16, 8))
            gs = GridSpec(2, 2, figure=self._fig, width_ratios=[1, 2], height_ratios=[1, 1])

            self._ax_left_force = self._fig.add_subplot(gs[0, 0])  # 左上：左臂力矩
            self._ax_yz         = self._fig.add_subplot(gs[1, 0])  # 左下：World Y-Z 轨迹
            self._ax_camera     = self._fig.add_subplot(gs[:, 1])  # 右侧跨两行：相机

            # ---- 力矩子图（7 条关节曲线）------------------------------
            self._ax_left_force.set_xlim(0, 5)
            self._ax_left_force.set_ylim(-100, 100)
            self._ax_left_force.set_title('Left Arm Joint Force')
            self._ax_left_force.set_xlabel('Time (s)')
            self._ax_left_force.set_ylabel('N')
            self._ax_left_force.grid(True, alpha=0.3)
            colors = plt.cm.tab10.colors
            joint_labels = [f'J{i+1}' for i in range(7)]
            self._lines_left_force = []
            for j in range(7):
                ln, = self._ax_left_force.plot([], [], color=colors[j], label=joint_labels[j], linewidth=1)
                self._lines_left_force.append(ln)
            self._ax_left_force.legend(loc='upper right', fontsize=6, ncol=4)

            # ---- World Y-Z 轨迹子图 ----------------------------------
            self._ax_yz.set_title('World Y-Z Trajectory')
            self._ax_yz.set_xlabel('Y (m)')
            self._ax_yz.set_ylabel('Z (m)')
            self._ax_yz.grid(True, alpha=0.3)
            self._ax_yz.set_xlim(0, 0.6)
            self._ax_yz.set_ylim(0, 1.5)
            self._yz_line, = self._ax_yz.plot([], [], 'b-', linewidth=0.8)       # 轨迹线
            self._yz_point, = self._ax_yz.plot([], [], 'ro', markersize=8)       # 当前点（圆饼）
            self._yz_text = self._ax_yz.annotate('', xy=(0, 0), xytext=(6, 6),
                                                 textcoords='offset points',
                                                 fontsize=7,
                                                 bbox=dict(boxstyle='round,pad=0.2',
                                                           fc='white', alpha=0.7))

            # 相机显示区域
            self._ax_camera.set_title('Camera Feed')
            self._ax_camera.axis('off')
            self._camera_img = self._ax_camera.imshow(
                np.zeros((720, 1280, 3), dtype=np.uint8))

            self._ani = FuncAnimation(
                self._fig, self._animation_update,
                interval=20,  # 50 Hz
                blit=True,
                cache_frame_data=False,
            )
    
    # --- 主线程 ---
    def _animation_update(self, frame):
        """FuncAnimation 回调 — 更新左臂力矩、World Y-Z 轨迹 + 相机画面（50Hz）"""
        _data = self.get_arm_data('A')
        left_force = _data['est_joint_force']
        _left_world_T = _data['world_T_end']

        # ---- 追加到滚动历史缓冲区 ------------------------------------
        now = time.time()
        if self._plot_t0 is None:
            self._plot_t0 = now
        self._hist_t.append(now - self._plot_t0)
        self._hist_left_force.append(left_force)

        t_raw = list(self._hist_t)
        if len(t_raw) > 1:
            t = [v - t_raw[-1] + 5.0 for v in t_raw]
        elif len(t_raw) == 1:
            t = [5.0]
        else:
            t = []

        # ---- 更新左臂力矩曲线 ---------------------------------------
        for j in range(7):
            self._lines_left_force[j].set_data(t, [h[j] for h in self._hist_left_force])

        # ---- 读 world_T_end → World Y-Z 轨迹 -----------------------
        cy = _left_world_T[1, 3]  # y (m)
        cz = _left_world_T[2, 3]  # z (m)
        self._hist_yz.append((cy, cz))
        if self._hist_yz:
            y_vals = [p[0] for p in self._hist_yz]
            z_vals = [p[1] for p in self._hist_yz]
            self._yz_line.set_data(y_vals, z_vals)
            self._yz_point.set_data([cy], [cz])
            self._yz_text.xy = (cy, cz)
            self._yz_text.set_text(f'({cy:.3f}, {cz:.3f})')

        # ---- 更新相机画面 -------------------------------------------
        if self._camera_available:
            with self._camera_lock:
                cam_frame = self._camera_frame.copy() if self._camera_frame is not None else None
            if cam_frame is not None:
                self._camera_img.set_data(cv2.cvtColor(cam_frame, cv2.COLOR_BGR2RGB))

        return (self._lines_left_force +
                [self._yz_line, self._yz_point, self._yz_text, self._camera_img])

    def _start_plotting(self):
        """启动绘图 — 阻塞主线程，关闭窗口后返回"""
        plt.tight_layout()
        plt.show()

    def _stop_plot_data(self):
        """停止绘图（关窗后 FuncAnimation 自动停止，此处为防御性清理）"""
        if self._ani is not None:
            self._ani = None
        plt.close('all')

    # 释放机器人
    def _release(self):
        """Disable arms and release _robot resources."""
        self._robot.clear_set()
        self._robot.set_state(arm='A', state=0)
        self._robot.set_state(arm='B', state=0)
        self._robot.send_cmd()
        time.sleep(0.1)
        self._robot.release_robot()

    # ==================================================================
    #  坐标变换计算方法 
    # ==================================================================
    
    def _rot_mat_to_xyz_euler_xyz(self, rot_input, xyz):
        """旋转矩阵(3×3 或展平 9) + 位置(m) → xyzabc (list, m/deg)"""
        rot = np.asarray(rot_input, dtype=float)
        if rot.shape == (9,):
            rot = rot.reshape(3, 3)
        elif rot.shape != (3, 3):
            raise ValueError(f"Expected 3×3 or (9,) rotation, got {rot.shape}")
        mat4 = np.eye(4)
        mat4[:3, :3] = rot
        mat4[:3, 3] = np.asarray(xyz, dtype=float)
        return self._kk.mat4x4_to_xyzabc(pose_mat=mat4.tolist())

    def _world_to_arm_xyzabc(self, world_xyzabc, arm):
        """世界坐标系 xyzabc → 机械臂基坐标系 xyzabc"""
        world_T = np.asarray(self._kk.xyzabc_to_mat4x4(xyzabc=world_xyzabc))
        arm_T = np.asarray(self.ArmT.armA_B_W if arm == 'A' else self.ArmT.armB_B_W)
        arm_T_target = np.linalg.inv(arm_T) @ world_T
        return self._kk.mat4x4_to_xyzabc(pose_mat=arm_T_target.tolist())

    def _arm_to_world_xyzabc(self, arm_xyzabc, arm):
        """机械臂基坐标系 xyzabc → 世界坐标系 xyzabc"""
        arm_T_mat = np.asarray(self._kk.xyzabc_to_mat4x4(xyzabc=arm_xyzabc))
        world_T_arm = np.asarray(self.ArmT.armA_B_W if arm == 'A' else self.ArmT.armB_B_W)
        world_T_target = world_T_arm @ arm_T_mat
        return self._kk.mat4x4_to_xyzabc(pose_mat=world_T_target.tolist())

    def _compute_world_pose(self, arm: str, joints_deg: list):
        """FK → 世界坐标系 4x4 位姿矩阵（不加锁，纯计算）。

        Parameters
        ----------
        arm : 'A' | 'B'
        joints_deg : list(7,) — 关节角度 (deg)

        Returns
        -------
        np.ndarray | None — 4x4 变换矩阵 (m)，FK 失败返回 None
        """
        fk_mat = self._kk.fk(joints=joints_deg)  # 臂基坐标系 4x4 (mm)
        if not fk_mat:
            return None

        arm_T = np.asarray(fk_mat, dtype=float).copy()
        arm_T[:3, 3] *= 0.001  # mm → m

        world_T_arm = np.asarray(
            self.ArmT.armA_B_W if arm == 'A' else self.ArmT.armB_B_W,
            dtype=float,
        )
        return world_T_arm @ arm_T  # 世界坐标系 4x4 (m)

    # ==================================================================
    #  Static 方法
    # ==================================================================

    @staticmethod
    def _quat_wxyz_to_rot_mat(q):
        """四元数 (w,x,y,z) → 3x3 旋转矩阵 (ndarray)"""
        w, x, y, z = q
        return np.array([
            [1 - 2*y*y - 2*z*z,   2*x*y - 2*w*z,     2*x*z + 2*w*y],
            [2*x*y + 2*w*z,       1 - 2*x*x - 2*z*z, 2*y*z - 2*w*x],
            [2*x*z - 2*w*y,       2*y*z + 2*w*x,     1 - 2*x*x - 2*y*y],
        ])

    @staticmethod
    def _aa_xyz_to_rot_mat(aa):
        """轴角 (rx, ry, rz) (rad) → 3x3 旋转矩阵 (ndarray, Rodrigues)"""
        aa = np.asarray(aa, dtype=float)
        theta = np.linalg.norm(aa)
        if theta < 1e-12:
            return np.eye(3)
        k = aa / theta
        K = np.array([[0, -k[2], k[1]],
                      [k[2], 0, -k[0]],
                      [-k[1], k[0], 0]])
        return np.eye(3) + np.sin(theta) * K + (1 - np.cos(theta)) * (K @ K)

    @staticmethod
    def _euler_zyx_to_rot_mat(e):
        """欧拉角 ZYX (yaw,pitch,roll) (deg) → 3x3 旋转矩阵 (ndarray)"""
        z, y, x = np.radians(e)
        cz, sz = np.cos(z), np.sin(z)
        cy, sy = np.cos(y), np.sin(y)
        cx, sx = np.cos(x), np.sin(x)
        Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
        Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
        Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
        return Rz @ Ry @ Rx
