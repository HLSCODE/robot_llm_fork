"""
Convert TJ robot drag-teach .txt recordings to .fmv format.

Usage::

    python txt2fmv_tranformer.py

Reads all ``*.txt`` files from ``data/tj_arms_traj/`` and writes
``*_L.fmv`` / ``*_R.fmv`` pairs to ``data/tj_arm_fmv/``.
"""

import os
import re

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
SRC_DIR = os.path.join(os.path.dirname(__file__), 'tj_arms_traj')
DST_DIR = os.path.join(os.path.dirname(__file__), 'tj_arm_fmv')
DST_DIR_L = os.path.join(DST_DIR, 'left_arm')
DST_DIR_R = os.path.join(DST_DIR, 'right_arm')
os.makedirs(DST_DIR_L, exist_ok=True)
os.makedirs(DST_DIR_R, exist_ok=True)

# A-arm: direct mapping (same field names)
# B-arm: map input fields to fmv output fields
FMV_FIELDS = ['Z', 'A', 'B', 'C', 'U', 'V', 'W']
B_ARM_SRC  = ['O', 'P', 'Q', 'I', 'J', 'K', 'L']


def parse_line(line):
    """Parse a ``X 1.0$Y 2.0$...`` line into a dict."""
    result = {}
    for token in line.strip().split('$'):
        if not token:
            continue
        parts = token.strip().split()
        if len(parts) == 2:
            result[parts[0]] = float(parts[1])
    return result


def format_fmv_line(joint_angles):
    """Format a single .fmv data line.

    Output field order: Z A B C U V W X Y
    7 joint angles first, then X=0, Y=0.
    """
    parts = []
    for field, val in zip(FMV_FIELDS, joint_angles):
        parts.append(f'{field} {val:.6f}')
    parts.append('X 0.000000')
    parts.append('Y 0.000000')
    return '$'.join(parts) + '$\n'


def convert_file(src_path):
    """Convert one .txt file. Returns (l_path, r_path) or None."""
    base = os.path.splitext(os.path.basename(src_path))[0]
    l_path = os.path.join(DST_DIR_L, f'{base}.fmv')
    r_path = os.path.join(DST_DIR_R, f'{base}.fmv')

    with open(src_path, 'r') as f:
        lines = f.readlines()

    if not lines:
        return None

    header = lines[0].strip()
    match = re.match(r'PoinType=(\d+)@(\d+)', header)
    if not match:
        print(f'  skip: bad header "{header}"')
        return None

    data_lines = lines[1:]
    num_rows = len(data_lines)

    with open(l_path, 'w') as lf, open(r_path, 'w') as rf:
        lf.write(f'PoinType=9@{num_rows}\n')
        rf.write(f'PoinType=9@{num_rows}\n')

        for line in data_lines:
            d = parse_line(line)
            if not d:
                continue

            # A arm: Z, A, B, C, U, V, W (direct)
            l_angles = [d.get(k, 0.0) for k in FMV_FIELDS]
            lf.write(format_fmv_line(l_angles))

            # B arm: O→Z, P→A, Q→B, I→C, J→U, K→V, L→W
            r_angles = [d.get(k, 0.0) for k in B_ARM_SRC]
            rf.write(format_fmv_line(r_angles))

    return (l_path, r_path)


def main():
    txt_files = sorted(
        f for f in os.listdir(SRC_DIR)
        if f.endswith('.txt') and os.path.isfile(os.path.join(SRC_DIR, f))
    )
    if not txt_files:
        print(f'No .txt files found in {SRC_DIR}')
        return

    print(f'Found {len(txt_files)} .txt file(s)')
    for name in txt_files:
        src = os.path.join(SRC_DIR, name)
        result = convert_file(src)
        if result:
            l_path, r_path = result
            print(f'  {name} → {os.path.basename(l_path)}, {os.path.basename(r_path)}')
    print('Done.')


if __name__ == '__main__':
    main()
