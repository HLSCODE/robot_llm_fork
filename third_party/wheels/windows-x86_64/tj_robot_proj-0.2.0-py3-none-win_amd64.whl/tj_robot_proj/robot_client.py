"""``RobotClient`` — the single, typed, production-grade public entry point.

Lifecycle::

    client = RobotClient(config)   # no side effects
    client.initialize()            # connect, initialise, and start state subscription
    # ... use ...
    client.close()                 # idempotent shutdown

Context-manager support::

    with RobotClient(config) as client:
        client.initialize()
"""

from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager
from datetime import datetime
import hashlib
import logging
import math
import os
from pathlib import Path
import re
import sys
from threading import Condition, Event, Lock, Thread, current_thread
import time
from types import TracebackType
from typing import Iterable, Type

from transitions import Machine

from tj_robot_proj.errors import (
    ConfigurationError,
    KinematicsError,
    OperationCancelledError,
)
from tj_robot_proj.native.session import NativeSession
from tj_robot_proj.native.txt2fmv_tranformer import format_fmv_line
from tj_robot_proj.trajectory_description import TrajectoryDescription

from tj_robot_proj.value_objects import *

logger = logging.getLogger(__name__)


_FMV_HEADER_PATTERN = re.compile(r"PoinType=9@([1-9]\d*)")
_FMV_NUMBER_PATTERN = r"([+-]?\d+\.\d{6})"
_FMV_DATA_PATTERN = re.compile(
    rf"Z {_FMV_NUMBER_PATTERN}\$"
    rf"A {_FMV_NUMBER_PATTERN}\$"
    rf"B {_FMV_NUMBER_PATTERN}\$"
    rf"C {_FMV_NUMBER_PATTERN}\$"
    rf"U {_FMV_NUMBER_PATTERN}\$"
    rf"V {_FMV_NUMBER_PATTERN}\$"
    rf"W {_FMV_NUMBER_PATTERN}\$"
    rf"X {_FMV_NUMBER_PATTERN}\$"
    rf"Y {_FMV_NUMBER_PATTERN}\$"
)


_BUTTON_RELEASED = "released"
_BUTTON_PRESS_PENDING = "press_pending"
_BUTTON_PRESSED = "pressed"
_BUTTON_RELEASE_PENDING = "release_pending"

_COLLECTION_SOURCE_USER = "user"
_COLLECTION_SOURCE_BUTTON = "on_button_pressed"

_BUTTON_STATES = [
    _BUTTON_RELEASED,
    _BUTTON_PRESS_PENDING,
    _BUTTON_PRESSED,
    _BUTTON_RELEASE_PENDING,
]

_BUTTON_TRANSITIONS = [
    {
        "trigger": "begin_press_confirmation",
        "source": _BUTTON_RELEASED,
        "dest": _BUTTON_PRESS_PENDING,
    },
    {
        "trigger": "cancel_press_confirmation",
        "source": _BUTTON_PRESS_PENDING,
        "dest": _BUTTON_RELEASED,
    },
    {
        "trigger": "confirm_press",
        "source": _BUTTON_PRESS_PENDING,
        "dest": _BUTTON_PRESSED,
        "after": "on_button_pressed",
    },
    {
        "trigger": "begin_release_confirmation",
        "source": _BUTTON_PRESSED,
        "dest": _BUTTON_RELEASE_PENDING,
    },
    {
        "trigger": "cancel_release_confirmation",
        "source": _BUTTON_RELEASE_PENDING,
        "dest": _BUTTON_PRESSED,
    },
    {
        "trigger": "confirm_release",
        "source": _BUTTON_RELEASE_PENDING,
        "dest": _BUTTON_RELEASED,
        "after": "on_button_released",
    },
]


class _ButtonStateModel:
    """State-machine callbacks for one arm's end-effector button."""

    state: str

    def __init__(
        self,
        client: "RobotClient",
        arm: Arm,
    ) -> None:
        self._client = client
        self._arm = arm

    def on_button_pressed(self) -> None:
        """Run after five consecutive pressed confirmation cycles."""
        self._client.change_to_drag_mode(self._arm)
        self._client._collect_data_from_button()

    def on_button_released(self) -> None:
        """Run after five consecutive released confirmation cycles."""
        self._client.change_to_norm_mode(self._arm)
        self._client._stop_button_collection_if_active()


class _ButtonMonitorThread(Thread):
    """Privately monitor and debounce both end-effector buttons at 50 Hz."""

    def __init__(self, client: "RobotClient") -> None:
        super().__init__(daemon=True, name="tj-sdk-button-monitor")
        self._client = client
        self._stop_event = Event()
        self._frequency_hz = 50.0
        self._period_seconds = 1.0 / self._frequency_hz
        self._confirmation_cycles = 5
        self._arms = (Arm.LEFT, Arm.RIGHT)
        self._previous_pressed = {arm: False for arm in self._arms}
        self._confirmation_counts = {arm: 0 for arm in self._arms}
        self._state_conditions = {arm: Condition() for arm in self._arms}
        self._motion_active = {arm: False for arm in self._arms}
        self._motion_cancel_events = {arm: Event() for arm in self._arms}
        self._mode_transitioning = {arm: False for arm in self._arms}
        self._models = {
            arm: _ButtonStateModel(self._client, arm) for arm in self._arms
        }
        self._machines = {
            arm: Machine(
                model=self._models[arm],
                states=_BUTTON_STATES,
                transitions=_BUTTON_TRANSITIONS,
                initial=_BUTTON_RELEASED,
                auto_transitions=False,
            )
            for arm in self._arms
        }
        self._last_error_log_time = 0.0

    def stop(self) -> None:
        """Request termination of the monitoring loop."""
        self._stop_event.set()
        for condition in self._state_conditions.values():
            with condition:
                condition.notify_all()

    def stop_and_join(self, timeout: float = 2.0) -> None:
        """Request termination and wait unless called by this thread."""
        self.stop()
        if self.is_alive() and current_thread() is not self:
            self.join(timeout=timeout)
            if self.is_alive():
                logger.warning("Button monitor thread did not stop in time")

    def run(self) -> None:
        """Sample both arms while maintaining a stable 50 Hz schedule."""
        next_sample_time = time.monotonic()
        while not self._stop_event.is_set():
            for arm in self._arms:
                if self._stop_event.is_set():
                    return
                try:
                    pressed = bool(self._client.get_arm_data(arm).button_pressed)
                    self._process_sample(arm, pressed)
                except Exception:
                    self._log_sample_error(arm)

            next_sample_time += self._period_seconds
            delay = next_sample_time - time.monotonic()
            if delay <= 0:
                next_sample_time = time.monotonic()
                continue
            self._stop_event.wait(delay)

    def _process_sample(self, arm: Arm, pressed: bool) -> None:
        condition = self._state_conditions[arm]
        deferred_trigger: str | None = None
        with condition:
            model = self._models[arm]
            previous_pressed = self._previous_pressed[arm]
            try:
                if model.state == _BUTTON_RELEASED:
                    if not previous_pressed and pressed:
                        if self._motion_active[arm]:
                            self._motion_cancel_events[arm].set()
                        self._trigger(arm, "begin_press_confirmation")
                        self._confirmation_counts[arm] = 0

                elif model.state == _BUTTON_PRESS_PENDING:
                    if pressed:
                        self._confirmation_counts[arm] += 1
                        if self._confirmation_counts[arm] >= self._confirmation_cycles:
                            self._mode_transitioning[arm] = True
                            deferred_trigger = "confirm_press"
                            self._confirmation_counts[arm] = 0
                    else:
                        self._trigger(arm, "cancel_press_confirmation")
                        self._confirmation_counts[arm] = 0

                elif model.state == _BUTTON_PRESSED:
                    if previous_pressed and not pressed:
                        self._trigger(arm, "begin_release_confirmation")
                        self._confirmation_counts[arm] = 0

                elif model.state == _BUTTON_RELEASE_PENDING:
                    if not pressed:
                        self._confirmation_counts[arm] += 1
                        if self._confirmation_counts[arm] >= self._confirmation_cycles:
                            self._mode_transitioning[arm] = True
                            deferred_trigger = "confirm_release"
                            self._confirmation_counts[arm] = 0
                    else:
                        self._trigger(arm, "cancel_release_confirmation")
                        self._confirmation_counts[arm] = 0
            finally:
                self._previous_pressed[arm] = pressed
                condition.notify_all()

        if deferred_trigger is not None:
            self._run_deferred_trigger(arm, deferred_trigger)

    def _run_deferred_trigger(self, arm: Arm, trigger: str) -> None:
        """Run mode-changing state callbacks without holding the state lock."""
        try:
            self._trigger(arm, trigger)
        finally:
            condition = self._state_conditions[arm]
            with condition:
                self._mode_transitioning[arm] = False
                condition.notify_all()

    @contextmanager
    def motion_guard(self, arm: Arm) -> Generator[Event, None, None]:
        """Admit motion only while released and expose button cancellation."""
        condition = self._state_conditions[arm]
        with condition:
            while True:
                if self._stop_event.is_set():
                    raise OperationCancelledError(
                        "Motion cancelled because the button monitor is stopping",
                        operation="motion_guard",
                        arm=arm.value,
                    )
                if (
                    self._models[arm].state == _BUTTON_RELEASED
                    and not self._motion_active[arm]
                    and not self._mode_transitioning[arm]
                ):
                    self._motion_cancel_events[arm].clear()
                    self._motion_active[arm] = True
                    break
                condition.wait()

        try:
            yield self._motion_cancel_events[arm]
        finally:
            with condition:
                self._motion_active[arm] = False
                condition.notify_all()

    def _trigger(self, arm: Arm, trigger: str) -> None:
        getattr(self._models[arm], trigger)()

    def _log_sample_error(self, arm: Arm) -> None:
        now = time.monotonic()
        if now - self._last_error_log_time >= 5.0:
            logger.exception("Failed to monitor %s arm button", arm.name.lower())
            self._last_error_log_time = now


class RobotClient:
    """Top-level entry point for controlling a dual-arm robot.

    One ``RobotClient`` corresponds to one controller session.
    """

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    def __init__(self, config: RobotConfig) -> None:
        """Create a client with the given *config*.

        **No hardware is touched at this point** — the constructor only
        stores the validated configuration.
        """
        self._config = config
        self._session = NativeSession(config)
        self._button_monitor_thread = _ButtonMonitorThread(self)
        self._collection_state_lock = Lock()
        self._is_collecting_data = False
        self._collect_data_source: str | None = None
        self._trajectory_description_cache: dict[
            tuple[str, str], tuple[Path, str]
        ] = {}

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> "RobotClient":
        return self

    def __exit__(
        self,
        exc_type: Type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self.close()

    def __del__(self) -> None:
        if not self._session.closed:
            logger.warning(
                "RobotClient was not explicitly closed; "
                "releasing in __del__.  This is unreliable — use a "
                "context manager or call close() explicitly."
            )
            self.close()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def initialize(self) -> None:
        """Connect to and initialise the robot.

        Loads the native libraries, establishes the TCP connection, clears
        errors, sets position mode, initialises kinematics, and starts the
        background state subscription.

        Raises:
            NativeLibraryError: The native DLL/SO could not be loaded.
            ConnectionError: TCP connection to the controller failed.
            InitializationError: Initialisation failed (errors, kinematics, etc.).
        """
        self._session.connect()
        self._session.initialize()
        # Start the background state subscription.
        self._session.start_subscription()
        if not self._button_monitor_thread.is_alive():
            self._button_monitor_thread.start()

        # solve unexpected error
        self.movej_step(
            Arm.LEFT,
            joints_step_rad=(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
            vel=10,
        )
        self.movej_step(
            Arm.RIGHT,
            joints_step_rad=(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
            vel=10,
        )

    def close(self) -> None:
        """Idempotent shutdown.

        Stops active data collection without saving, stops background threads,
        releases the native connection, and frees native resources. Safe to
        call multiple times.
        """
        try:
            with self._collection_state_lock:
                if self._is_collecting_data:
                    try:
                        if not self._session.stop_collect_data():
                            logger.warning(
                                "Controller reported that data collection did not "
                                "stop cleanly during client shutdown"
                            )
                    except Exception:
                        logger.exception(
                            "Failed to stop data collection during shutdown"
                        )
                    finally:
                        self._is_collecting_data = False
                        self._collect_data_source = None
            self._button_monitor_thread.stop_and_join()
            self._session.stop_subscription()
            self._session.close()
        finally:
            try:
                self._session.cleanup_temp_data()
            except Exception:
                logger.exception("Failed to clean temporary recording backups")

    # ------------------------------------------------------------------
    # Get robot state
    # ------------------------------------------------------------------
    def get_arm_data(self, arm: Arm) -> ArmData :
        return self._session.get_arm_data(arm=arm)

    # ------------------------------------------------------------------
    # Motion
    # ------------------------------------------------------------------

    @staticmethod
    def _motion_was_cancelled(cancel_event: Event) -> bool:
        return cancel_event.is_set()

    def change_to_drag_mode(self, arm: Arm) -> None:
        """Change one arm to joint-impedance drag mode."""
        if not isinstance(arm, Arm):
            raise ConfigurationError(
                f"arm must be an Arm, got {arm!r}",
                operation="change_to_drag_mode",
            )
        self._session.change_to_drag_mode(arm.value)

    def change_to_norm_mode(self, arm: Arm) -> None:
        """Clear errors and return one arm to normal position mode."""
        if not isinstance(arm, Arm):
            raise ConfigurationError(
                f"arm must be an Arm, got {arm!r}",
                operation="change_to_norm_mode",
            )
        self._session.change_to_norm_mode(arm.value)

    def soft_emergency_stop(self) -> None:
        """Soft-stop both robot arms."""
        self._session.soft_emergency_stop()

    def quick_stop(self, arm: Arm) -> None:
        """Quick-stop one robot arm."""
        if not isinstance(arm, Arm):
            raise ConfigurationError(
                f"arm must be an Arm, got {arm!r}",
                operation="quick_stop",
            )
        self._session.quick_stop(arm.value)

    def run_trajectory(
        self,
        arm: Arm,
        fmv_trajectory_path: str | None = None,
        is_block: bool = True,
        tolerance: float = 0.01,
    ) -> int:
        """Validate and execute an FMV trajectory.

        When no path is supplied, the newest arm-matching FMV under the
        project ``temp_data`` directory is selected. The arm first moves to
        the FMV's first joint position, then the session starts PVT playback.
        When ``is_block`` is true, this method first waits for the estimated
        trajectory duration (FMV row count divided by configured trajectory
        frequency), then samples feedback every 50 ms until every joint is
        within ``tolerance`` radians of the final FMV position. PVT playback
        uses the same button-state motion guard as other motions. A button
        press while the guard is active ends the current call early and, once
        confirmed, transitions the arm into drag mode.

        Returns:
            ``0`` when the operation completes normally, including successful
            non-blocking startup; ``1`` when a button press interrupts it.
        """
        if not isinstance(arm, Arm):
            raise ConfigurationError(
                f"arm must be an Arm, got {arm!r}",
                operation="run_trajectory",
            )
        try:
            tolerance = float(tolerance)
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(
                f"tolerance must be a positive finite value, got {tolerance!r}",
                operation="run_trajectory",
                arm=arm.value,
            ) from exc
        if tolerance <= 0 or not math.isfinite(tolerance):
            raise ConfigurationError(
                f"tolerance must be a positive finite value, got {tolerance}",
                operation="run_trajectory",
                arm=arm.value,
            )

        trajectory_path = self._resolve_fmv_trajectory_path(
            arm,
            fmv_trajectory_path,
        )
        (
            first_joints_deg,
            final_joints_deg,
            trajectory_frame_count,
        ) = self._validate_fmv_trajectory(trajectory_path, arm)

        # Reaching the first frame is a required precondition for PVT playback,
        # even when the caller does not wait for the PVT motion to finish.
        move_to_start_result = self.movej(
            arm,
            joints_deg=first_joints_deg,
            vel=5,
            is_block=True,
            tolerance=tolerance * 0.2,
        )
        if move_to_start_result == 1:
            return 1

        logger.warning(
            "begin to run trajectory"
        )

        final_joints_rad = tuple(map(math.radians, final_joints_deg))
        with self._button_monitor_thread.motion_guard(arm) as cancel_event:
            if self._motion_was_cancelled(cancel_event):
                return 1
            self._session.run_trajectory(arm.value, str(trajectory_path))
            if self._motion_was_cancelled(cancel_event):
                return 1

            if not is_block:
                return 0

            trajectory_duration_seconds = (
                trajectory_frame_count / self._config.trajectory_frequency
            )
            if cancel_event.wait(trajectory_duration_seconds):
                return 1

            while True:
                if self._motion_was_cancelled(cancel_event):
                    return 1
                feedback_rad = self.get_arm_data(arm).joints_pos.pos_rad
                if self._motion_was_cancelled(cancel_event):
                    return 1
                if all(
                    abs(feedback - target) < tolerance
                    for feedback, target in zip(
                        feedback_rad,
                        final_joints_rad,
                        strict=True,
                    )
                ):
                    return 0
                if cancel_event.wait(0.05):
                    return 1

    def run_trajectory_description(
        self,
        arm: Arm,
        trajectory_description: TrajectoryDescription,
        is_block: bool = True,
        tolerance: float = 0.01,
    ) -> int:
        """Convert a 500 Hz world-frame pose description to FMV and play it.

        First move linearly to the initial pose, always blocking. The first
        execution reads the measured joints as the first IK seed, and each
        subsequent pose uses the previous IK solution. The seven-joint degree
        sequence is saved as
        YYYYMMDD_HHMMSS_<L/R>_trajectory_description.fmv in
        /tmp/tj_trajectory_data on Linux, or the working directory elsewhere.
        Replaying an unchanged description on the same arm reuses that FMV;
        the session also reuses the controller's uploaded PVT slot, avoiding
        repeated entry into the native SDK file-transfer teardown path.
        The description and RobotConfig.trajectory_frequency must both be
        500 Hz, since run_trajectory uses the latter to time playback.

        is_block controls final playback only. tolerance is passed to movel
        (radians/metres) and run_trajectory (joint radians). Motion guarding
        is provided by those two methods, including the movej to FMV start.

        Returns:
            0 on normal completion or non-blocking playback startup;
            1 if the initial move or playback is interrupted by a button.

        Raises:
            ConfigurationError: Invalid input, frequency, joint data or file.
            KinematicsError: Any pose cannot be solved; playback is not started.
        """
        operation = "run_trajectory_description"
        if not isinstance(arm, Arm):
            raise ConfigurationError("arm must be an Arm", operation=operation)
        if not isinstance(trajectory_description, TrajectoryDescription):
            raise ConfigurationError(
                "trajectory_description must be a TrajectoryDescription",
                operation=operation, arm=arm.value,
            )
        if trajectory_description.frequency != 500:
            raise ConfigurationError(
                "TrajectoryDescription.frequency must be 500 Hz",
                operation=operation, arm=arm.value,
            )
        if self._config.trajectory_frequency != 500:
            raise ConfigurationError(
                "RobotConfig.trajectory_frequency must be 500 Hz for description playback",
                operation=operation, arm=arm.value,
            )
        if not isinstance(is_block, bool):
            raise ConfigurationError(
                "is_block must be a bool", operation=operation, arm=arm.value,
            )
        try:
            tolerance = float(tolerance)
        except (TypeError, ValueError, OverflowError) as exc:
            raise ConfigurationError(
                "tolerance must be a positive finite value",
                operation=operation, arm=arm.value,
            ) from exc
        if not math.isfinite(tolerance) or tolerance <= 0:
            raise ConfigurationError(
                "tolerance must be a positive finite value",
                operation=operation, arm=arm.value,
            )

        # Take a snapshot so later appends to the description cannot change
        # the path while the initial move and offline IK are in progress.
        poses = trajectory_description.p_list
        if not poses or not all(isinstance(pose, SE3) for pose in poses):
            raise ConfigurationError(
                "trajectory_description must contain SE3 poses",
                operation=operation, arm=arm.value,
            )
        if self.movel(arm, poses[0], is_block=True, tolerance=tolerance) == 1:
            return 1

        description_hash = hashlib.sha256()
        description_hash.update(arm.value.encode("ascii"))
        description_hash.update(
            float(trajectory_description.frequency).hex().encode("ascii")
        )
        for pose in poses:
            description_hash.update(pose.matrix.tobytes(order="C"))
        cache_key = (arm.value, description_hash.hexdigest())
        description_cache = getattr(self, "_trajectory_description_cache", None)
        if description_cache is None:
            description_cache = {}
            self._trajectory_description_cache = description_cache

        trajectory_path: Path | None = None
        cached = description_cache.get(cache_key)
        if cached is not None:
            cached_path, cached_file_hash = cached
            try:
                current_file_hash = hashlib.sha256(
                    cached_path.read_bytes()
                ).hexdigest()
            except OSError:
                current_file_hash = ""
            if current_file_hash == cached_file_hash:
                trajectory_path = cached_path
                logger.info(
                    "Reusing cached FMV for an unchanged trajectory description: %s",
                    trajectory_path,
                )

        if trajectory_path is None:
            previous_joints = self.get_arm_data(arm).joints_pos
            if (
                not isinstance(previous_joints, JointPositions)
                or len(previous_joints) != 7
            ):
                raise ConfigurationError(
                    "Description playback requires exactly 7 measured joints",
                    operation=operation, arm=arm.value,
                )
            joint_trajectory_deg: list[list[float]] = []
            for index, pose in enumerate(poses):
                try:
                    joints = self._session.ik(
                        arm.value, pose, ref_joints=previous_joints,
                    )
                except KinematicsError as exc:
                    raise KinematicsError(
                        "Description inverse kinematics failed at frame "
                        f"{index + 1}/{len(poses)}",
                        operation=operation, arm=arm.value,
                    ) from exc
                if not isinstance(joints, JointPositions) or len(joints) != 7:
                    raise ConfigurationError(
                        "Description IK must return exactly 7 joint positions",
                        operation=operation, arm=arm.value,
                    )
                angles = list(joints.pos_deg)
                if not all(math.isfinite(angle) for angle in angles):
                    raise ConfigurationError(
                        "Description IK returned non-finite joint angles",
                        operation=operation, arm=arm.value,
                    )
                joint_trajectory_deg.append(angles)
                previous_joints = joints

            trajectory_dir = (
                Path("/tmp/tj_trajectory_data")
                if sys.platform.startswith("linux") else Path.cwd()
            )
            date_str = datetime.now().strftime("%Y%m%d_%H%M%S")
            arm_suffix = "L" if arm is Arm.LEFT else "R"
            trajectory_path = (
                trajectory_dir
                / f"{date_str}_{arm_suffix}_trajectory_description.fmv"
            )
            try:
                trajectory_dir.mkdir(parents=True, exist_ok=True)
                with trajectory_path.open(
                    "w", encoding="utf-8", newline="\n"
                ) as output:
                    output.write(f"PoinType=9@{len(joint_trajectory_deg)}\n")
                    for angles in joint_trajectory_deg:
                        output.write(format_fmv_line(angles))
                generated_file_hash = hashlib.sha256(
                    trajectory_path.read_bytes()
                ).hexdigest()
            except (OSError, ValueError) as exc:
                raise ConfigurationError(
                    f"Unable to write description FMV {trajectory_path}: {exc}",
                    operation=operation, arm=arm.value,
                ) from exc
            description_cache[cache_key] = (
                trajectory_path,
                generated_file_hash,
            )

        return self.run_trajectory(
            arm, fmv_trajectory_path=str(trajectory_path),
            is_block=is_block, tolerance=tolerance,
        )

    def _resolve_fmv_trajectory_path(
        self,
        arm: Arm,
        fmv_trajectory_path: str | None,
    ) -> Path:
        if fmv_trajectory_path is None:
            temp_data_dir = self._session.get_temp_data_dir()
            arm_suffix = "_L.fmv" if arm is Arm.LEFT else "_R.fmv"
            candidates = (
                [
                    path
                    for path in temp_data_dir.rglob(f"*{arm_suffix}")
                    if path.is_file()
                ]
                if temp_data_dir.is_dir()
                else []
            )
            if not candidates:
                raise ConfigurationError(
                    f"No {arm.name.lower()}-arm FMV trajectory exists in "
                    f"{temp_data_dir}",
                    operation="run_trajectory",
                    arm=arm.value,
                )
            trajectory_path = max(
                candidates,
                key=lambda path: (path.stat().st_mtime_ns, str(path)),
            )
        else:
            if not isinstance(fmv_trajectory_path, str) or not fmv_trajectory_path:
                raise ConfigurationError(
                    "fmv_trajectory_path must be a non-empty string or None",
                    operation="run_trajectory",
                    arm=arm.value,
                )
            trajectory_path = Path(fmv_trajectory_path).expanduser()

        trajectory_path = trajectory_path.resolve()
        if trajectory_path.suffix.lower() != ".fmv":
            raise ConfigurationError(
                f"Trajectory path must end with .fmv: {trajectory_path}",
                operation="run_trajectory",
                arm=arm.value,
            )
        if not trajectory_path.is_file():
            raise ConfigurationError(
                f"FMV trajectory does not exist or is not a file: {trajectory_path}",
                operation="run_trajectory",
                arm=arm.value,
            )
        return trajectory_path

    @staticmethod
    def _validate_fmv_trajectory(
        trajectory_path: Path,
        arm: Arm,
    ) -> tuple[tuple[float, ...], tuple[float, ...], int]:
        try:
            with trajectory_path.open("r", encoding="utf-8-sig") as trajectory:
                header = trajectory.readline().rstrip("\r\n")
                header_match = _FMV_HEADER_PATTERN.fullmatch(header)
                if header_match is None:
                    raise ConfigurationError(
                        f"Invalid FMV header: {header!r}",
                        operation="run_trajectory",
                        arm=arm.value,
                    )

                declared_rows = int(header_match.group(1))
                actual_rows = 0
                first_joints_deg: tuple[float, ...] | None = None
                final_joints_deg: tuple[float, ...] | None = None
                for line_number, line in enumerate(trajectory, start=2):
                    row = line.rstrip("\r\n")
                    row_match = _FMV_DATA_PATTERN.fullmatch(row)
                    if row_match is None:
                        raise ConfigurationError(
                            f"Invalid FMV row format at line {line_number}",
                            operation="run_trajectory",
                            arm=arm.value,
                        )
                    values = tuple(float(value) for value in row_match.groups())
                    if not all(math.isfinite(value) for value in values):
                        raise ConfigurationError(
                            f"FMV row {line_number} contains a non-finite value",
                            operation="run_trajectory",
                            arm=arm.value,
                        )
                    if values[7:] != (0.0, 0.0):
                        raise ConfigurationError(
                            f"FMV row {line_number} must end with zero X/Y values",
                            operation="run_trajectory",
                            arm=arm.value,
                        )
                    if first_joints_deg is None:
                        first_joints_deg = values[:7]
                    final_joints_deg = values[:7]
                    actual_rows += 1

        except (OSError, UnicodeError) as exc:
            raise ConfigurationError(
                f"Unable to read FMV trajectory {trajectory_path}: {exc}",
                operation="run_trajectory",
                arm=arm.value,
            ) from exc

        if actual_rows != declared_rows:
            raise ConfigurationError(
                f"FMV declares {declared_rows} rows but contains {actual_rows}",
                operation="run_trajectory",
                arm=arm.value,
            )
        if first_joints_deg is None or final_joints_deg is None:
            raise ConfigurationError(
                "FMV trajectory contains no data rows",
                operation="run_trajectory",
                arm=arm.value,
            )
        return first_joints_deg, final_joints_deg, actual_rows

    def movej(
        self,
        arm: Arm,
        joints_rad: Iterable[float] | None = None,
        joints_deg: Iterable[float] | None = None,
        vel: int = 10,
        is_block: bool = True,
        tolerance: float = 0.01,
    ) -> int:
        """Move *arm* to a joint-space target.

        Supply either ``joints_rad`` or ``joints_deg``.  When both are
        supplied, ``joints_rad`` takes precedence.  Joint limits come from
        the corresponding arm entry in :class:`RobotConfig`.

        ``vel`` is percentage 1~100

        Before sending the command, this method waits until the monitored
        button state for the arm is ``released``. A press while the guard is
        active ends this operation early and then permits the confirmed button
        transition into drag mode.

        When ``is_block`` is true, this method polls feedback every 50 ms and
        returns only after every joint is within ``tolerance`` radians of the
        effective target. Targets outside configured joint limits are clipped
        to the nearest limit before they are sent.

        Returns:
            ``0`` when the operation completes normally, including successful
            non-blocking command sending; ``1`` when a button press interrupts
            it.

        Raises:
            ConfigurationError: The command parameters are invalid.
        """
        if not isinstance(arm, Arm):
            raise ConfigurationError(
                f"arm must be an Arm, got {arm!r}", operation="movej"
            )
        if joints_rad is None and joints_deg is None:
            raise ConfigurationError(
                "Provide joints_rad or joints_deg", operation="movej", arm=arm.value
            )
        try:
            tolerance = float(tolerance)
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(
                f"tolerance must be a positive finite value, got {tolerance!r}",
                operation="movej",
                arm=arm.value,
            ) from exc
        if tolerance <= 0 or not math.isfinite(tolerance):
            raise ConfigurationError(
                f"tolerance must be a positive finite value, got {tolerance}",
                operation="movej",
                arm=arm.value,
            )

        limits = (
            self._config.left_arm_config.joints_limit
            if arm is Arm.LEFT
            else self._config.right_arm_config.joints_limit
        )
        try:
            target_rad = tuple(
                float(value)
                for value in (joints_rad if joints_rad is not None else joints_deg)
            )
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(
                "Joint targets must be numeric", operation="movej", arm=arm.value
            ) from exc
        if joints_rad is None:
            target_rad = tuple(math.radians(value) for value in target_rad)

        if len(target_rad) != limits.num_joints:
            raise ConfigurationError(
                f"Expected {limits.num_joints} joint targets, got {len(target_rad)}",
                operation="movej",
                arm=arm.value,
            )
        for index, target in enumerate(target_rad):
            if not math.isfinite(target):
                raise ConfigurationError(
                    f"joints_rad[{index}] must be finite, got {target}",
                    operation="movej",
                    arm=arm.value,
                )
        target_rad = tuple(
            min(max(target, minimum), maximum)
            for target, (minimum, maximum) in zip(target_rad, limits, strict=True)
        )

        if isinstance(vel, bool) or not isinstance(vel, int) or not 0 <= vel <= 100:
            raise ConfigurationError(
                f"vel must be an integer in [0, 100], got {vel!r}",
                operation="movej",
                arm=arm.value,
            )

        with self._button_monitor_thread.motion_guard(arm) as cancel_event:
            if self._motion_was_cancelled(cancel_event):
                return 1
            self._session.send_joint_command(
                arm.value,
                list(map(math.degrees, target_rad)),
                vel,
            )
            if self._motion_was_cancelled(cancel_event):
                return 1

            if not is_block:
                return 0

            while True:
                if self._motion_was_cancelled(cancel_event):
                    return 1
                feedback_rad = self.get_arm_data(arm).joints_pos.pos_rad
                if self._motion_was_cancelled(cancel_event):
                    return 1
                if all(
                    abs(feedback - target) < tolerance
                    for feedback, target in zip(
                        feedback_rad, target_rad, strict=True
                    )
                ):
                    return 0
                if cancel_event.wait(0.05):
                    return 1

    def movej_p(
        self,
        arm: Arm,
        T_end_ref_world: SE3,
        vel: int = 10,
        is_block: bool = True,
        tolerance: float = 0.01,
    ) -> int:
        """Move to a Cartesian target through a joint-space command.

        The session obtains the target joint position from the final point of
        a linearly planned Cartesian trajectory.  The resulting joint target
        is then delegated to :meth:`movej`, which applies configured joint
        limits, button-state motion guarding, and optional blocking feedback
        convergence.

        Only the target joint position is used, so the executed end-effector
        path is not guaranteed to be Cartesian-linear.  Use :meth:`movel` when
        a linear Cartesian path is required.

        Returns:
            The status returned by :meth:`movej`: ``0`` for normal completion
            or ``1`` when interrupted by a button press.
        """
        if not isinstance(arm, Arm):
            raise ConfigurationError(
                f"arm must be an Arm, got {arm!r}", operation="movej_p"
            )
        if not isinstance(T_end_ref_world, SE3):
            raise ConfigurationError(
                "T_end_ref_world must be an SE3",
                operation="movej_p",
                arm=arm.value,
            )

        target_joints = self._session.ik(
            arm.value,
            T_end_ref_world,
            vel=vel,
        )
        return self.movej(
            arm,
            joints_rad=target_joints.pos_rad,
            vel=vel,
            is_block=is_block,
            tolerance=tolerance,
        )

    def movej_step(
        self,
        arm: Arm,
        joints_step_rad: Iterable[float] | None = None,
        joints_step_deg: Iterable[float] | None = None,
        vel: int = 10,
        is_block: bool = True,
        tolerance: float = 0.01,
    ) -> int:
        """Move *arm* by a joint-space increment from its current position.

        Supply either ``joints_step_rad`` or ``joints_step_deg``. When both
        are supplied, the radian increment takes precedence. The resulting
        absolute target is sent through :meth:`movej`, where it is clipped to
        the configured joint limits before sending and blocking.

        Returns:
            The status returned by :meth:`movej`: ``0`` for normal completion
            or ``1`` when interrupted by a button press.
        """
        if not isinstance(arm, Arm):
            raise ConfigurationError(
                f"arm must be an Arm, got {arm!r}", operation="movej_step"
            )
        if joints_step_rad is None and joints_step_deg is None:
            raise ConfigurationError(
                "Provide joints_step_rad or joints_step_deg",
                operation="movej_step",
                arm=arm.value,
            )

        current_positions = self.get_arm_data(arm).joints_pos
        steps = joints_step_rad if joints_step_rad is not None else joints_step_deg
        try:
            steps = tuple(float(value) for value in steps)
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(
                "Joint steps must be numeric", operation="movej_step", arm=arm.value
            ) from exc
        if len(steps) != current_positions.num_joints:
            raise ConfigurationError(
                f"Expected {current_positions.num_joints} joint steps, got {len(steps)}",
                operation="movej_step",
                arm=arm.value,
            )

        if joints_step_rad is not None:
            target_rad = tuple(
                current + step
                for current, step in zip(current_positions.pos_rad, steps, strict=True)
            )
            return self.movej(
                arm,
                joints_rad=target_rad,
                vel=vel,
                is_block=is_block,
                tolerance=tolerance,
            )

        target_deg = tuple(
            current + step
            for current, step in zip(current_positions.pos_deg, steps, strict=True)
        )
        return self.movej(
            arm,
            joints_deg=target_deg,
            vel=vel,
            is_block=is_block,
            tolerance=tolerance,
        )

    def movel(
        self,
        arm: Arm,
        T_end_ref_world: SE3,
        vel: int = 10,
        is_block: bool = True,
        tolerance: float = 0.02,
    ) -> int:
        """Move *arm* linearly to ``T_end_ref_world``.

        ``vel`` is a percentage in ``[1, 100]``. When ``is_block`` is true,
        the current end-effector pose is sampled every 50 ms. The motion is
        considered complete when every component of the relative pose error
        ``current_T.inverse() @ target_T`` in ``se(3)`` is smaller than
        ``tolerance``. Its first three components are radians and its last
        three components are metres. If the arm is already within that
        tolerance, the method returns ``0`` without invoking the native linear
        planner. Native plans with fewer than six joint points are interpolated
        to the controller's six-point minimum.

        Before sending the command, this method waits until the monitored
        button state for the arm is ``released``. A press while the guard is
        active ends this operation early and then permits the confirmed button
        transition into drag mode.

        Returns:
            ``0`` when the operation completes normally, including successful
            non-blocking command sending; ``1`` when a button press interrupts
            it.
        """
        if not isinstance(arm, Arm):
            raise ConfigurationError(
                f"arm must be an Arm, got {arm!r}", operation="movel"
            )
        if not isinstance(T_end_ref_world, SE3):
            raise ConfigurationError(
                "T_end_ref_world must be an SE3", operation="movel", arm=arm.value
            )
        try:
            tolerance = float(tolerance)
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(
                f"tolerance must be a positive finite value, got {tolerance!r}",
                operation="movel",
                arm=arm.value,
            ) from exc
        if tolerance <= 0 or not math.isfinite(tolerance):
            raise ConfigurationError(
                f"tolerance must be a positive finite value, got {tolerance}",
                operation="movel",
                arm=arm.value,
            )

        with self._button_monitor_thread.motion_guard(arm) as cancel_event:
            if self._motion_was_cancelled(cancel_event):
                return 1

            # The native MOVL planner is not safe for a zero-length request:
            # FX_Robot_PLN_MOVLA_C may dereference invalid native state instead
            # of returning a failed plan.  Test convergence before crossing the
            # Python/C boundary, using exactly the same error definition as the
            # blocking completion loop below.
            current_T_end_ref_world = self.get_arm_data(arm).T_end_ref_world
            if self._motion_was_cancelled(cancel_event):
                return 1
            pose_error_se3 = (
                current_T_end_ref_world.inverse() @ T_end_ref_world
            ).log()
            if all(abs(float(error)) < tolerance for error in pose_error_se3):
                return 0

            self._session.send_linear_command(
                arm.value,
                T_end_ref_world,
                vel,
            )
            if self._motion_was_cancelled(cancel_event):
                return 1

            if not is_block:
                return 0

            while True:
                if self._motion_was_cancelled(cancel_event):
                    return 1
                current_T_end_ref_world = self.get_arm_data(arm).T_end_ref_world
                if self._motion_was_cancelled(cancel_event):
                    return 1
                pose_error_se3 = (
                    current_T_end_ref_world.inverse() @ T_end_ref_world
                ).log()
                if all(abs(float(error)) < tolerance for error in pose_error_se3):
                    return 0
                if cancel_event.wait(0.05):
                    return 1

    def movel_step(
        self,
        arm: Arm,
        T_end_ref_current_end: SE3,
        vel: int = 10,
        is_block: bool = True,
        tolerance: float = 0.02,
    ) -> int:
        """Move *arm* by an end-effector pose increment.

        The increment is expressed in the current end-effector frame. The
        next world-frame target is therefore ``current_T_end_ref_world @
        T_end_ref_current_end``. A pure rotational increment with zero
        translation preserves the current end-effector world position.

        Returns:
            The status returned by :meth:`movel`: ``0`` for normal completion
            or ``1`` when interrupted by a button press.
        """
        if not isinstance(arm, Arm):
            raise ConfigurationError(
                f"arm must be an Arm, got {arm!r}", operation="movel_step"
            )
        if not isinstance(T_end_ref_current_end, SE3):
            raise ConfigurationError(
                "T_end_ref_current_end must be an SE3",
                operation="movel_step",
                arm=arm.value,
            )

        current_T_end_ref_world = self.get_arm_data(arm).T_end_ref_world
        target_T_end_ref_world = (
            current_T_end_ref_world @ T_end_ref_current_end
        )
        return self.movel(
            arm,
            target_T_end_ref_world,
            vel=vel,
            is_block=is_block,
            tolerance=tolerance,
        )

    # ------------------------------------------------------------------
    # Data Collection
    # ------------------------------------------------------------------

    def collect_data(self) -> bool:
        """Manually start collection using options stored in ``RobotConfig``.

        The left-arm selection is sent before the right-arm selection. Their
        combined target ID count must not exceed 35; unused native list slots
        are padded with zeroes. Returns ``False`` without calling the session
        when this client is already collecting data.
        """
        return self._start_collect_data(_COLLECTION_SOURCE_USER)

    def _collect_data_from_button(self) -> bool:
        """Start collection attributed to the confirmed button press."""
        return self._start_collect_data(_COLLECTION_SOURCE_BUTTON)

    def _start_collect_data(self, source: str) -> bool:
        with self._collection_state_lock:
            if self._is_collecting_data:
                logger.warning("Data collection is already active")
                return False

            started = self._session.collect_data()
            if started:
                self._is_collecting_data = True
                self._collect_data_source = source
            return started

    def stop_and_save_data(
        self,
        dir: str | None = None,
    ) -> bool:
        """Stop and save using the collection options in ``RobotConfig``.

        When ``dir`` is ``None``, data is saved under
        ``RobotConfig.traj_data_dir``. A valid explicit directory overrides
        the configured location for this call.

        The options determine the native left-then-right column layout. Each
        arm independently gets a split TXT and FMV when its option contains
        all joint-position IDs ``0..6``. Incomplete-arm data remains only in
        the raw file. Returns ``False`` without calling the session when this
        client is not collecting data.
        """
        return self._stop_and_save_data(dir, required_source=None)

    def _stop_button_collection_if_active(self) -> bool:
        """Stop only a collection started by ``on_button_pressed``."""
        return self._stop_and_save_data(
            None,
            required_source=_COLLECTION_SOURCE_BUTTON,
        )

    def _stop_and_save_data(
        self,
        dir: str | None,
        *,
        required_source: str | None,
    ) -> bool:
        with self._collection_state_lock:
            if not self._is_collecting_data:
                logger.warning("No active data collection to stop and save")
                return False
            if (
                required_source is not None
                and self._collect_data_source != required_source
            ):
                logger.debug(
                    "Ignoring automatic stop for collection source %r",
                    self._collect_data_source,
                )
                return False

            data_dir = self._prepare_traj_data_dir(
                self._config.traj_data_dir if dir is None else dir
            )
            stopped = self._session.stop_collect_data()
            if stopped:
                self._is_collecting_data = False
                self._collect_data_source = None
                logger.warning("stopped data collection")
            else:
                logger.warning(
                    "Controller reported that data collection did not stop cleanly; "
                    "attempting to save the collected data anyway"
                )
            time.sleep(0.1)
            return self._session.save_collected_data(data_dir)

    @staticmethod
    def _prepare_traj_data_dir(dir: str) -> str:
        """Validate and create a per-call trajectory data directory."""
        if not isinstance(dir, str) or not dir.strip():
            raise ConfigurationError(
                f"dir must be a non-empty directory path, got {dir!r}",
                operation="stop_and_save_data",
            )
        try:
            data_dir = Path(dir).expanduser()
            data_dir.mkdir(parents=True, exist_ok=True)
            data_dir = data_dir.resolve()
        except (OSError, ValueError) as exc:
            raise ConfigurationError(
                f"Unable to create or access data directory {dir!r}: {exc}",
                operation="stop_and_save_data",
            ) from exc
        if not data_dir.is_dir():
            raise ConfigurationError(
                f"Data path is not a directory: {data_dir}",
                operation="stop_and_save_data",
            )
        if not os.access(data_dir, os.W_OK):
            raise ConfigurationError(
                f"Data directory is not writable: {data_dir}",
                operation="stop_and_save_data",
            )
        return str(data_dir)

    # ------------------------------------------------------------------
    # Lifecycle state
    # ------------------------------------------------------------------

    @property
    def connected(self) -> bool:
        """Whether the controller connection is currently established."""
        return self._session.connected

    @property
    def initialised(self) -> bool:
        """Whether ``initialize()`` has completed successfully."""
        return self._session.initialised

    @property
    def closed(self) -> bool:
        """Whether the client has been closed."""
        return self._session.closed
