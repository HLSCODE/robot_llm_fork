# TrajectoryDescription

源码：`src/tj_robot_proj/trajectory_description.py`。所有点均为同一参考坐标系下的
`SE3`；平移单位 m，时间单位 s，采样频率单位 Hz。仅进行位姿规划。

## 构造和访问

```python
from tj_robot_proj import TrajectoryDescription, SE3, SO3

trajectory = TrajectoryDescription(frequency=500.0, init_p=SE3.identity())
trajectory.frequency  # 500.0，只读
trajectory.p_list     # list[SE3]，包含初始点，返回列表副本
trajectory.length     # 初始为 1
trajectory.time       # 初始为 0.0
```

`frequency` 必须是有限非负数，`init_p` 必须是 `SE3`。允许以零频率构造单点轨迹，
但调用 `movel_step`、`movec` 或需要连接段的加法时，频率必须大于零。
初始点时间为 0，之后每个点间隔 `1 / frequency` 秒，轨迹时长等于
`(length - 1) / frequency`。通过方法追加点，修改 `p_list` 返回的列表不会修改轨迹。

## movel_step

```python
trajectory.movel_step(p=SE3(SO3.identity(), [0.1, 0, 0]), time=2.0)
```

签名：`movel_step(p: SE3, time: float) -> None`。其语义与 `RobotClient.movel_step`
一致：`p` 是相对于当前轨迹最后一点末端坐标系的位姿增量，绝对目标为
`trajectory.p_list[-1] @ p`。方法原地追加从当前最后一点到该目标的轨迹。

- `time` 为有限数，且不小于 `1 / frequency`。
- 新增点数 `N = floor(time * frequency)`，已有起点不重复加入。
- 实际新增时长为 `N / frequency`，最后一点精确为调用前末点右乘 `p`。
- 当 `N == 1` 时直接追加组合后的目标。
- 传入 `SE3.identity()` 表示保持当前位置和姿态，可用来描述静止停留。
- 增量的平移和旋转均在调用时最后一点的局部末端坐标系中解释；因此局部纯旋转
  不会改变末端在参考坐标系中的位置。
- 几何插值：XYZ 沿直线，旋转沿 SO(3) 最短路径插值
  （等价于最短路径四元数 SLERP），平移和旋转共享进度。
- 因接口指定时长、不指定速度和加速度，采用 `s(u)=3u²-2u³` 作为平滑进度，
  连续曲线的起止速度为零。

例如 100 Hz 下传入 0.125 秒，新增 12 个点，实际新增时长为 0.12 秒。

## movec

```python
trajectory.movec(
    axis=[0, 0, 1], radius=0.04, ring=2.0, l=0.1,
    time=8.0, direction=1, rotation_stay=True,
)
```

签名为 `movec(axis, radius, ring, l, time: float, direction=0, rotation_stay=True) -> None`。
从当前轨迹最后一点开始，生成绕局部轴旋转并沿该轴平移的位姿轨迹；轴相对于该点的
局部末端坐标系，输出位姿变换回原参考系。

| 参数 | 范围与含义 |
|---|---|
| `axis` | 三个有限数构成的非零 `list`，内部单位化 |
| `radius` | `[0, 0.2]` m |
| `ring` | 有限数，`>= 1`，包括起止半圈 |
| `l` | `[-0.5, 0.5]` m，沿局部轴的总位移 |
| `direction` | 整数 0 顺时针、1 逆时针；从轴正向看向原点 |
| `rotation_stay` | 默认且仅支持 `True`，保持起始姿态 |
| `time` | 必传有限时长，单位 s，`>= 1 / frequency` |

与 `movel_step` 使用同一时间规则：新增 `N = floor(time * frequency)` 个点，实际新增
时长 `N / frequency`，不重复已有起点。点数和时长只由 `frequency` 和 `time` 决定，
不根据半径、圈数或轴向距离自动延长，也不施加原客户端的速度上限。
每点角度按 `2π * ring * i / N` 计算；前半圈平滑扩圆、最后半圈平滑收圆，中间保持
半径，轴向位移采用平滑启停曲线。最终回到轴上，轴向位移精确为 `l`。
当 `N == 1` 时仅追加最终位姿，不包含中间圆周采样点。
不进行关节限位或可达性验证。

## movec_uniform

```python
trajectory.movec_uniform(
    axis=[0, 0, 1], radius=0.04, ring=4.0, l=0.1,
    time=8.0, direction=1, rotation_stay=True,
)
```

签名和参数约束与 `movec` 相同。区别仅在半径规划方式：设整个轨迹的归一化进度为
`u`，则

```text
radius_at_point = radius * (1 - abs(2u - 1))
```

因此，前 `ring / 2` 圈从轴心开始，半径随角度均匀增加，在总圈数的一半处达到
`radius`；后 `ring / 2` 圈半径均匀减小，最终回到轴心。中间没有定半径圆周段。
例如 `ring=4` 时，前两圈向外扩张，后两圈向内收缩。

轴向位移仍使用 `3u²-2u³` 从 0 平滑变化到 `l`，姿态保持不变。新增点数仍为
`floor(time * frequency)`，最终位姿精确位于轴上 `l * axis_unit` 处。

## move_star

```python
trajectory.move_star(
    n=5, axis=[0, 0, 1], radius=0.04, ring=2.0, l=0.1,
    time=10.0, direction=1,
)
```

签名：`move_star(n: int, axis: list[float], radius: float, ring: float, l: float,
time: float, direction: int = 0) -> None`。

采用轮廓式星形：`n` 个外顶点等间隔位于半径 `radius` 的圆上，交替连接半径
`radius/2` 上的 `n` 个内顶点，一次闭合路线包含 `2n` 条直线边。
这不是跳过顶点画交叉线的星形。`n` 为不小于 2 的整数；`n=2` 退化为菱形，
`n=3` 的内顶点位于外三角形边上。姿态始终保持本段起始姿态。

`axis` 相对于调用时最后一点的局部末端坐标系；`radius`、`l`、`direction` 的单位和
范围同 `movec`。`ring >= 1` 是重复次数，整数表示完整重复，小数表示最后追加一段
不完整星形路线。起始从轴心直线走到第一个外顶点；完成重复后，从最后一个路线点
直线收回轴上。整数重复时，该点就是第一个外顶点。

总点数与其他方法一致：新增 `floor(time * frequency)` 个点。进入段、每条完整星形边
和退出段各占一份时间，最后的不完整边按比例占用时间。每条三维线段内部采用
`3u²-2u³` 插值，使线段起止速度为零。分段端点的轴向坐标按全局平滑曲线从 0 变到
`l`，线段内部线性连接，最终位移精确为 `l * axis_unit`。

采样点很少时可能跳过星形顶点；仅一个采样点时直接追加轴上的终点。
所有点仍属于同一参考系，可继续调用 `movel_step`、`movec` 或进行轨迹相加。

## move_polygon

```python
trajectory.move_polygon(
    n=6, axis=[0, 0, 1], radius=0.04, ring=2.0, l=0.1,
    time=10.0, direction=1,
)
```

签名：`move_polygon(n: int, axis: list[float], radius: float, ring: float,
l: float, time: float, direction: int = 0) -> None`。

生成以 `axis` 为局部法向的正 n 边形轮廓。`n` 是不小于 3 的整数，所有顶点等间隔
分布在半径 `radius` 的外接圆上，一次闭合路线包含 `n` 条直线边。姿态保持本段起点
姿态，`axis`、`radius`、`l` 和 `direction` 的坐标约定与取值范围同 `movec`。

`ring >= 1` 表示轮廓重复次数；小数部分表示在最后一圈只走对应比例的边。例如四边形
的 `ring=1.5` 会走完一圈后再走两条边，到达首顶点的对角顶点。轨迹先从轴心直线
进入第一个顶点，完成轮廓后再从当前轮廓点直线收回轴上，终点精确为
`l * axis_unit`。

新增点数为 `floor(time * frequency)`。进入段、每条完整边和退出段各占一份时间，
不完整边按其比例占用时间；每段使用 `3u²-2u³` 插值，因此在每个顶点都会降速到
零。轴向位移的处理、稀疏采样行为及可达性限制与 `move_star` 相同。

## 通过 RobotClient 执行

```python
# client 已初始化，RobotConfig.trajectory_frequency 为 500。
result = client.run_trajectory_description(
    Arm.RIGHT, trajectory, is_block=True, tolerance=0.01,
)
```

描述实例与 `RobotConfig` 的轨迹频率都必须为 500 Hz，所有描述点采用世界坐标系。
客户端先调用 `movel` 确认并在需要时移动到描述起点。当前位姿已在
`tolerance` 内时，`movel` 会在 Python 层直接返回，不会将零长度轨迹传入原生规划器。
随后读取当前七关节角作为第一点的 IK 参考，
每个后续点以上一点逆解为参考。全部点求解成功后，将角度（度）写入
`YYYYMMDD_HHMMSS_L_trajectory_description.fmv` 或
`YYYYMMDD_HHMMSS_R_trajectory_description.fmv`，最后调用 `run_trajectory`。
Linux 文件目录为 `/tmp/tj_trajectory_data`，其他系统为当前工作目录。

同一 `RobotClient` 会按手臂和描述中的全部位姿计算内容指纹。再次执行内容未变的描述时，
仍会先到达描述起点，但会复用首次生成且未被修改的 FMV；会话层还会按 FMV 内容指纹
复用控制器中已经上传的 PVT 槽，只重新下发运行命令。描述、手臂或 FMV 内容变化时缓存
自动失效并重新求解、生成和上传；重新连接或关闭会话时清空上传缓存。

`is_block=False` 仅使最后的轨迹播放非阻塞；移动到起点和 IK 计算仍需完成。
`tolerance` 同时传给初始 `movel`（姿态误差 rad/m）和 `run_trajectory`
（关节误差 rad）。运动守护由这些运动方法提供。正常完成或非阻塞启动返回 `0`，
按钮打断返回 `1`；到起点被打断时不再继续 IK 或播放，IK 失败也不会启动播放。

## 相加

```python
second = TrajectoryDescription(trajectory.frequency, trajectory.p_list[-1])
second.movel_step(SE3(SO3.identity(), [0.2, 0, 0.1]), time=1.0)
combined = trajectory + second
```

两个操作数必须同频率。加法创建新轨迹，不改变原对象，不移动或重新解释第二条轨迹的坐标。
连接点相等（使用 `SE3` 值对象的相等判定）时只保留一份，否则在结果对象中先调用
`movel_step(result.p_list[-1].inverse() @ second.p_list[0],
time=max(XYZ欧氏距离 / 0.1, 1 / frequency))`，把绝对连接目标换算成局部增量后，
再接上第二条轨迹的剩余点。纯旋转或距离不足一个周期的连接也使用一个周期。
连接时长按 `movel_step` 规则向下取整；`0.1` 用于估算时间，不代表平滑连接段的速度上限。
