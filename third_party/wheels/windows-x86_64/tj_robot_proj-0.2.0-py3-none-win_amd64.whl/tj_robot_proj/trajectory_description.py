"""Sampled Cartesian trajectories, independent of a robot or native SDK."""

from __future__ import annotations

import math

import numpy as np

from tj_robot_proj.value_objects.lie_group.SE3 import SE3
from tj_robot_proj.value_objects.lie_group.SO3 import SO3


def _finite(value: float, name: str) -> float:
    if isinstance(value, (bool, str, bytes)):
        raise ValueError(f"{name} must be a finite number")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{name} must be a finite number") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name} must be a finite number")
    return result


def _smoothstep(value: float) -> float:
    value = min(max(value, 0.0), 1.0)
    return value * value * (3.0 - 2.0 * value)


class TrajectoryDescription:
    """Build a pose sequence in a common reference frame (metres/radians).

    The initial pose is at time zero; each appended pose adds 1/frequency
    seconds. Zero frequency is allowed for construction only: motion planning
    requires a positive frequency. No IK, file output or robot commands occur.
    """

    def __init__(self, frequency: float, init_p: SE3) -> None:
        frequency = _finite(frequency, "frequency")
        if frequency < 0:
            raise ValueError("frequency must be >= 0")
        if not isinstance(init_p, SE3):
            raise TypeError("init_p must be an SE3")
        self._frequency = frequency
        self._p_list: list[SE3] = [init_p]

    @property
    def frequency(self) -> float:
        """Sampling frequency in Hz (read-only)."""
        return self._frequency

    @property
    def p_list(self) -> list[SE3]:
        """Return a list copy of the immutable poses, including the start."""
        return self._p_list.copy()

    @property
    def length(self) -> int:
        """Number of poses, including the initial pose."""
        return len(self._p_list)

    @property
    def time(self) -> float:
        """Actual sampled duration in seconds: (length - 1) / frequency."""
        if self.length == 1:
            return 0.0
        return (self.length - 1) / self.frequency

    def _period(self) -> float:
        if self.frequency <= 0:
            raise ValueError("frequency must be > 0 for trajectory planning")
        period = 1.0 / self.frequency
        if not math.isfinite(period):
            raise ValueError("frequency is too small for a finite sampling period")
        return period

    def _sample_count(self, time: float) -> int:
        """Validate a segment duration and truncate it to whole periods."""
        period = self._period()
        duration = _finite(time, "time")
        if duration < period:
            raise ValueError("time must be >= 1/frequency")
        sample_count = duration * self.frequency
        if not math.isfinite(sample_count):
            raise ValueError("time * frequency must be finite")
        return max(1, math.floor(sample_count))

    def movel_step(self, p: SE3, time: float) -> None:
        """Append a straight segment using a local end-effector increment.

        ``p`` is expressed in the current last pose's end-effector frame. The
        world/reference-frame target is ``last_pose @ p``, matching
        ``RobotClient.movel_step``. ``time`` is a finite duration in seconds,
        at least 1/frequency.
        Append floor(time * frequency) samples, excluding the existing start
        and including the exact target. A single sample simply appends that
        composed target.
        Translation is linear in shared progress and rotation follows the
        shortest SO(3) path (SLERP equivalent). Progress uses 3s²-2s³ for
        zero endpoint velocities. This follows MOVL's geometric interpolation,
        not its native acceleration/filter implementation or joint-space IK.
        """
        if not isinstance(p, SE3):
            raise TypeError("p must be an SE3")
        count = self._sample_count(time)
        start = self._p_list[-1]
        target = start @ p
        if count == 1:
            self._p_list.append(target)
            return

        rotation_vector = (start.rotation.inverse() @ target.rotation).log()
        points = []
        for index in range(1, count):
            progress = _smoothstep(index / count)
            points.append(SE3(
                start.rotation @ SO3.exp(progress * rotation_vector),
                (1.0 - progress) * start.translation
                + progress * target.translation,
            ))
        points.append(target)
        self._p_list.extend(points)

    def movec(
        self,
        axis: list[float],
        radius: float,
        ring: float,
        l: float,
        time: float,
        direction: int = 0,
        rotation_stay: bool = True,
    ) -> None:
        """Append a circular trajectory around a local axis from the last pose.

        The nonzero three-vector axis is expressed in that pose's local frame.
        Radius is in [0, 0.2] m, ring >= 1, axial travel l in [-0.5, 0.5] m.
        Direction is 0 clockwise or 1 counter-clockwise when viewed toward
        the origin from the positive axis. Only rotation_stay=True is supported.
        The first/final half-turns smoothly expand/contract the radius;
        axial motion eases in and out. As in movel_step, time must be finite and
        >= 1/frequency, and floor(time * frequency) points are appended.
        The full path is sampled across those intervals with no speed-based
        time extension. With one interval only the exact endpoint is appended.
        """
        count = self._sample_count(time)
        if not isinstance(axis, list) or len(axis) != 3:
            raise ValueError("axis must be a list of three finite numbers")
        components = [_finite(component, "axis component") for component in axis]
        norm = math.hypot(*components)
        if norm == 0 or not math.isfinite(norm):
            raise ValueError("axis must have a finite nonzero norm")
        axis_unit = np.array([component / norm for component in components])
        radius = _finite(radius, "radius")
        ring = _finite(ring, "ring")
        l = _finite(l, "l")
        if not 0 <= radius <= 0.2:
            raise ValueError("radius must be in [0, 0.2] metres")
        if ring < 1:
            raise ValueError("ring must be >= 1")
        if not -0.5 <= l <= 0.5:
            raise ValueError("l must be in [-0.5, 0.5] metres")
        if isinstance(direction, bool) or not isinstance(direction, int) or direction not in (0, 1):
            raise ValueError("direction must be integer 0 or 1")
        if rotation_stay is not True:
            raise ValueError("only rotation_stay=True is supported")

        reference = np.zeros(3)
        reference[int(np.argmin(np.abs(axis_unit)))] = 1.0
        radial_x = np.cross(axis_unit, reference)
        radial_x /= np.linalg.norm(radial_x)
        radial_y = np.cross(axis_unit, radial_x)
        total_angle = math.tau * ring
        if not math.isfinite(total_angle):
            raise ValueError("ring is too large to plan")
        sign = 1.0 if direction == 1 else -1.0
        start = self._p_list[-1]
        points = []
        for index in range(1, count + 1):
            angle = total_angle * (index / count)
            radius_at_point = radius * min(
                _smoothstep(angle / math.pi),
                _smoothstep((total_angle - angle) / math.pi),
            )
            translation = (
                radius_at_point * math.cos(sign * angle) * radial_x
                + radius_at_point * math.sin(sign * angle) * radial_y
                + l * _smoothstep(index / count) * axis_unit
            )
            if index == count:
                translation = l * axis_unit
            points.append(start @ SE3(SO3.identity(), translation))
        self._p_list.extend(points)

    def movec_uniform(
        self,
        axis: list[float],
        radius: float,
        ring: float,
        l: float,
        time: float,
        direction: int = 0,
        rotation_stay: bool = True,
    ) -> None:
        """Append a uniformly expanding and contracting circular trajectory.

        Parameters, coordinates, sample timing and orientation behavior match
        movec. The radial profile is different: during the first ring/2 turns
        the radius increases linearly from zero to radius, and during the
        remaining ring/2 turns it decreases linearly back to zero. Therefore
        there is no constant-radius middle section. Axial motion still uses a
        smoothstep profile from zero to l.
        """
        count = self._sample_count(time)
        if not isinstance(axis, list) or len(axis) != 3:
            raise ValueError("axis must be a list of three finite numbers")
        components = [_finite(component, "axis component") for component in axis]
        norm = math.hypot(*components)
        if norm == 0 or not math.isfinite(norm):
            raise ValueError("axis must have a finite nonzero norm")
        axis_unit = np.array([component / norm for component in components])
        radius = _finite(radius, "radius")
        ring = _finite(ring, "ring")
        l = _finite(l, "l")
        if not 0 <= radius <= 0.2:
            raise ValueError("radius must be in [0, 0.2] metres")
        if ring < 1:
            raise ValueError("ring must be >= 1")
        if not -0.5 <= l <= 0.5:
            raise ValueError("l must be in [-0.5, 0.5] metres")
        if isinstance(direction, bool) or not isinstance(direction, int) or direction not in (0, 1):
            raise ValueError("direction must be integer 0 or 1")
        if rotation_stay is not True:
            raise ValueError("only rotation_stay=True is supported")

        reference = np.zeros(3)
        reference[int(np.argmin(np.abs(axis_unit)))] = 1.0
        radial_x = np.cross(axis_unit, reference)
        radial_x /= np.linalg.norm(radial_x)
        radial_y = np.cross(axis_unit, radial_x)
        total_angle = math.tau * ring
        if not math.isfinite(total_angle):
            raise ValueError("ring is too large to plan")
        sign = 1.0 if direction == 1 else -1.0
        start = self._p_list[-1]
        points = []
        for index in range(1, count + 1):
            progress = index / count
            angle = total_angle * progress
            radius_at_point = radius * (1.0 - abs(2.0 * progress - 1.0))
            translation = (
                radius_at_point * math.cos(sign * angle) * radial_x
                + radius_at_point * math.sin(sign * angle) * radial_y
                + l * _smoothstep(progress) * axis_unit
            )
            if index == count:
                translation = l * axis_unit
            points.append(start @ SE3(SO3.identity(), translation))
        self._p_list.extend(points)

    def move_star(
        self,
        n: int,
        axis: list[float],
        radius: float,
        ring: float,
        l: float,
        time: float,
        direction: int = 0,
    ) -> None:
        """Append an n-tip star outline with straight entry/exit segments.

        The star lies in the plane normal to axis in the last pose's local
        frame. Its n outer tips lie on radius; the n alternating inner
        vertices lie on radius/2. n=2 is the degenerate diamond outline.
        Orientation stays fixed. Radius, axial travel l and direction use
        movec's conventions and bounds; ring >= 1 counts repetitions, with
        a fractional repetition following a prefix of the outline.

        Append floor(time * frequency) samples, including the exact endpoint
        on the axis at l. Entry, each full star edge, and exit receive equal
        time shares; a partial edge receives its proportional share. Entry
        connects the axis to the first outer tip; exit connects the last
        outline point back to the axis. Each 3D segment uses smoothstep
        interpolation with zero endpoint velocity. Axial positions at segment
        boundaries follow a global smoothstep from zero to l.

        Very sparse sampling can miss vertices; one sample appends only the
        endpoint. No IK or robot commands are performed.
        """
        count = self._sample_count(time)
        if isinstance(n, bool) or not isinstance(n, int) or n < 2:
            raise ValueError("n must be an integer >= 2")
        if not isinstance(axis, list) or len(axis) != 3:
            raise ValueError("axis must be a list of three finite numbers")
        components = [_finite(component, "axis component") for component in axis]
        norm = math.hypot(*components)
        if norm == 0 or not math.isfinite(norm):
            raise ValueError("axis must have a finite nonzero norm")
        axis_unit = np.array([component / norm for component in components])
        radius = _finite(radius, "radius")
        ring = _finite(ring, "ring")
        l = _finite(l, "l")
        if not 0 <= radius <= 0.2:
            raise ValueError("radius must be in [0, 0.2] metres")
        if ring < 1:
            raise ValueError("ring must be >= 1")
        if not -0.5 <= l <= 0.5:
            raise ValueError("l must be in [-0.5, 0.5] metres")
        if isinstance(direction, bool) or not isinstance(direction, int) or direction not in (0, 1):
            raise ValueError("direction must be integer 0 or 1")
        try:
            star_edges = 2 * n * ring
        except OverflowError as exc:
            raise ValueError("n * ring is too large to plan") from exc
        if not math.isfinite(star_edges):
            raise ValueError("n * ring must be finite")
        total_units = star_edges + 2.0

        reference = np.zeros(3)
        reference[int(np.argmin(np.abs(axis_unit)))] = 1.0
        radial_x = np.cross(axis_unit, reference)
        radial_x /= np.linalg.norm(radial_x)
        radial_y = np.cross(axis_unit, radial_x)
        sign = 1.0 if direction == 1 else -1.0

        def vertex(index: int) -> np.ndarray:
            index %= 2 * n
            angle = sign * math.pi * (index / n)
            distance = radius if index % 2 == 0 else radius * 0.5
            return distance * (math.cos(angle) * radial_x + math.sin(angle) * radial_y)

        def outline_point(edge: float) -> np.ndarray:
            index = math.floor(edge)
            fraction = edge - index
            return (1.0 - fraction) * vertex(index) + fraction * vertex(index + 1)

        def with_axial(radial: np.ndarray, unit: float) -> np.ndarray:
            return radial + l * _smoothstep(unit / total_units) * axis_unit

        start = self._p_list[-1]
        points = []
        for index in range(1, count + 1):
            unit = total_units * (index / count)
            if index == count:
                translation = l * axis_unit
            else:
                if unit <= 1.0:
                    begin_unit, end_unit = 0.0, 1.0
                    begin = np.zeros(3)
                    end = with_axial(vertex(0), end_unit)
                elif unit < star_edges + 1.0:
                    edge = math.floor(unit - 1.0)
                    begin_unit = 1.0 + edge
                    end_unit = 1.0 + min(edge + 1.0, star_edges)
                    begin = with_axial(vertex(edge), begin_unit)
                    end = with_axial(outline_point(end_unit - 1.0), end_unit)
                else:
                    begin_unit, end_unit = star_edges + 1.0, total_units
                    begin = with_axial(outline_point(star_edges), begin_unit)
                    end = l * axis_unit
                progress = _smoothstep((unit - begin_unit) / (end_unit - begin_unit))
                translation = (1.0 - progress) * begin + progress * end
            points.append(start @ SE3(SO3.identity(), translation))
        self._p_list.extend(points)

    def move_polygon(
        self,
        n: int,
        axis: list[float],
        radius: float,
        ring: float,
        l: float,
        time: float,
        direction: int = 0,
    ) -> None:
        """Append a regular n-gon outline with straight entry/exit segments.

        The regular polygon lies in the plane normal to axis in the last
        pose's local frame. All n vertices lie on radius, and n must be an
        integer >= 3. Orientation stays fixed. Radius, axial travel l and
        direction use movec's conventions and bounds; ring >= 1 counts
        repetitions, with a fractional repetition following a prefix of the
        polygon outline.

        Append floor(time * frequency) samples, including the exact endpoint
        on the axis at l. Entry, each full polygon edge, and exit receive equal
        time shares; a partial edge receives its proportional share. Entry
        connects the axis to the first vertex; exit connects the last outline
        point back to the axis. Each 3D segment uses smoothstep interpolation
        with zero endpoint velocity. Axial positions at segment boundaries
        follow a global smoothstep from zero to l.

        Very sparse sampling can miss vertices; one sample appends only the
        endpoint. No IK or robot commands are performed.
        """
        count = self._sample_count(time)
        if isinstance(n, bool) or not isinstance(n, int) or n < 3:
            raise ValueError("n must be an integer >= 3")
        if not isinstance(axis, list) or len(axis) != 3:
            raise ValueError("axis must be a list of three finite numbers")
        components = [_finite(component, "axis component") for component in axis]
        norm = math.hypot(*components)
        if norm == 0 or not math.isfinite(norm):
            raise ValueError("axis must have a finite nonzero norm")
        axis_unit = np.array([component / norm for component in components])
        radius = _finite(radius, "radius")
        ring = _finite(ring, "ring")
        l = _finite(l, "l")
        if not 0 <= radius <= 0.2:
            raise ValueError("radius must be in [0, 0.2] metres")
        if ring < 1:
            raise ValueError("ring must be >= 1")
        if not -0.5 <= l <= 0.5:
            raise ValueError("l must be in [-0.5, 0.5] metres")
        if isinstance(direction, bool) or not isinstance(direction, int) or direction not in (0, 1):
            raise ValueError("direction must be integer 0 or 1")
        try:
            polygon_edges = n * ring
        except OverflowError as exc:
            raise ValueError("n * ring is too large to plan") from exc
        if not math.isfinite(polygon_edges):
            raise ValueError("n * ring must be finite")
        total_units = polygon_edges + 2.0

        reference = np.zeros(3)
        reference[int(np.argmin(np.abs(axis_unit)))] = 1.0
        radial_x = np.cross(axis_unit, reference)
        radial_x /= np.linalg.norm(radial_x)
        radial_y = np.cross(axis_unit, radial_x)
        sign = 1.0 if direction == 1 else -1.0

        def vertex(index: int) -> np.ndarray:
            angle = sign * math.tau * ((index % n) / n)
            return radius * (math.cos(angle) * radial_x + math.sin(angle) * radial_y)

        def outline_point(edge: float) -> np.ndarray:
            index = math.floor(edge)
            fraction = edge - index
            return (1.0 - fraction) * vertex(index) + fraction * vertex(index + 1)

        def with_axial(radial: np.ndarray, unit: float) -> np.ndarray:
            return radial + l * _smoothstep(unit / total_units) * axis_unit

        start = self._p_list[-1]
        points = []
        for index in range(1, count + 1):
            unit = total_units * (index / count)
            if index == count:
                translation = l * axis_unit
            else:
                if unit <= 1.0:
                    begin_unit, end_unit = 0.0, 1.0
                    begin = np.zeros(3)
                    end = with_axial(vertex(0), end_unit)
                elif unit < polygon_edges + 1.0:
                    edge = math.floor(unit - 1.0)
                    begin_unit = 1.0 + edge
                    end_unit = 1.0 + min(edge + 1.0, polygon_edges)
                    begin = with_axial(vertex(edge), begin_unit)
                    end = with_axial(outline_point(end_unit - 1.0), end_unit)
                else:
                    begin_unit, end_unit = polygon_edges + 1.0, total_units
                    begin = with_axial(outline_point(polygon_edges), begin_unit)
                    end = l * axis_unit
                progress = _smoothstep((unit - begin_unit) / (end_unit - begin_unit))
                translation = (1.0 - progress) * begin + progress * end
            points.append(start @ SE3(SO3.identity(), translation))
        self._p_list.extend(points)

    def __add__(self, other: object) -> TrajectoryDescription:
        """Return a same-frequency concatenation without changing operands.

        Join equal poses once. Otherwise bridge with movel_step at a nominal
        distance / 0.1 m/s duration, at least one period (also for pure
        rotation). Poses retain their reference-frame coordinates.
        """
        if not isinstance(other, TrajectoryDescription):
            return NotImplemented
        if self.frequency != other.frequency:
            raise ValueError("trajectories must have the same frequency")
        result = TrajectoryDescription(self.frequency, self._p_list[0])
        result._p_list = self._p_list.copy()
        target = other._p_list[0]
        if result._p_list[-1] != target:
            period = result._period()
            distance = math.dist(result._p_list[-1].translation, target.translation)
            increment = result._p_list[-1].inverse() @ target
            result.movel_step(increment, max(period, distance / 0.1))
        result._p_list.extend(other._p_list[1:])
        return result
